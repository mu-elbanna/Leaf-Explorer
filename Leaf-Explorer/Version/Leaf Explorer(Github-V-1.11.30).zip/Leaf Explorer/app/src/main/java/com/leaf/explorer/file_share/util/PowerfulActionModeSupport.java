package com.leaf.explorer.file_share.util;

import com.genonbeta.android.framework.widget.PowerfulActionMode;

public interface PowerfulActionModeSupport
{
    PowerfulActionMode getPowerfulActionMode();
}
