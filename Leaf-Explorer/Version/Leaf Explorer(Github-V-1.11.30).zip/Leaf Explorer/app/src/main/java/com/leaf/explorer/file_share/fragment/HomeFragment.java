package com.leaf.explorer.file_share.fragment;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.leaf.explorer.file_share.activity.ContentSharingActivity;
import com.leaf.explorer.file_share.activity.WebShareActivity;
import com.leaf.explorer.file_share.model.TitleSupport;
import com.leaf.explorer.R;
import com.genonbeta.android.framework.ui.callback.SnackbarSupport;

public class HomeFragment
        extends com.genonbeta.android.framework.app.Fragment
        implements TitleSupport, SnackbarSupport, com.genonbeta.android.framework.app.FragmentImpl
{

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState)
    {
        final View view = inflater.inflate(R.layout.fragment_home, container, false);

        Button actionReceive = view.findViewById(R.id.receive);

        actionReceive.setOnClickListener(view1 -> startActivity(new Intent(getContext(), WebShareActivity.class)));

        Button actionSend = view.findViewById(R.id.send);
        actionSend.setOnClickListener(view12 -> {
            Intent mIntent = new Intent(getContext(), ContentSharingActivity.class);
            mIntent.putExtra("no.", 0);
            startActivity(mIntent);
        });


        return view;
    }


    @Override
    public CharSequence getTitle(Context context)
    {
        return context.getString(R.string.text_home);
    }


}
