package com.leaf.explorer.file_share.activity;

public class ShareTextActivity extends Activity
{
}
