package com.leaf.explorer.file_share.util;

public interface DetachListener
{
    void onPrepareDetach();
}
