package com.leaf.explorer.file_share.activity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

import androidx.annotation.Nullable;

import com.leaf.explorer.R;

public class ShareSplashActivity extends Activity
{

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
       // setSkipPermissionRequest(true);
      //  setWelcomePageDisallowed(true);

        gotoHomeActivity();

    }

    private void gotoHomeActivity(){
        startActivity(new Intent(this, HomeActivity.class));
        finish();
    }


}
