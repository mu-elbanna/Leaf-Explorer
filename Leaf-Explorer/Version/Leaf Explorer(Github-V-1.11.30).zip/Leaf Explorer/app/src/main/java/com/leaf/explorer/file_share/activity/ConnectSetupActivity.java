package com.leaf.explorer.file_share.activity;

import android.Manifest;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.Toast;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.widget.Toolbar;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.leaf.explorer.R;
import com.leaf.explorer.file_share.util.ConnectionUtils;

import static com.leaf.explorer.file_share.activity.AddDevicesToTransferActivity.REQUEST_CODE_SETUP_DEVICE;

public class ConnectSetupActivity extends Activity {

    public static final String EXTRA_ACTIVITY_SUBTITLE = "extraActivitySubtitle";
    private ConnectionUtils mConnectionUtils;
    public static final int REQUEST_PERMISSION_LOCATION = 2;
    RelativeLayout location;
    ProgressBar mProgressBar;
    ImageView mImageView;

    RelativeLayout wifi;
    ProgressBar wifiProgressBar;
    ImageView wifiImageView;

    FloatingActionButton content_next;
    private static String mTitleProvided;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.connect_setup_activity);
        final Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        if (getIntent() != null) {
            mTitleProvided = getIntent().getStringExtra(EXTRA_ACTIVITY_SUBTITLE);
            setTitle(mTitleProvided);
        }

        mConnectionUtils = new ConnectionUtils(getApplicationContext());

        location = findViewById(R.id.layout_location_manager_info_toggle_button);
        mProgressBar = findViewById(R.id.location_establishment_progress);
        mImageView = findViewById(R.id.location_establishment_completed);

        wifi = findViewById(R.id.layout_wifi_manager_info_toggle_button);
        wifiProgressBar = findViewById(R.id.wifi_establishment_progress);
        wifiImageView = findViewById(R.id.wifi_establishment_completed);

        content_next = findViewById(R.id.content_next);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            location.setOnClickListener(v -> validateLocationPermission());
        }
        wifi.setOnClickListener(v -> turnOnWiFi());
        content_next.setOnClickListener(v -> {
            if (Build.VERSION.SDK_INT < 26 && getConnectionUtils().getWifiManager().isWifiEnabled()
                    ||
                    getConnectionUtils().hasLocationPermission(getConnectionUtils().getContext())
                    && getConnectionUtils().isLocationServiceEnabled()
                    && getConnectionUtils().getWifiManager().isWifiEnabled()) {

                if (mTitleProvided.equals(getString(R.string.text_receive))) {
                    startActivity(new Intent(this, ConnectionManagerActivity.class)
                            .putExtra(ConnectionManagerActivity.EXTRA_ACTIVITY_SUBTITLE, getString(R.string.text_receive))
                            .putExtra(ConnectionManagerActivity.EXTRA_REQUEST_TYPE, ConnectionManagerActivity.RequestType.MAKE_ACQUAINTANCE.toString()));
                } else if (mTitleProvided.equals(getString(R.string.text_addDevicesToTransfer))) {

                    Intent intent = new Intent();
                    setResult(REQUEST_CODE_SETUP_DEVICE, intent);
                }

                finish();
            } else {
                new AlertDialog.Builder(this)
                        .setMessage(R.string.mesg_errortPermission)
                        .setPositiveButton(R.string.ok, (dialog, which) -> recreate())
                        .show();
            }
        });

    }

    public ConnectionUtils getConnectionUtils()
    {
        return mConnectionUtils;
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    private void validateLocationPermission() {

        if (!getConnectionUtils().hasLocationPermission(getConnectionUtils().getContext())) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION}, REQUEST_PERMISSION_LOCATION);
        } else if (!getConnectionUtils().isLocationServiceEnabled()) {
            startActivity(new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
        }

    }

    public void turnOnWiFi() {
        if (getConnectionUtils().getWifiManager().setWifiEnabled(true)) {
            Toast.makeText(this, R.string.mesg_turningWiFiOn, Toast.LENGTH_SHORT).show();
            wifi.setVisibility(View.GONE);
            wifiProgressBar.setVisibility(View.VISIBLE);
            wifiImageView.setVisibility(View.VISIBLE);
            if (Build.VERSION.SDK_INT < 26 || getConnectionUtils().hasLocationPermission(getConnectionUtils().getContext()) && getConnectionUtils().isLocationServiceEnabled()) {
                content_next.setVisibility(View.VISIBLE);
            }
            } else
            startActivity(new Intent(Settings.ACTION_WIFI_SETTINGS)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));

    }

    @Override
    protected void onResume() {
        super.onResume();
        if (Build.VERSION.SDK_INT < 26 || getConnectionUtils().hasLocationPermission(getConnectionUtils().getContext()) && getConnectionUtils().isLocationServiceEnabled()) {
            location.setVisibility(View.GONE);
            mProgressBar.setVisibility(View.VISIBLE);
            mImageView.setVisibility(View.VISIBLE);
        } else {
            location.setVisibility(View.VISIBLE);
            mProgressBar.setVisibility(View.GONE);
            mImageView.setVisibility(View.GONE);
        }

        if (getConnectionUtils().getWifiManager().isWifiEnabled()) {
            wifi.setVisibility(View.GONE);
            wifiProgressBar.setVisibility(View.VISIBLE);
            wifiImageView.setVisibility(View.VISIBLE);
        } else {
            wifi.setVisibility(View.VISIBLE);
            wifiProgressBar.setVisibility(View.GONE);
            wifiImageView.setVisibility(View.GONE);
        }

        if (Build.VERSION.SDK_INT < 26 && getConnectionUtils().getWifiManager().isWifiEnabled()
                ||
                getConnectionUtils().hasLocationPermission(getConnectionUtils().getContext())
                        && getConnectionUtils().isLocationServiceEnabled()
                        && getConnectionUtils().getWifiManager().isWifiEnabled()) {

            content_next.setVisibility(View.VISIBLE);
        } else {
            content_next.setVisibility(View.GONE);
        }

    }

}
