package com.leaf.explorer.leaf_music;

import android.net.Uri;

public class Song {
    private final String TAG="Song";
    private Uri data;
    private long id;
    private String title;
    private String artist;

    public Song() {}

    public Song(long songID, String songTitle, String songArtist, Uri artData) {
        id=songID;
        title=songTitle;
        artist=songArtist;
        data=artData;
    }


    public long getID(){return id;}
    public String getTitle(){return title;}
    public String getArtist(){return artist;}
    public Uri getData(){return data;}

    public void setID(long its_id){this.id=its_id;}
    public void setTitle(String name){this.title=name;}
    public void setArtist(String its_artist){this.artist=its_artist;}
    public void setData(Uri its_data){this.data=its_data;}
}
