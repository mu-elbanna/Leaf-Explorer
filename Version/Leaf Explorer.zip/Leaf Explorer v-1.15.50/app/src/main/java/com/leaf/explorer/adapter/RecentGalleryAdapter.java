package com.leaf.explorer.adapter;

import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.provider.MediaStore;
import android.text.format.DateUtils;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.leaf.explorer.file_share.base.GlideApp;
import com.leaf.explorer.file_share.util.TimeUtils;
import com.leaf.explorer.R;
import com.leaf.explorer.file_share.widget.GalleryGroupEditableListAdapter;
import com.leaf.explorer.file_share.widget.GroupEditableListAdapter;

import java.io.File;

public class RecentGalleryAdapter
        extends GalleryGroupEditableListAdapter<RecentGalleryAdapter.RecentHolder, GroupEditableListAdapter.GroupViewHolder>
{

    private final ContentResolver mResolver;

    public RecentGalleryAdapter(Context context)
    {
        super(context, MODE_GROUP_BY_DATE);
        mResolver = context.getContentResolver();
    }

    @Override
    protected void onLoad(GroupLister<RecentHolder> lister)
    {

        Uri collection = MediaStore.Files.getContentUri("external");

        long MAX_HISTORY_IN_MILLIS = 15 * DateUtils.DAY_IN_MILLIS;
        long cutoff = System.currentTimeMillis() - MAX_HISTORY_IN_MILLIS;

        Cursor cursor = mResolver.query(collection,
                null,
                MediaStore.Files.FileColumns.DATE_TAKEN + ">" + cutoff,
                null,
                null);

        if (cursor != null) {
            if (cursor.moveToFirst()) {
                int idIndex = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns._ID);
                int titleIndex = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.TITLE);
                int displayIndex = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.DISPLAY_NAME);
                int folderIndex = cursor.getColumnIndex(MediaStore.Files.FileColumns.DATA);
                int dateAddedIndex = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.DATE_MODIFIED);
                int sizeIndex = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.SIZE);
                int typeIndex = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.MIME_TYPE);

                do {
                    RecentHolder holder = new RecentHolder(
                            cursor.getLong(idIndex),
                            cursor.getString(titleIndex),
                            cursor.getString(displayIndex),
                            extractFolderName(cursor.getString(folderIndex)),
                            cursor.getString(typeIndex),
                            cursor.getLong(dateAddedIndex) * 1000,
                            cursor.getLong(sizeIndex),
                            Uri.parse(collection + "/" + cursor.getInt(idIndex)));

                    holder.dateTakenString = String.valueOf(TimeUtils.formatDateTime(getContext(), holder.date));

                    lister.offerObliged(this, holder);
                }
                while (cursor.moveToNext());
            }

            cursor.close();
        }
    }

    public String extractFolderName(String folder)
    {
        if (folder.contains(File.separator)) {
            String[] split = folder.split(File.separator);

            if (split.length >= 2)
                folder = split[split.length - 2];
        }

        return folder;
    }

    @NonNull
    @Override
    public GroupViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType)
    {
        if (viewType == VIEW_TYPE_REPRESENTATIVE)
            return new GroupViewHolder(getInflater().inflate(R.layout.view_title, parent, false),
                    R.id.layout_list_title_text);

        return new GroupViewHolder(getInflater().inflate(isGridLayoutRequested()
                ? R.layout.row_image_grid
                : R.layout.row_image, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull GroupViewHolder holder, int position)
    {
        try {
            final View parentView = holder.getView();
            final RecentHolder object = getItem(position);

            if (!holder.tryBinding(object)) {
                ViewGroup container = parentView.findViewById(R.id.container);
                ImageView image = parentView.findViewById(R.id.image);
                ImageView video = parentView.findViewById(R.id.video);
                TextView text1 = parentView.findViewById(R.id.text);
                TextView text2 = parentView.findViewById(R.id.text2);
                FrameLayout selectorContainer = parentView.findViewById(R.id.selectorContainer);

               // selectorContainer.setVisibility(View.GONE);
                text1.setText(object.friendlyName);
                text2.setText(object.dateTakenString);

                if (object.mimeType.startsWith("video/")) {
                    video.setVisibility(View.VISIBLE);
                } else {
                    video.setVisibility(View.GONE);
                }

                parentView.setSelected(object.isSelectableSelected());

                GlideApp.with(getContext())
                        .load(object.uri)
                        .override(300)
                        .centerCrop()
                        .into(image);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    protected RecentHolder onGenerateRepresentative(String representativeText)
    {
        return new RecentHolder(representativeText);
    }

    @Override
    public boolean isGridSupported()
    {
        return true;
    }

    public static class RecentHolder extends GalleryGroupEditableListAdapter.GalleryGroupShareable
    {
        public String dateTakenString;

        public RecentHolder(String representativeText)
        {
            super(VIEW_TYPE_REPRESENTATIVE, representativeText);
        }

        public RecentHolder(long id, String title, String fileName, String albumName, String mimeType, long date, long size, Uri uri)
        {
            super(id, title, fileName, albumName, mimeType, date, size, uri);
        }
    }

}