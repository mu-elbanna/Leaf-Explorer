package com.leaf.explorer.file_share.p2p_ble;

import android.content.Context;
import android.net.wifi.p2p.WifiP2pDevice;
import android.net.wifi.p2p.WifiP2pInfo;
import android.net.wifi.p2p.WifiP2pManager;

import java.util.Collection;

import static android.os.Looper.getMainLooper;

public class WifiP2pHotspot {

    private final WifiP2pManager wifiP2pManager;
    private final WifiP2pManager.Channel channel;

    public WifiP2pHotspot(Context context) {

        wifiP2pManager = (WifiP2pManager) context.getApplicationContext().getSystemService(Context.WIFI_P2P_SERVICE);
        DirectActionListener directActionListener = new DirectActionListener() {

            @Override
            public void onChannelDisconnected() {

            }

            @Override
            public void wifiP2pEnabled(boolean enabled) {

            }

            @Override
            public void onConnectionInfoAvailable(WifiP2pInfo wifiP2pInfo) {

            }

            @Override
            public void onDisconnection() {

            }

            @Override
            public void onSelfDeviceAvailable(WifiP2pDevice wifiP2pDevice) {

            }

            @Override
            public void onPeersAvailable(Collection<WifiP2pDevice> wifiP2pDeviceList) {

            }
        };
        channel = wifiP2pManager.initialize(context, getMainLooper(), directActionListener);
    }

    public void removeGroup() {
        wifiP2pManager.removeGroup(channel, new WifiP2pManager.ActionListener() {
            @Override
            public void onSuccess() {
            }

            @Override
            public void onFailure(int reason) {
            }
        });
    }
}
