package com.leaf.explorer.leaf_music;

import androidx.fragment.app.Fragment;

import android.app.ActivityManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import android.util.Log;

import com.leaf.explorer.R;
import com.leaf.explorer.app.AppActivity;

public class MusicActivity extends AppActivity /*implements MediaController.MediaPlayerControl*/ {

    private final String TAG="MusicActivity";

    public MusicService musicService;
    private Intent playIntent;
    private boolean musicBound=false;
   // private  MusicController controller;
    private boolean paused = false, playbackPaused = false;
    private  boolean firstTimePlay = false;

    private Fragment controllerFragmet;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        /*  setController();*/
        controllerFragmet = new ControllerFragment();
        setContentView(R.layout.activity_main);

        /*
        Intent intent = getIntent();
        String action = intent.getAction();
        String type = intent.getType();

        if (Intent.ACTION_VIEW.equals(action) && type != null) {

            if (type.startsWith("audio/")) {
                Uri mUri = intent.getData();

            }
        }
         */
        Log.d(TAG, "onCreate invoked :");

        if (!isMyMusicServiceRunning()) {
            playIntent = new Intent(getApplicationContext(), MusicService.class);
            bindService(playIntent, musicConnection, Context.BIND_AUTO_CREATE);
            startService(playIntent);
            Log.d(TAG, "onCreate: service created in oncreate ");
        } else {
            firstTimePlay = true;
        }
        /*     setController();*/

        /*
        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.frame_container, new SongListFragment())
                .commit();

         */
    }

    private boolean isMyMusicServiceRunning() {
        ActivityManager manager = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
        for (ActivityManager.RunningServiceInfo service : manager.getRunningServices(Integer.MAX_VALUE)) {
            if (MusicService.class.getName().equals(service.service.getClassName())) {
                return true;
            }
        }
        return false;
    }

    public MusicService getInstanceOfService()
    {
        return musicService;
    }

    private final ServiceConnection musicConnection = new ServiceConnection(){
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            MusicService.MusicBinder binder = (MusicService.MusicBinder)service;
            musicService = binder.getService();
            musicBound = true;
            Log.d(TAG, "onServiceConnected: invoked");

            getSupportFragmentManager().beginTransaction().replace(R.id.frame_container, new SongListFragment()).commit();
            getSupportFragmentManager().beginTransaction().replace(R.id.music_controller_container, controllerFragmet).commit();
        }


        @Override
        public void onServiceDisconnected(ComponentName name) {
            musicBound = false;

        }
    };



    @Override
    protected void onStart() {

        super.onStart();
        Log.d(TAG, "onStart invoked");
        if(!isMyMusicServiceRunning()){
            playIntent = new Intent(getApplicationContext(), MusicService.class);
            bindService(playIntent, musicConnection, Context.BIND_AUTO_CREATE);
            startService(playIntent);
            Log.d(TAG, "onStart MusicActivity: service started and binded again ");
        }
        if(!musicBound && isMyMusicServiceRunning()) {
            playIntent = new Intent(getApplicationContext(), MusicService.class);
            Log.d(TAG, "onStart: service binded again");
            bindService(playIntent, musicConnection, Context.BIND_AUTO_CREATE);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.d(TAG,"onResume invoked");
        if(paused){
            /*   setController();*/
            paused = false;
        }
        if(musicService != null) Log.d(TAG, " onResume: music service is not null ");
        else Log.d(TAG, "onResume: music service is null");


    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.d(TAG,"onPause invoked");
        paused = true;
        playbackPaused = true;
    }

    @Override
    protected void onStop() {
        Log.d(TAG,"onStop invoked");
        /*     if(controller.isShowing())controller.hide();*/
        if(musicBound && musicService != null) { Log.d(TAG, "onStop: service unbinded here ");
            unbindService(musicConnection);
            musicBound = false;}

        super.onStop();
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        Log.d(TAG,"onRestart invoked");
    }


    @Override
    protected void onDestroy() {
        Log.d(TAG,"onDestroy invoked");
        super.onDestroy();
    }

/*    public void setController(){
        if(controller==null) controller = new MusicController(MusicActivity.this);
        controller.setPrevNextListeners(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                musicService.playNext();
            }
        }, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                musicService.playPrev();
            }
        });
        controller.setMediaPlayer(this);
        controller.setAnchorView(findViewById(R.id.song_list));
        controller.setEnabled(true);
        Log.d(TAG, "setController: called");
    }

    public void songPicked(View v){
        controller.show();
        Log.d(TAG, "songPicked: controller showing: "+ controller.isShowing());
    }



    @Override
    public void start() {
        musicService.go();
        musicService.songPlaying=true;
        musicService.startNotification();
        setController();
    }


    @Override
    public void pause() {
        musicService.songPlaying=false;
        musicService.pausePlayer();
        musicService.startNotification();
        setController();
    }

    @Override
    public int getDuration() {
        if(musicService!=null && musicBound && musicService.isPng())
        return musicService.getDur();
        else return 0;
    }

    @Override
    public int getCurrentPosition() {
        if(musicService!=null && musicBound && musicService.isPng())
        return musicService.getPosn();
  else return 0;
    }

    @Override
    public void seekTo(int pos) {
        musicService.seek(pos);
    }

    @Override
    public boolean isPlaying() {
        if(musicService!=null && musicBound)
        {musicService.songPlaying=true;
            return musicService.isPng();
        }
      else  return false;
    }

    @Override
    public int getBufferPercentage() {
        return 0;
    }

    @Override
    public boolean canPause() {
        return true;
    }

    @Override
    public boolean canSeekBackward() {
        return true;
    }

    @Override
    public boolean canSeekForward() {
        return true;
    }

    @Override
    public int getAudioSessionId() {
        return 0;
    }*/

}