package com.example_gallary.activity;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.RelativeLayout;

import androidx.appcompat.app.AlertDialog;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.genonbeta.android.framework.io.DocumentFile;
import com.github.chrisbanes.photoview.PhotoView;
import com.leaf.explorer.R;
import com.leaf.explorer.app.AppActivity;
import com.leaf.explorer.file_share.util.FileUtils;

import java.io.FileNotFoundException;

public class MediaBrowser extends AppActivity {

    PhotoView photoView;
    Uri imageUri;
    // String url;
    String type;
    private boolean bottomSheet = true;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.media_pager);

        Intent intent = getIntent();
        String action = intent.getAction();
        type = intent.getType();

        if (Intent.ACTION_VIEW.equals(action) && type != null) {

            if (type.startsWith("image/")) {
                // if (type.startsWith("image/") || type.startsWith("video/")) {
                this.imageUri = intent.getData();
                //  url = convertMediaUriToPath(imageUri);
            }
        }
        runOnUiThread(this::initMediaView);
    }

    @Override
    public void onPause() {
        super.onPause();
    }

    private void initMediaView() {

        photoView = findViewById(R.id.photoView);
        RelativeLayout layout_Bottom = findViewById(R.id.layout_Bottom);
        ImageButton layout_Info = findViewById(R.id.layout_Info);
        ImageButton layout_Delete = findViewById(R.id.layout_Delete);

        ColorDrawable transparentDrawable = new ColorDrawable(Color.TRANSPARENT);

        Glide.with(this)
                .load(imageUri)
                // .crossFade()
                .placeholder(transparentDrawable)
                .diskCacheStrategy(DiskCacheStrategy.NONE)
                .into(photoView);

        photoView.setOnClickListener(v -> {
            if (!bottomSheet) {
                layout_Bottom.setVisibility(View.VISIBLE);
                bottomSheet = true;
            } else {
                layout_Bottom.setVisibility(View.GONE);
                bottomSheet = false;
            }
        });
        layout_Info.setOnClickListener(v -> {
            try {
                DocumentFile current_song = FileUtils.fromUri(this, imageUri);
                String title = current_song.getName();

                AlertDialog.Builder mDialog = new AlertDialog.Builder(this);
                mDialog.setTitle("Information");
                mDialog.setMessage("Name : " + title + "\n\n"
                        + "Path : " + current_song.getUri().getPath() + "\n\n"
                        + "Size : " + FileUtils.sizeExpression(current_song.length(), false) + "\n\n");
                mDialog.setPositiveButton("Ok", null);
                AlertDialog alertDialog = mDialog.create();

                alertDialog.show();
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
        });

        layout_Delete.setOnClickListener(v -> {
        });
    }

    /*
    protected String convertMediaUriToPath(Uri uri) {

        String filePath = "";

        Cursor cursor = this.getContentResolver().query(uri, new String[]{MediaStore.MediaColumns.DATA}, null, null, null);

        if (cursor != null) {
            cursor.moveToFirst();
            filePath = cursor.getString(0);
            cursor.close();
        }

        return filePath;
    }

     */
}
