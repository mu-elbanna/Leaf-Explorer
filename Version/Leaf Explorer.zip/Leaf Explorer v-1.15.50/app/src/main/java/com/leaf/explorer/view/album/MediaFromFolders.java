package com.leaf.explorer.view.album;

import java.io.File;
import java.io.FilenameFilter;

public class MediaFromFolders {

    public static final String[] EXTENSIONS = new String[]{
            "mp3"
    };

    public static final FilenameFilter MEDIA_FILTER = (dir, name) -> {
        for (final String ext : EXTENSIONS) {
            if (name.endsWith("." + ext)) {
                return (true);
            }
        }
        return false;
    };

    public static String[] listMedia(String path) {

        File[] listFile;

        String[] FilePathStrings;

        File file = new File(path);

        listFile = file.listFiles(MEDIA_FILTER);

        FilePathStrings = new String[listFile.length];

        for (int i = 0; i < listFile.length; i++) {

            FilePathStrings[i] = listFile[i].getAbsolutePath();

        }

        return FilePathStrings;

    }
}
