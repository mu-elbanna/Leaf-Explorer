package com.leaf.explorer.view.album;

import android.app.Activity;
import android.database.Cursor;
import android.net.Uri;
import android.provider.MediaStore;

import java.io.File;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

public class FoldersUtils {

    public static ArrayList<Folders> getAllAlbums(Activity activity) {

        Uri externalImagesUri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
        String imageData = MediaStore.Audio.Media.DATA;
        String imagePath = MediaStore.Audio.Media.DISPLAY_NAME;

        ArrayList<Folders> allAlbums = new ArrayList<>();

        Cursor cursor;
        int column_index_data;

        String absolutePathOfAlbums;

        String[] ImagesProjection = {imageData, imagePath};

        cursor = activity.getContentResolver().query(externalImagesUri, ImagesProjection, null,
                null, null);

        if (cursor != null) {
            column_index_data = cursor.getColumnIndexOrThrow(imageData);

            while (cursor.moveToNext()) {

                absolutePathOfAlbums = cursor.getString(column_index_data);

                Folders media = new Folders();

                media.setAlbumsUrl(absolutePathOfAlbums);

                allAlbums.add(media);

            }
        }

        return allAlbums;
    }

    public static String getFolderName(String path) {

        File folderName = new File(path);

        return folderName.getName();

    }

    public static String[] initFolders(Activity activity, ArrayList<Folders> albumsList) {

        int mediaSize = albumsList.size();

        String[] albumsPath = new String[mediaSize];

        Set<String> paths = new HashSet<>();

        for (int i = 0; i < albumsList.size(); i++) {

            albumsPath[i] = albumsList.get(i).getAlbumsPath();

            paths.add(albumsPath[i]);
        }

        return paths.toArray(new String[paths.size()]);
    }
}
