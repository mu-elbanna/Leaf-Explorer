package com.leaf.explorer.leaf_music;

import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.Intent;
import android.database.Cursor;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import androidx.fragment.app.Fragment;

import com.genonbeta.android.framework.io.DocumentFile;
import com.leaf.explorer.R;
import com.leaf.explorer.file_share.util.FileUtils;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Collections;

public class SongListFragment extends Fragment {

    private final ArrayList<Song> songList = new ArrayList<>();
    private MusicActivity instanceOfMainactivity;
    private MusicService musicService;

    int pos;
    String[] mUrls;
    boolean play = false;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View viewSongFragment = inflater.inflate(R.layout.fragment_song, container, false);

        ListView songView = viewSongFragment.findViewById(R.id.song_list);

        Intent intent = requireActivity().getIntent();

        mUrls = intent.getExtras().getStringArray("urls");
        pos = intent.getExtras().getInt("pos");
        play = intent.getExtras().getBoolean("play");

        for (String SongUrl : mUrls) {
            DocumentFile mSongUrl = DocumentFile.fromFile(new File(SongUrl));
            MediaMetadataRetriever mmr = new MediaMetadataRetriever();
            mmr.setDataSource(getContext(), mSongUrl.getUri());

            String title = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE);
            String artist = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST);
            if (title == null) {
                try {
                    DocumentFile current_song = FileUtils.fromUri(getContext(), mSongUrl.getUri());
                    title = current_song.getName();
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                }
            }
            if (artist == null) {
                artist = "<Unknown>";
            }

            songList.add(new Song(SongUrl.length(),
                    title,
                    artist,
                    mSongUrl.getUri()));
        }

        instanceOfMainactivity = (MusicActivity) getActivity();
        if (instanceOfMainactivity != null && instanceOfMainactivity.getInstanceOfService() != null) {
            musicService = instanceOfMainactivity.getInstanceOfService();

            if (mUrls != null) {
                musicService.setList(songList);
                musicService.setSong(pos);
                musicService.playDefault();
            } else {
                getSongList();
                musicService.setList(songList);
            }
        }

        Collections.sort(songList, (a, b) -> a.getTitle().compareTo(b.getTitle()));

        SongAdapter songAdapter = new SongAdapter(getContext(), songList);
        songAdapter.setOnItemClickListener((parent, view, position, id) -> {

            musicService.setSong(position);
            musicService.songPlaying = true;
            musicService.playSong();
        });
        songView.setAdapter(songAdapter);
        songView.setSmoothScrollbarEnabled(true);

        return viewSongFragment;
    }

    protected void getSongList() {

        ContentResolver musicResolver = requireActivity().getContentResolver();
        Uri musicUri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
        Cursor musicCursor = musicResolver.query(musicUri, null, null, null, null);

        if(musicCursor != null && musicCursor.moveToFirst()){
            int titleColumn = musicCursor.getColumnIndex(android.provider.MediaStore.Audio.Media.TITLE);
            int idColumn = musicCursor.getColumnIndex(android.provider.MediaStore.Audio.Media._ID);
            int artistColumn = musicCursor.getColumnIndex(android.provider.MediaStore.Audio.Media.ARTIST);
            int dataColumn=musicCursor.getColumnIndex(MediaStore.Audio.Media.DATA);
            do {
                long thisId = musicCursor.getLong(idColumn);
                String thisTitle = musicCursor.getString(titleColumn);
                String thisArtist = musicCursor.getString(artistColumn);
                String thisData = musicCursor.getString(dataColumn);
                Uri trackUri = ContentUris.withAppendedId(android.provider.MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, thisId);
                songList.add(new Song(thisId, thisTitle, thisArtist, trackUri));
            }
            while (musicCursor.moveToNext());
        }

    }

    @Override
    public void onStart() {
        if (musicService == null && instanceOfMainactivity.getInstanceOfService() != null) {
            musicService = instanceOfMainactivity.getInstanceOfService();
            musicService.setList(songList);
        }
        String TAG = "SongListFragment";
        if (musicService == null) Log.d(TAG, "onStart: music service is null");
        else Log.d(TAG, "onStart: Music service is not null");
        super.onStart();
    }
}
