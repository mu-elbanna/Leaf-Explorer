package com.leaf.explorer.config;

public class AppConfig
{
    public final static int
            SERVER_PORT_WEBSHARE = 58732;

    public final static String
            SHOW_HIDDEN = "show_hidden";

}
