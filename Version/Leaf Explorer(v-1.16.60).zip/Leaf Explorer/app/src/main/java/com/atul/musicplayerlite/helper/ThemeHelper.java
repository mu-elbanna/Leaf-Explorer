package com.atul.musicplayerlite.helper;


import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.util.TypedValue;

import androidx.core.content.ContextCompat;

import com.atul.musicplayerlite.MainActivity;

public class ThemeHelper {

    public static void applySettings(Activity activity) {
        Intent intent = new Intent(activity, MainActivity.class);
        intent.setFlags(
                Intent.FLAG_ACTIVITY_CLEAR_TOP |
                        Intent.FLAG_ACTIVITY_CLEAR_TASK |
                        Intent.FLAG_ACTIVITY_NEW_TASK
        );

        activity.finishAfterTransition();
        activity.startActivity(intent);
        activity.overridePendingTransition(
                android.R.anim.fade_in,
                android.R.anim.fade_out
        );
    }

    public static int resolveColorAttr(Context context, int attr) {
        TypedValue resolveTheme = resolveThemeAttr(context, attr);
        int color = resolveTheme.resourceId != 0
                ? resolveTheme.resourceId : resolveTheme.data;

        return ContextCompat.getColor(context, color);
    }

    private static TypedValue resolveThemeAttr(Context context, int attr) {
        TypedValue typedValue = new TypedValue();
        context.getTheme().resolveAttribute(attr, typedValue, true);
        return typedValue;
    }
}
