package com.leaf.explorer.file_share.fragment;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.genonbeta.android.framework.app.Fragment;
import com.leaf.explorer.R;
import com.leaf.explorer.file_share.model.TitleSupport;
import com.leaf.explorer.file_share.util.IconSupport;
import com.leaf.explorer.file_share.view.RadarScanView;

public class P2PDiscoverCustomFragment extends Fragment
        implements TitleSupport, IconSupport {

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        final View view = inflater.inflate(R.layout.fragment_p2p_discover_custom, container, false);

        RadarScanView radarView;
        radarView = view.findViewById(R.id.radar);
        radarView.start();

        return view;
    }

    @Override
    public int getIconRes()
    {
        return R.drawable.ic_wifi_white_24dp;
    }

    @Override
    public CharSequence getTitle(Context context)
    {
        return context.getString(R.string.text_connectDevices);
    }

}
