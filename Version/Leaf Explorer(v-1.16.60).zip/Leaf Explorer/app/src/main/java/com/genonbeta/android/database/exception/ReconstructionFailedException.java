package com.genonbeta.android.database.exception;

public class ReconstructionFailedException extends Exception
{
    public ReconstructionFailedException(String message) {
        super(message);
    }
}
