package com.leaf.explorer.fragments.recent;

import android.content.Context;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.genonbeta.android.framework.widget.PowerfulActionMode;
import com.leaf.explorer.adapter.RecentGalleryAdapter;
import com.leaf.explorer.file_share.view.GalleryGroupEditableListFragment;
import com.leaf.explorer.file_share.model.TitleSupport;
import com.leaf.explorer.file_share.util.AppUtils;
import com.leaf.explorer.R;
import com.leaf.explorer.file_share.widget.GroupEditableListAdapter;
import com.leaf.explorer.view.ActionModeCallback;

import java.util.List;

public class RecentGalleryList
        extends GalleryGroupEditableListFragment<RecentGalleryAdapter.RecentHolder, GroupEditableListAdapter.GroupViewHolder, RecentGalleryAdapter>
        implements TitleSupport {

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);

        setFilteringSupported(true);
        setDefaultOrderingCriteria(RecentGalleryAdapter.MODE_SORT_ORDER_DESCENDING);
        setDefaultSortingCriteria(RecentGalleryAdapter.MODE_SORT_BY_DATE);
        setDefaultViewingGridSize(3, 6);
        setUseDefaultPaddingDecoration(false);

        setDefaultSelectionCallback(new SelectionCallback(this));
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState)
    {
        super.onViewCreated(view, savedInstanceState);

        setEmptyImage(R.drawable.ic_history);
        setEmptyText(getString(R.string.text_empty));
    }

    @Override
    public void onResume()
    {
        super.onResume();

        requireContext().getContentResolver()
                .registerContentObserver(MediaStore.Files.getContentUri("external"), true, getDefaultContentObserver());
    }

    @Override
    public void onPause()
    {
        super.onPause();

        requireContext().getContentResolver()
                .unregisterContentObserver(getDefaultContentObserver());
    }

    @Override
    public RecentGalleryAdapter onAdapter()
    {
        final AppUtils.QuickActions<GroupEditableListAdapter.GroupViewHolder> quickActions = clazz -> {
            if (!clazz.isRepresentative()) {
                registerLayoutViewClicks(clazz);

                View visitView = clazz.getView().findViewById(R.id.visitView);
                visitView.setOnClickListener(
                        v -> performLayoutClickOpen(clazz));
                visitView.setOnLongClickListener(v -> performLayoutLongClick(clazz));

                clazz.getView().findViewById(getAdapter().isGridLayoutRequested()
                        ? R.id.selectorContainer : R.id.selector)
                        .setOnClickListener(v -> {
                            if (getSelectionConnection() != null)
                                getSelectionConnection().setSelected(clazz.getAdapterPosition());
                        });
            }
        };

        return new RecentGalleryAdapter(getActivity())
        {
            @NonNull
            @Override
            public GroupViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType)
            {
                return AppUtils.quickAction(super.onCreateViewHolder(parent, viewType), quickActions);
            }
        };
    }

    @Override
    public boolean onDefaultClickAction(GroupEditableListAdapter.GroupViewHolder holder)
    {
        return getSelectionConnection() != null
                ? getSelectionConnection().setSelected(holder)
                : performLayoutClickOpen(holder);
    }

    @Override
    public CharSequence getTitle(Context context)
    {
        return context.getString(R.string.text_gallery);
    }

    public boolean handleEditingAction(int id, final RecentGalleryList fragment, List<RecentGalleryAdapter.RecentHolder> selectedItemList) {

        if (id == R.id.action_mode_file_delete) {
            Toast.makeText(getContext(), "Success", Toast.LENGTH_SHORT).show();
        } else
            return true;

        return false;
    }


    private class SelectionCallback extends ActionModeCallback<RecentGalleryAdapter.RecentHolder>
    {
        private final RecentGalleryList mFragment;

        public SelectionCallback(RecentGalleryList fragment)
        {
            super(fragment);
            mFragment = fragment;
        }

        @Override
        public boolean onCreateActionMenu(Context context, PowerfulActionMode actionMode, Menu menu)
        {
            super.onCreateActionMenu(context, actionMode, menu);
            actionMode.getMenuInflater().inflate(R.menu.selection_mode_recent_gallery, menu);

            return true;
        }

        @Override
        public boolean onActionMenuItemSelected(Context context, PowerfulActionMode actionMode, MenuItem item)
        {
            int id = item.getItemId();

            if (getFragment().getSelectionConnection().getSelectedItemList().size() == 0)
                return super.onActionMenuItemSelected(context, actionMode, item);

            if (handleEditingAction(id, mFragment, getFragment().getSelectionConnection().getSelectedItemList()))
                return super.onActionMenuItemSelected(context, actionMode, item);

            return true;
        }
    }
}
