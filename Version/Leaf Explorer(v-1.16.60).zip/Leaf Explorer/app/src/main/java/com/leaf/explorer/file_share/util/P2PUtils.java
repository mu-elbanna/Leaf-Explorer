package com.leaf.explorer.file_share.util;

import static android.content.Context.WIFI_P2P_SERVICE;
import static android.os.Looper.getMainLooper;

import android.annotation.SuppressLint;
import android.content.Context;
import android.net.wifi.p2p.WifiP2pDevice;
import android.net.wifi.p2p.WifiP2pInfo;
import android.net.wifi.p2p.WifiP2pManager;

import com.leaf.explorer.file_share.p2p_ble.DirectActionListener;

import java.util.Collection;

abstract public class P2PUtils {
   // private static final String TAG = "P2PUtils";

    private final WifiP2pManager wifiP2pManager;
    private final WifiP2pManager.Channel channel;
    private static P2PUtils mInstance = null;

    DirectActionListener directActionListener = new DirectActionListener() {

        @Override
        public void onChannelDisconnected() {

        }

        @Override
        public void wifiP2pEnabled(boolean enabled) {

        }

        @Override
        public void onConnectionInfoAvailable(WifiP2pInfo wifiP2pInfo) {

        }

        @Override
        public void onDisconnection() {

        }

        @Override
        public void onSelfDeviceAvailable(WifiP2pDevice wifiP2pDevice) {

        }

        @Override
        public void onPeersAvailable(Collection<WifiP2pDevice> wifiP2pDeviceList) {

        }
    };

    private P2PUtils(Context context)
    {
        wifiP2pManager = (WifiP2pManager) context.getApplicationContext().getSystemService(WIFI_P2P_SERVICE);
        channel = wifiP2pManager.initialize(context, getMainLooper(), directActionListener);
    }

    public static P2PUtils getInstance(Context context)
    {
        if (mInstance == null)
            mInstance = new P2PAPI(context);

        return mInstance;
    }

    public WifiP2pManager getWifiP2pManager()
    {
        return wifiP2pManager;
    }

    public WifiP2pManager.Channel getWifiP2PChannel()
    {
        return channel;
    }

    abstract public boolean enable();
    abstract public void disable();

    abstract public boolean isEnabled();


    public static class P2PAPI extends P2PUtils
    {
        private boolean p2pStarted = false;

        private P2PAPI(Context context)
        {
            super(context);
        }

        @SuppressLint("MissingPermission")
        @Override
        public boolean enable()
        {
            try {
                getWifiP2pManager().createGroup(getWifiP2PChannel(), new WifiP2pManager.ActionListener() {
                    @Override
                    public void onSuccess() {
                        p2pStarted = true;
                    }

                    @Override
                    public void onFailure(int reason) {
                    }
                });
            } catch (Throwable e) {
                e.printStackTrace();
            }

            return false;

        }

        @Override
        public void disable()
        {
            getWifiP2pManager().removeGroup(getWifiP2PChannel(), new WifiP2pManager.ActionListener() {
                @Override
                public void onSuccess() {
                    p2pStarted = false;
                }

                @Override
                public void onFailure(int reason) {
                }
            });
        }

        @Override
        public boolean isEnabled()
        {
            return p2pStarted;
        }
    }
}
