package com.leaf.explorer.app;

import android.app.Application;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;

import com.leaf.explorer.R;
import com.leaf.explorer.util.AppUtils;
import com.leaf.explorer.util.PreferenceUtils;
import com.genonbeta.android.framework.preference.DbSharablePreferences;

public class App extends Application
{
    public static final String TAG = App.class.getSimpleName();
    public static final String ACTION_REQUEST_PREFERENCES_SYNC = "com.leaf.explorer.intent.action.REQUEST_PREFERENCES_SYNC";

    private final BroadcastReceiver mReceiver = new BroadcastReceiver()
    {
        @Override
        public void onReceive(Context context, Intent intent)
        {
            if (intent != null)
                if (ACTION_REQUEST_PREFERENCES_SYNC.equals(intent.getAction())) {
                    SharedPreferences preferences = AppUtils.getDefaultPreferences(context).getWeakManager();

                    if (preferences instanceof DbSharablePreferences)
                        ((DbSharablePreferences) preferences).sync();
                }
        }
    };

    @Override
    public void onCreate()
    {
        super.onCreate();

        initializeSettings();
        getApplicationContext().registerReceiver(mReceiver, new IntentFilter(ACTION_REQUEST_PREFERENCES_SYNC));

    }

    @Override
    public void onTerminate()
    {
        super.onTerminate();
        getApplicationContext().unregisterReceiver(mReceiver);
    }

    private void initializeSettings()
    {
        SharedPreferences defaultPreferences = AppUtils.getDefaultLocalPreferences(this);
        boolean nsdDefined = defaultPreferences.contains("nsd_enabled");

        PreferenceManager.setDefaultValues(this, R.xml.preferences_defaults_main, false);
        
        
        if (!nsdDefined)
            defaultPreferences.edit()
                    .putBoolean("nsd_enabled", true)
                    .apply();

        PreferenceUtils.syncDefaults(getApplicationContext());

    }
}
