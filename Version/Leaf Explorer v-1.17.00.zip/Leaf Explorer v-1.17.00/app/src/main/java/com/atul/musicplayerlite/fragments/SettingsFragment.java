package com.atul.musicplayerlite.fragments;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.atul.musicplayerlite.MPConstants;
import com.atul.musicplayerlite.MPPreferences;
import com.leaf.explorer.R;
import com.atul.musicplayerlite.activities.FolderDialog;
import com.atul.musicplayerlite.helper.ThemeHelper;
import com.atul.musicplayerlite.model.Folder;
import com.atul.musicplayerlite.viewmodel.MainViewModel;
import com.atul.musicplayerlite.viewmodel.MainViewModelFactory;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.switchmaterial.SwitchMaterial;

import java.util.ArrayList;
import java.util.List;

public class SettingsFragment extends Fragment implements View.OnClickListener {

    private MainViewModel viewModel;
    private boolean state;

    private MaterialToolbar toolbar;
    private FolderDialog folderDialog;

    public SettingsFragment() {
    }

    public static SettingsFragment newInstance() {
        return new SettingsFragment();
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        viewModel = new ViewModelProvider(requireActivity(), new MainViewModelFactory(requireActivity())).get(MainViewModel.class);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_settings, container, false);

        SwitchMaterial switchMaterial = view.findViewById(R.id.album_switch);
        toolbar = view.findViewById(R.id.toolbar);

        LinearLayout albumOption = view.findViewById(R.id.album_options);
        LinearLayout folderOption = view.findViewById(R.id.folder_options);
        LinearLayout refreshOption = view.findViewById(R.id.refresh_options);

        state = MPPreferences.getAlbumRequest(requireActivity().getApplicationContext());
        switchMaterial.setChecked(state);

        albumOption.setOnClickListener(this);
        switchMaterial.setOnClickListener(this);
        folderOption.setOnClickListener(this);
        refreshOption.setOnClickListener(this);

        setUpOptions();

        return view;

    }


    private void setUpOptions() {
        toolbar.setOnMenuItemClickListener(item -> {
            int id = item.getItemId();

            if (id == R.id.github) {
                startActivity(new Intent(
                        Intent.ACTION_VIEW,
                        Uri.parse(MPConstants.GITHUB_REPO_URL)
                ));
                return true;
            }

            return false;
        });
        toolbar.setNavigationOnClickListener(v -> requireActivity().finish());
    }

    @Override
    public void onClick(View v) {
        int id = v.getId();

        if (id == R.id.album_options)
            setAlbumRequest();

        else if (id == R.id.album_switch)
            setAlbumRequest();

        else if (id == R.id.folder_options)
            showFolderSelectionDialog();

        else if (id == R.id.refresh_options) {
            Toast.makeText(requireActivity(), "Looking ...", Toast.LENGTH_SHORT).show();
            ThemeHelper.applySettings(requireActivity());
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (folderDialog != null)
            folderDialog.dismiss();
    }

    private void showFolderSelectionDialog() {
        List<Folder> folderList = new ArrayList<>(viewModel.getFolders(false));
        folderDialog = new FolderDialog(requireActivity(), folderList);
        folderDialog.show();

        folderDialog.setOnDismissListener(dialog ->
                ThemeHelper.applySettings(requireActivity())
        );
    }

    private void setAlbumRequest() {
        MPPreferences.storeAlbumRequest(requireActivity().getApplicationContext(), (!state));
        ThemeHelper.applySettings(getActivity());
    }
}