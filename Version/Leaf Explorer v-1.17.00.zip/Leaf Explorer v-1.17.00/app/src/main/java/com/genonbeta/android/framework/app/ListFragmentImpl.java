package com.genonbeta.android.framework.app;

/**
 * created by: veli
 * date: 14/04/18 10:38
 */
public interface ListFragmentImpl<T> extends FragmentImpl
{
	void refreshList();
}
