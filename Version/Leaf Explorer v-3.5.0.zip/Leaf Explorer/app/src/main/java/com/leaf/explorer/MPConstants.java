package com.leaf.explorer;

import android.app.Activity;
import android.content.Intent;

import com.leaf.explorer.listener.MusicSelectListener;

import org.monora.uprotocol.client.android.R;

public class MPConstants {

    public static final int PERMISSION_READ_STORAGE = 1009;

    public static final String MEDIA_SESSION_TAG = "com.leaf.explorer.MediaSession";

    public static final int NOTIFICATION_ID = 101;
    public static final String PLAY_PAUSE_ACTION = "com.leaf.explorer.PLAYPAUSE";
    public static final String NEXT_ACTION = "com.leaf.explorer.NEXT";
    public static final String PREV_ACTION = "com.leaf.explorer.PREV";
    public static final String CLOSE_ACTION = "com.leaf.explorer.CLOSE";
    public static final String CHANNEL_ID = "com.leaf.explorer.CHANNEL_ID";
    public static final int REQUEST_CODE = 100;

    public static final float VOLUME_DUCK = 0.2f;
    public static final float VOLUME_NORMAL = 1.0f;
    public static final int AUDIO_NO_FOCUS_NO_DUCK = 0;
    public static final int AUDIO_NO_FOCUS_CAN_DUCK = 1;
    public static final int AUDIO_FOCUSED = 2;

    public static final int SORT_MUSIC_BY_TITLE = 0;
    public static final int SORT_MUSIC_BY_DATE_ADDED = 1;
    public static MusicSelectListener musicSelectListener;

    public static final int[] TAB_ICONS = new int[]{
            R.drawable.ic_notif_music_note,
            R.drawable.ic_folder_white_24dp,
    };

    public static void applySettings(Activity activity) {
        Intent intent = new Intent(activity, MusicActivity.class);
        intent.setFlags(
                Intent.FLAG_ACTIVITY_CLEAR_TOP |
                        Intent.FLAG_ACTIVITY_CLEAR_TASK |
                        Intent.FLAG_ACTIVITY_NEW_TASK
        );

        activity.finishAfterTransition();
        activity.startActivity(intent);
        activity.overridePendingTransition(
                android.R.anim.fade_in,
                android.R.anim.fade_out
        );
    }
}