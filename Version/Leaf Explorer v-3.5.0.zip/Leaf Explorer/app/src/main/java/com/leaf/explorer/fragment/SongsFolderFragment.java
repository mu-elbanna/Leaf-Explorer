package com.leaf.explorer.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.appbar.MaterialToolbar;
import com.leaf.explorer.adapter.SongsFolderAdapter;
import com.leaf.explorer.listener.MusicSelectListener;
import com.leaf.explorer.model.Folder;
import com.leaf.explorer.model.Music;
import com.leaf.explorer.model.SongsFolderModel;
import com.leaf.explorer.viewmodel.MainViewModel;
import com.leaf.explorer.viewmodel.MainViewModelFactory;

import org.monora.uprotocol.client.android.R;

import java.util.ArrayList;
import java.util.List;

public class SongsFolderFragment extends Fragment {

    private static MusicSelectListener listener;
    private ArrayList<SongsFolderModel> mArrayList;
    private MainViewModel viewModel;
    private List<Folder> folderList = new ArrayList<>();
    private MaterialToolbar toolbar;

    public static SongsFolderFragment newInstance(MusicSelectListener selectListener) {
        SongsFolderFragment.listener = selectListener;
        return new SongsFolderFragment();
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        viewModel = new ViewModelProvider(requireActivity(),
                new MainViewModelFactory(requireActivity())).get(MainViewModel.class);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_song_folder, container, false);

        folderList = viewModel.getFolders(false);
        toolbar = view.findViewById(R.id.folder_toolbar);

        RecyclerView mainRecyclerView = view.findViewById(R.id.folder_recycler_view);
        mainRecyclerView.setHasFixedSize(true);
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false);
        mainRecyclerView.setLayoutManager(layoutManager);

        insertData();

        SongsFolderAdapter homeItemAdapter = new SongsFolderAdapter(listener, mArrayList, getContext());
        mainRecyclerView.setAdapter(homeItemAdapter);

        setUpOptions();
        return view;
    }

    public boolean isScreenLandscape()
    {
        return getContext() != null &&
                getContext().getResources().getBoolean(R.bool.genfw_screen_isLandscape);
    }

    private void setUpOptions() {
        toolbar.setNavigationOnClickListener(v -> {
            requireActivity().finish();
        });
    }

    private void insertData() {
        mArrayList = new ArrayList<>();

        for (Folder path : folderList) {

            loadSongsFolderData(path.title, path.music.size(), path.music);
        }
    }

    private void loadSongsFolderData(String folderName, int size, List<Music> loadSongsList) {
        String folderDetails = "("+size+")" + " songs";
        if (getContext() != null) {
            mArrayList.add(new SongsFolderModel("normal", folderName, folderDetails, loadSongsList));
        }
    }
}
