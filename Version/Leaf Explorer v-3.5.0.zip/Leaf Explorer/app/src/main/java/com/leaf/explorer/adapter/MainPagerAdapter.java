package com.leaf.explorer.adapter;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.viewpager2.adapter.FragmentStateAdapter;

import com.leaf.explorer.fragment.SongsFolderFragment;
import com.leaf.explorer.fragment.SongsFragment;
import com.leaf.explorer.listener.MusicSelectListener;

public class MainPagerAdapter extends FragmentStateAdapter {

    private final MusicSelectListener selectListener;

    public MainPagerAdapter(FragmentActivity mFragmentActivity, MusicSelectListener selectListener) {
        super(mFragmentActivity);
        this.selectListener = selectListener;
    }

    @NonNull
    @Override
    public Fragment createFragment(int position) {
        switch (position) {
            case 0: {
                return SongsFragment.newInstance(selectListener);
            }
            case 1: {
                return SongsFolderFragment.newInstance(selectListener);
            }
            default:
                return SongsFragment.newInstance(selectListener);
        }
    }

    @Override
    public int getItemCount() {
        return 2;
    }
}
