package com.leaf.explorer.model;

import java.util.List;

public class SongsFolderModel {
    private String folderName;
    private String folderUrl;
    private String type;
    private final List<Music> loadSongsList;

    public SongsFolderModel(String type, String folderName, String folderUrl, List<Music> loadSongsList) {
        this.type = type;
        this.folderName = folderName;
        this.folderUrl = folderUrl;
        this.loadSongsList = loadSongsList;
    }

    public String getType() {
        return type;
    }

    public String getFolderName() {
        return folderName;
    }

    public String getFolderUrl() {
        return folderUrl;
    }

    public List<Music> getLoadSongsList() {
        return loadSongsList;
    }




    public void setType(String type) {
        this.type = type;
    }

    public void setFolderName(String folderName) {
        this.folderName = folderName;
    }

    public void setFolderUrl(String folderUrl) {
        this.folderUrl = folderUrl;
    }
}
