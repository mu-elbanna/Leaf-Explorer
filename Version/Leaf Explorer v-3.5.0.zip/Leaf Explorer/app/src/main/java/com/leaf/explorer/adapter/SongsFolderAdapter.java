package com.leaf.explorer.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.leaf.explorer.listener.MusicSelectListener;
import com.leaf.explorer.model.SongsFolderModel;

import org.monora.uprotocol.client.android.R;

import java.util.ArrayList;

public class SongsFolderAdapter extends RecyclerView.Adapter {

    public MusicSelectListener listener;
    private final ArrayList<SongsFolderModel> mArrayList;
    private final Context context;

    public SongsFolderAdapter(MusicSelectListener listener, ArrayList<SongsFolderModel> mArrayList, Context context) {
        this.listener = listener;
        this.mArrayList = mArrayList;
        this.context = context;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view;

        if (viewType == 1) {
            view = LayoutInflater.from(parent.getContext()).inflate(R.layout.song_folder, parent, false);
            return new FolderViewHolder(view);
        }
        return null;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {

        SongsFolderModel songFolderModel = mArrayList.get(position);

        if (songFolderModel != null) {
            if ("normal".equals(songFolderModel.getType())) {
                ((FolderViewHolder) holder).folderName.setText(mArrayList.get(position).getFolderName());

                if (!mArrayList.get(position).getFolderUrl().equals(""))
                    ((FolderViewHolder) holder).folderUrl.setText(mArrayList.get(position).getFolderUrl());
                else
                    ((FolderViewHolder) holder).folderUrl.setVisibility(View.GONE);

                ((FolderViewHolder) holder).folder_recycler_view.setHasFixedSize(true);
                RecyclerView.LayoutManager normalLayoutManager = new LinearLayoutManager(context, LinearLayoutManager.VERTICAL, false);
                ((FolderViewHolder) holder).folder_recycler_view.setLayoutManager(normalLayoutManager);

                SongsAdapter mainItemAppAdapter = new SongsAdapter(listener, songFolderModel.getLoadSongsList());
                ((FolderViewHolder) holder).folder_recycler_view.setAdapter(mainItemAppAdapter);
            }
        }
    }

    @Override
    public int getItemCount() {
        return mArrayList.size();
    }

    public static class FolderViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        private final LinearLayout folder_layout;
        private final TextView folderName;
        private final TextView folderUrl;
        private final ImageView btn_expand;
        private final RecyclerView folder_recycler_view;

        FolderViewHolder(View view) {
            super(view);
            folder_layout = view.findViewById(R.id.folder_layout);
            folderName = view.findViewById(R.id.folderName);
            folderUrl = view.findViewById(R.id.folderUrl);
            btn_expand = view.findViewById(R.id.btn_expand);
            folder_recycler_view = view.findViewById(R.id.folder_recycler_view);

            folder_layout.setOnClickListener(this);
            btn_expand.setOnClickListener(this);
        }

        @Override
        public void onClick(View view) {
            if (folder_recycler_view.getVisibility() == View.VISIBLE) {
                folder_recycler_view.setVisibility(View.GONE);
                btn_expand.setImageResource(R.drawable.ic_navigate_before_white_24dp);
            } else {
                folder_recycler_view.setVisibility(View.VISIBLE);
                btn_expand.setImageResource(R.drawable.ic_arrow_down_white_24dp);
            }
        }
    }

    @Override
    public int getItemViewType(int position) {

        if ("normal".equals(mArrayList.get(position).getType())) {
            return 1;
        }
        return -1;
    }
}
