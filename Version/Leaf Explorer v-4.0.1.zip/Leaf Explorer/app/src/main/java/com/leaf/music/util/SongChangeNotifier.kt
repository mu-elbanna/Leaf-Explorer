package com.leaf.music.util

interface SongChangeNotifier {
    fun onCurrentSongChange()
}