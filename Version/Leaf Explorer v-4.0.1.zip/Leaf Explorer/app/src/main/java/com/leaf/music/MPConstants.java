package com.leaf.music;

import android.content.Context;
import android.content.res.Resources;
import android.provider.MediaStore;

import androidx.core.content.ContextCompat;

import com.leaf.music.helper.MusicLibraryHelper;
import com.leaf.music.model.Folder;
import com.leaf.music.model.Music;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;

public class MPConstants {

    public static float dp2px(Resources resources, float dp) {
        final float scale = resources.getDisplayMetrics().density;
        return  dp * scale + 0.5f;
    }

    public static float sp2px(Resources resources, float sp){
        final float scale = resources.getDisplayMetrics().scaledDensity;
        return sp * scale;
    }

    public static List<File> referencedDirectoryList(Context context) {

        return new ArrayList<>(Arrays.asList(ContextCompat.getExternalFilesDirs(context,null)));
    }

    public static String buildPath(String[] splitPath, int count)
    {
        StringBuilder stringBuilder = new StringBuilder();

        for (int i = 0; (i < count && i < splitPath.length); i++) {
            stringBuilder.append(File.separator);
            stringBuilder.append(splitPath[i]);
        }

        return stringBuilder.toString();
    }

    public static List<Music> getSongs(Context context, boolean reverse) {
        List<Music> musicList = MusicLibraryHelper.fetchMusicLibrary(context, MediaStore.Audio.Media.EXTERNAL_CONTENT_URI);

        List<Music> songsList = new ArrayList<>(musicList);

        Collections.sort(songsList, new SongComparator());

        if (reverse)
            Collections.reverse(songsList);

        return songsList;
    }


    public static List<Folder> folderList = new ArrayList<>();

    public static List<Folder> getFolders(List<Music> songsList, boolean reverse) {
        if (folderList.size() == 0) {

            HashMap<String, Folder> map = new HashMap<>();
            folderList = new ArrayList<>();

            for (Music music : songsList) {
                if (map.containsKey(music.relativePath)) {
                    Folder album = map.get(music.relativePath);
                    assert album != null;
                    album.music.add(music);

                    map.put(music.relativePath, album);

                } else {
                    List<Music> list = new ArrayList<>();
                    list.add(music);
                    Folder album = new Folder(music.relativePath, list);
                    map.put(music.relativePath, album);
                }
            }

            for (String k : map.keySet()) {
                folderList.add(map.get(k));
            }
        }
        Collections.sort(folderList, new FolderComparator());
        if (reverse)
            Collections.reverse(folderList);

        return folderList;
    }

    static class SongComparator implements Comparator<Music> {
        @Override
        public int compare(Music m1, Music m2) {
            return m1.title.compareTo(m2.title);
        }
    }

    static class FolderComparator implements Comparator<Folder> {

        @Override
        public int compare(Folder f1, Folder f2) {
            return f1.title.compareTo(f2.title);
        }
    }
}