package com.leaf.music.ui.fragment

import android.os.Bundle
import android.view.View
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.leaf.music.MPConstants
import com.leaf.music.adapter.SongsAdapter
import com.leaf.music.repository.SongRepository
import com.leaf.music.ui.SongViewModel
import com.leaf.music.ui.SongViewModelFactory
import com.leaf.music.views.ScrollingViewOnApplyWindowInsetsListener
import me.zhanghai.android.fastscroll.FastScroller
import me.zhanghai.android.fastscroll.FastScrollerBuilder
import org.monora.uprotocol.client.android.R

class SongFragment : Fragment(R.layout.fragment_song) {

    private lateinit var viewModel: SongViewModel
    private lateinit var adapter: SongsAdapter
    private lateinit var rvSongs: RecyclerView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val repository = SongRepository(requireContext())
        val viewModelFactory = SongViewModelFactory(repository)
        viewModel = ViewModelProvider(this, viewModelFactory).get(SongViewModel::class.java)
    }

    override fun onResume() {
        super.onResume()
        viewModel.forceReload()
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        rvSongs = view.findViewById(R.id.rvSongs)

        rvSongs.layoutManager = LinearLayoutManager(context)
        adapter = SongsAdapter(requireContext(), mutableListOf())
        rvSongs.adapter = adapter

        val fastScroller = createFastScroller(rvSongs)

        rvSongs.setOnApplyWindowInsetsListener(
            ScrollingViewOnApplyWindowInsetsListener(rvSongs, fastScroller)
        )

        viewModel.songLiveData.observe(viewLifecycleOwner, {
            if (it.isNotEmpty()) {

            } else {
                adapter.updateSongList(emptyList())
            }
        })

        adapter.updateSongList(MPConstants.getSongs(context, false))
    }

    private fun createFastScroller(recyclerView: RecyclerView): FastScroller {
        return FastScrollerBuilder(recyclerView).useMd2Style().build()
    }
}