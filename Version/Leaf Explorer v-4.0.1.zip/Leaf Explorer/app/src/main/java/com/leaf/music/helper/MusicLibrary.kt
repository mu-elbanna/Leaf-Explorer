package com.leaf.music.helper

import com.leaf.music.model.Music

object MusicLibrary {

    fun getSongFromIntent(queriedDisplayName: String, mDeviceMusicList: MutableList<Music>) =
        mDeviceMusicList.firstOrNull { s -> s.displayName == queriedDisplayName }
}