package org.monora.uprotocol.client.android.model

import android.content.Context

data class HomeModel(val context: Context?,
                     val viewType: String,
                     val typeName: String)