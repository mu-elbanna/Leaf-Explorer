package com.leaf.explorer.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.os.StrictMode;

import com.genonbeta.android.framework.preference.DbSharablePreferences;
import com.leaf.explorer.BuildConfig;
import com.leaf.explorer.R;
import com.leaf.explorer.util.AppUtils;
import com.leaf.explorer.util.PreferenceUtils;

import java.lang.Thread.UncaughtExceptionHandler;

import androidx.annotation.NonNull;
import androidx.multidex.MultiDexApplication;
import androidx.preference.PreferenceManager;

public class FileExplorer extends MultiDexApplication
{

    public static final String TAG = FileExplorer.class.getSimpleName();
    public static final String ACTION_REQUEST_PREFERENCES_SYNC = "com.leaf.explorer.intent.action.REQUEST_PREFERENCES_SYNC";

    private final BroadcastReceiver mReceiver = new BroadcastReceiver()
    {
        @Override
        public void onReceive(Context context, Intent intent)
        {
            if (intent != null)
                if (ACTION_REQUEST_PREFERENCES_SYNC.equals(intent.getAction())) {
                    SharedPreferences preferences = AppUtils.getDefaultPreferences(context).getWeakManager();

                    if (preferences instanceof DbSharablePreferences)
                        ((DbSharablePreferences) preferences).sync();
                }
        }
    };

    @Override
    public void onCreate()
    {
        super.onCreate();

        initializeSettings();
        getApplicationContext().registerReceiver(mReceiver, new IntentFilter(ACTION_REQUEST_PREFERENCES_SYNC));

        Thread.setDefaultUncaughtExceptionHandler(new CustomExceptionHandler());

        if (BuildConfig.DEBUG)
        {
            StrictMode.ThreadPolicy.Builder threadBuilder = new StrictMode.ThreadPolicy.Builder();
            threadBuilder.detectAll();
            threadBuilder.penaltyLog();
            StrictMode.setThreadPolicy(threadBuilder.build());

            StrictMode.VmPolicy.Builder vmBuilder = new StrictMode.VmPolicy.Builder();
            vmBuilder.detectAll();
            vmBuilder.penaltyLog();
            StrictMode.setVmPolicy(vmBuilder.build());
        }
    }

    @Override
    public void onTerminate()
    {
        super.onTerminate();
        getApplicationContext().unregisterReceiver(mReceiver);
    }

    private void initializeSettings()
    {
        SharedPreferences defaultPreferences = AppUtils.getDefaultLocalPreferences(this);
        boolean nsdDefined = defaultPreferences.contains("nsd_enabled");

        PreferenceManager.setDefaultValues(this, R.xml.preferences_defaults_main, false);


        if (!nsdDefined)
            defaultPreferences.edit()
                    .putBoolean("nsd_enabled", true)
                    .apply();

        PreferenceUtils.syncDefaults(getApplicationContext());

    }

    public static class CustomExceptionHandler implements UncaughtExceptionHandler
    {
        private final UncaughtExceptionHandler defaultHandler;

        public CustomExceptionHandler()
        {
            this.defaultHandler = Thread.getDefaultUncaughtExceptionHandler();
        }

        @Override
        public void uncaughtException(@NonNull Thread thread, @NonNull Throwable throwable)
        {

            defaultHandler.uncaughtException(thread, throwable);
        }
    }
}