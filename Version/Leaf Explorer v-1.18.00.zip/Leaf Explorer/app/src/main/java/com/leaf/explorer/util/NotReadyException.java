package com.leaf.explorer.util;

public class NotReadyException extends Exception
{
    public NotReadyException(String msg)
    {
        super(msg);
    }
}
