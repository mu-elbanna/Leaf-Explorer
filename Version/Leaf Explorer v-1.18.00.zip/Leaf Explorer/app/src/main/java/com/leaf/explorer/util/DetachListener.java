package com.leaf.explorer.util;

public interface DetachListener
{
    void onPrepareDetach();
}
