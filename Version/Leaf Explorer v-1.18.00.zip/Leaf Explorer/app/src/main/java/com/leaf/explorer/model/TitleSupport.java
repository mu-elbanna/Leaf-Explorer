package com.leaf.explorer.model;

import android.content.Context;

public interface TitleSupport
{
    CharSequence getTitle(Context context);
}
