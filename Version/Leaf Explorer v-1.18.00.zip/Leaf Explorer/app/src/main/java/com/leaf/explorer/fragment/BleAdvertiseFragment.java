package com.leaf.explorer.fragment;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothManager;
import android.bluetooth.le.AdvertiseCallback;
import android.bluetooth.le.AdvertiseData;
import android.bluetooth.le.AdvertiseSettings;
import android.bluetooth.le.BluetoothLeAdvertiser;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.ParcelUuid;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.AppCompatButton;
import com.leaf.explorer.R;
import com.genonbeta.android.framework.ui.callback.SnackbarSupport;

import java.nio.charset.StandardCharsets;
import java.util.UUID;

import static android.content.Context.BLUETOOTH_SERVICE;

public class BleAdvertiseFragment
        extends com.genonbeta.android.framework.app.Fragment
        implements SnackbarSupport, com.genonbeta.android.framework.app.FragmentImpl
{

    private final static String TAG = "BleAdvertiseFragment";

    private Boolean advertising = false;
    private TextView logger;
    private String advertising_data;
    private AppCompatButton advertiseButton;

    private BluetoothAdapter bluetoothAdapter;
    private BluetoothLeAdvertiser advertiser;
    private AdvertiseCallback advertisingCallback;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

          BluetoothManager mBluetoothManager = (BluetoothManager) requireActivity().getSystemService(BLUETOOTH_SERVICE);
          bluetoothAdapter = mBluetoothManager.getAdapter();
       //  We can't continue without proper Bluetooth support
          if (!checkBluetoothSupport(bluetoothAdapter)) {
              requireActivity().finish();
          }
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState)
    {
        final View view = inflater.inflate(R.layout.fragment_ble_advertise, container, false);

        advertiser = BluetoothAdapter.getDefaultAdapter().getBluetoothLeAdvertiser();

        logger = view.findViewById(R.id.loggera);
        advertiseButton = view.findViewById(R.id.advertise_button);

        advertising_data = "Hello Android";

        advertiseButton.setOnClickListener(v -> {
            if (advertising) {
                if (bluetoothAdapter.isEnabled()) {
                    stop_advertise();
                }
            } else {
                if (!bluetoothAdapter.isEnabled()) {
                    Log.d(TAG, "Bluetooth is currently disabled...enabling");
                    bluetoothAdapter.enable();
                } else {
                    // Enable Location
                    Log.d(TAG, "Bluetooth enabled...starting services");
                    start_advertise();
                }
            }
        });

        return view;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();

          if (bluetoothAdapter.isEnabled()) {
               stop_advertise();
          }
    }


    /*
     * This will stop the adversting.  It needs the callback that is created in the start advertising.
     */

    private void stop_advertise() {
        if (advertisingCallback != null && advertising)
            advertiser.stopAdvertising(advertisingCallback);
        advertising = false;
        advertiseButton.setText(getString(R.string.butn_start));
    }
    /**
     * start advertise
     * setup the power levels, the UUID, and the data
     * which is used the callback then call start advertising.
     */

    private void start_advertise() {

        //define the power settings  could use ADVERTISE_MODE_LOW_POWER, ADVERTISE_MODE_BALANCED too.
        AdvertiseSettings settings = new AdvertiseSettings.Builder()
                .setAdvertiseMode(AdvertiseSettings.ADVERTISE_MODE_LOW_LATENCY)
                .setTxPowerLevel(AdvertiseSettings.ADVERTISE_TX_POWER_HIGH)
                .setConnectable(false)
                .build();
        //get the UUID needed.
        ParcelUuid pUuid = new ParcelUuid(UUID.fromString(getString(R.string.blue_uuid)));
        //build
        AdvertiseData data = new AdvertiseData.Builder()
                .setIncludeDeviceName(false)  //should be true, but we are bigger then 31bytes in the name?
                .addServiceUuid(pUuid)
                //this is where the text is added.
                .addServiceData(pUuid, advertising_data.getBytes(StandardCharsets.UTF_8))
                .build();
        advertisingCallback = new AdvertiseCallback() {
            @Override
            public void onStartSuccess(AdvertiseSettings settingsInEffect) {
                logthis("Advertising has started");
                logthis("message is " + advertising_data);
                advertising = true;
                advertiseButton.setText(getString(R.string.text_stopping));
                super.onStartSuccess(settingsInEffect);
            }

            @Override
            public void onStartFailure(int errorCode) {
                logthis("Advertising onStartFailure: " + errorCode);
                advertising = false;
                advertiseButton.setText(getString(R.string.butn_start));
                super.onStartFailure(errorCode);
            }
        };

        advertiser.startAdvertising(settings, data, advertisingCallback);
    }

    public void logthis(String msg) {
        logger.append(msg + "\n");
        Log.d(TAG, msg);
    }

    /**
     * Verify the level of Bluetooth support provided by the hardware.
     * @param bluetoothAdapter System {@link BluetoothAdapter}.
     * @return true if Bluetooth is properly supported, false otherwise.
     */

    private boolean checkBluetoothSupport(BluetoothAdapter bluetoothAdapter) {

        if (bluetoothAdapter == null) {
            Log.w(TAG, "Bluetooth is not supported");
            return false;
        }

        if (!requireActivity().getPackageManager().hasSystemFeature(PackageManager.FEATURE_BLUETOOTH_LE)) {
            Log.w(TAG, "Bluetooth LE is not supported");
            return false;
        }

        return true;
    }


}
