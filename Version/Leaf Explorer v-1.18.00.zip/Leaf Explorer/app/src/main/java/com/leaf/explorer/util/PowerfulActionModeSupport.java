package com.leaf.explorer.util;

import com.genonbeta.android.framework.widget.PowerfulActionMode;

public interface PowerfulActionModeSupport
{
    PowerfulActionMode getPowerfulActionMode();
}
