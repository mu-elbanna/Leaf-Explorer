package com.leaf.explorer.activity;

import android.annotation.SuppressLint;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.res.Configuration;
import android.net.Uri;
import android.net.wifi.p2p.WifiP2pDevice;
import android.os.Build;
import android.os.Bundle;
import android.os.LocaleList;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import com.genonbeta.android.framework.io.DocumentFile;
import com.genonbeta.android.framework.widget.PowerfulActionMode;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.rewarded.RewardedAd;
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.navigation.NavigationView;
import com.leaf.explorer.BuildConfig;
import com.leaf.explorer.R;
import com.leaf.explorer.app.Activity;
import com.leaf.explorer.model.NetworkDevice;
import com.leaf.explorer.util.AppUtils;
import com.leaf.explorer.util.PowerfulActionModeSupport;
import com.leaf.explorer.fragment.LeafFragment;
import com.leaf.explorer.dialog.DeleteView;

public class LeafActivity extends Activity
        implements NavigationView.OnNavigationItemSelectedListener, PowerfulActionModeSupport {

    private LeafFragment mMainFragment;
    private NavigationView mNavigationView;
    private DrawerLayout mDrawerLayout;

    private RewardedAd rewardedAd;

    public static final String TAG = LeafActivity.class.getSimpleName();
    private PowerfulActionMode mActionMode;

    private long mExitPressTime;
    private int mChosenMenuItemId;

    private void createShareHeaderView() {
        View headerView = mNavigationView.getHeaderView(0);
        if (headerView != null) {
            MaterialButton sendLayoutButton = headerView.findViewById(R.id.sendButton);
            MaterialButton receiveLayoutButton = headerView.findViewById(R.id.receiveButton);

            sendLayoutButton.setOnClickListener(v -> {
            });

            receiveLayoutButton.setOnClickListener(v -> startActivity(new Intent(getApplicationContext(), ConnectionManagerActivity.class)
                    .putExtra(ConnectionManagerActivity.EXTRA_ACTIVITY_SUBTITLE, getString(R.string.text_receive))
                    .putExtra(ConnectionManagerActivity.EXTRA_REQUEST_TYPE, ConnectionManagerActivity.RequestType.MAKE_ACQUAINTANCE.toString())));
        }
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_imp);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        //initializing the Google Admob SDK
        MobileAds.initialize(this, initializationStatus -> loadRewardedAd());

        mMainFragment = (LeafFragment) getSupportFragmentManager().findFragmentById(R.id.activitiy_leaf_fragment);
        mNavigationView = findViewById(R.id.nav_view);
        mDrawerLayout = findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, mDrawerLayout, toolbar, R.string.text_navigationDrawerOpen, R.string.text_navigationDrawerClose);
        mDrawerLayout.addDrawerListener(toggle);
        toggle.syncState();
        mDrawerLayout.addDrawerListener(new DrawerLayout.SimpleDrawerListener()
        {
            @Override
            public void onDrawerClosed(View drawerView)
            {
                applyAwaitingDrawerAction();
            }
        });

        mNavigationView.setNavigationItemSelectedListener(this);

        createShareHeaderView();

        mActionMode = findViewById(R.id.content_powerful_action_mode);
        mActionMode.setOnSelectionTaskListener((started, actionMode) -> toolbar.setVisibility(!started ? View.VISIBLE : View.GONE));

    }

    @Override
    protected void onStart()
    {
        super.onStart();
        createHeaderView();
    }

    @Override
    protected void onResume()
    {
        super.onResume();
    }

    @Override
    public void onUserProfileUpdated()
    {
        createHeaderView();
    }

    private void createHeaderView()
    {
        View headerView = mNavigationView.getHeaderView(0);
        Configuration configuration = getApplication().getResources().getConfiguration();

        if (Build.VERSION.SDK_INT >= 24) {
            LocaleList list = configuration.getLocales();

            if (list.size() > 0)
                for (int pos = 0; pos < list.size(); pos++)
                    if (list.get(pos).toLanguageTag().startsWith("en")) {
                        break;
                    }
        }
        if (headerView != null) {
            NetworkDevice localDevice = AppUtils.getLocalDevice(getApplicationContext());

            ImageView imageView = headerView.findViewById(R.id.layout_profile_picture_image_default);
            ImageView editImageView = headerView.findViewById(R.id.layout_profile_picture_image_preferred);
            TextView deviceNameText = headerView.findViewById(R.id.header_default_device_name_text);
            TextView versionText = headerView.findViewById(R.id.header_default_device_version_text);

            deviceNameText.setText(localDevice.nickname);
            versionText.setText(localDevice.versionName);
            loadProfilePictureInto(localDevice.nickname, imageView);

            editImageView.setOnClickListener(v -> startProfileEditor());
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    public PowerfulActionMode getPowerfulActionMode()
    {
        return mActionMode;
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item)
    {
        mChosenMenuItemId = item.getItemId();

        if (mDrawerLayout != null)
            mDrawerLayout.closeDrawer(GravityCompat.START);

        return true;
    }

    @SuppressLint("SetJavaScriptEnabled")
    private void applyAwaitingDrawerAction()
    {
        if (mChosenMenuItemId == 0) {
            // Do nothing
        } else if (R.id.menu_activity_main_web_share == mChosenMenuItemId) {
            startActivity(new Intent(this, WebShareActivity.class));
        } else if (R.id.menu_activity_history == mChosenMenuItemId) {

        } else if (R.id.menu_activity_clear_cache_file == mChosenMenuItemId) {
            new DeleteView(this,null, DocumentFile.fromFile(getApplicationContext().getExternalCacheDir()));
        } else if (R.id.menu_activity_main_exit == mChosenMenuItemId) {
            exitApp();
        } else if (R.id.menu_activity_main_donate == mChosenMenuItemId) {
            startActivity(new Intent(Intent.ACTION_VIEW,
                    Uri.parse("https://play.google.com/store/apps/details?id=com.shiv.shambhu")));
        } else if (R.id.nav_leaf_share == mChosenMenuItemId) {

            Intent sharingIntent = new Intent(android.content.Intent.ACTION_SEND);
            sharingIntent.setType("text/plain");
            String shareBody = "*Best File Explorer & File Sharing app* download now. https://play.google.com/store/apps/details?id=" + getApplicationContext().getPackageName();
            sharingIntent.putExtra(android.content.Intent.EXTRA_SUBJECT, "Share App");
            sharingIntent.putExtra(android.content.Intent.EXTRA_TEXT, shareBody);
            startActivity(Intent.createChooser(sharingIntent, "Share via"));

        } else if (R.id.about_leaf_me == mChosenMenuItemId) {
            aboutMyApp();
        } else if (R.id.leaf_privacypolicy == mChosenMenuItemId) {
            AlertDialog.Builder alert = new AlertDialog.Builder(this);
            alert.setTitle("Privacy Policy");

            WebView wv = new WebView(this);
            wv.getSettings().setJavaScriptEnabled(true);
            wv.loadUrl("file:///android_asset/PrivacyPolicy.txt"); //Your Privacy Policy Url Here
            wv.setWebViewClient(new WebViewClient() {
                @Override
                public boolean shouldOverrideUrlLoading(WebView view, String url) {
                    view.getSettings().setJavaScriptEnabled(true);
                    view.loadUrl(url);

                    return true;
                }
            });

            alert.setView(wv);
            alert.setNegativeButton("Close", (dialog, id) -> dialog.dismiss());
            alert.show();
        } else if (R.id.leaf_rate_us == mChosenMenuItemId) {

            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=" + getApplicationContext().getPackageName())));

        } else if (R.id.leaf_moreapp == mChosenMenuItemId) {

            Uri uri = Uri.parse("market://search?q=pub:" + "Shiv Shambhu"); //Developer AC Name
            Intent goToMarket = new Intent(Intent.ACTION_VIEW, uri);
            try {
                startActivity(goToMarket);
            } catch (ActivityNotFoundException e) {
                startActivity(new Intent(Intent.ACTION_VIEW,
                        Uri.parse("http://play.google.com/store/search?q=pub:" + "Shiv Shambhu"))); //Developer AC Name
            }
        }

        mChosenMenuItemId = 0;
    }

    private void aboutMyApp() {

        AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(this)
                .setTitle(R.string.app_name)
                .setIcon(getResources().getDrawable(R.mipmap.ic_launcher))
                .setCancelable(true)
                .setPositiveButton("Close", null);

        LayoutInflater inflater = this.getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.about, null);
        dialogBuilder.setView(dialogView);

        TextView versionCode = dialogView.findViewById(R.id.version_code);
        TextView versionName = dialogView.findViewById(R.id.version_name);
        versionCode.setText("Version Code : " + BuildConfig.VERSION_CODE);
        versionName.setText("Version Name : " + BuildConfig.VERSION_NAME);
        AlertDialog alertDialog = dialogBuilder.create();
        alertDialog.show();
    }

    @Override
    public void onBackPressed() {
        if (mMainFragment.onBackPressed())
            return;

        if (mDrawerLayout != null && mDrawerLayout.isDrawerOpen(GravityCompat.START))
            mDrawerLayout.closeDrawer(GravityCompat.START);
        else if ((System.currentTimeMillis() - mExitPressTime) < 2000) {
            exitApp();
            super.onBackPressed();
        } else {
            mExitPressTime = System.currentTimeMillis();
            Toast.makeText(this, R.string.mesg_secureExit, Toast.LENGTH_SHORT).show();
        }
    }

    public static String getDeviceStatus(int deviceStatus) {
        switch (deviceStatus) {
            case WifiP2pDevice.AVAILABLE:
                return "Available Devices";
            case WifiP2pDevice.INVITED:
                return "INVITED";
            case WifiP2pDevice.CONNECTED:
                return "CONNECTED";
            case WifiP2pDevice.FAILED:
                return "FAILED";
            case WifiP2pDevice.UNAVAILABLE:
                return "UNAVAILABLE";
            default:
                return "default";
        }
    }

    private void loadRewardedAd() {
        // Creating  an Ad Request
        AdRequest adRequest = new AdRequest.Builder().build();
        //Initializing the RewardedAd  objects
        // load Rewarded Ad with the Request
        RewardedAd.load(this, getString(R.string.admob_rewarded_adUnit),
                adRequest, new RewardedAdLoadCallback() {
                    // creating  RewardedAdLoadCallback for Rewarded Ad with some 2 Override methods
                    @Override
                    public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                        // Handle the error.
                        Log.d(TAG, loadAdError.getMessage());
                        rewardedAd = null;
                    }

                    @Override
                    public void onAdLoaded(@NonNull RewardedAd mRewardedAd) {
                        rewardedAd = mRewardedAd;
                        Log.d(TAG, "Ad was loaded.");
                        showRewardedAd();

                    }
                });
    }

    private void showRewardedAd() {
        if (rewardedAd != null) {
            Activity activityContext = LeafActivity.this;
            //showing the ad Rewarded Ad if it is loaded
            rewardedAd.show(activityContext, rewardItem -> {
                // Handle the reward.
                Log.d(TAG, "The user earned the reward.");
            });
        } else {
            Log.d(TAG, "The rewarded ad wasn't ready yet.");
        }
    }

}
