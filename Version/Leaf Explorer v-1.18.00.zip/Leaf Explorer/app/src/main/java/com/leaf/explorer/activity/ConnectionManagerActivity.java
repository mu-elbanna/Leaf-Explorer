package com.leaf.explorer.activity;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.res.Configuration;
import android.os.Build;
import android.os.Bundle;
import android.os.LocaleList;
import android.provider.Settings;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.IdRes;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentFactory;
import androidx.fragment.app.FragmentTransaction;

import com.leaf.explorer.app.Activity;
import com.leaf.explorer.fragment.P2PManagerFragment;
import com.leaf.explorer.fragment.P2PDiscoverCustomFragment;
import com.leaf.explorer.fragment.QRConnectFragment;
import com.leaf.explorer.fragment.HotspotManagerFragment;
import com.leaf.explorer.fragment.NetworkDeviceListFragment;
import com.leaf.explorer.fragment.NetworkManagerFragment;
import com.leaf.explorer.util.UIConnectionUtils;
import com.leaf.explorer.model.UITask;
import com.leaf.explorer.util.NetworkDeviceSelectedListener;
import com.leaf.explorer.model.TitleSupport;
import com.leaf.explorer.util.ConnectionSetUpAssistant;
import com.leaf.explorer.util.AppUtils;
import com.leaf.explorer.util.ConnectionUtils;
import com.leaf.explorer.util.NetworkDeviceLoader;
import com.leaf.explorer.R;
import com.leaf.explorer.dialog.ManualIpAddressConnectionDialog;
import com.leaf.explorer.model.NetworkDevice;
import com.leaf.explorer.service.CommunicationService;
import com.genonbeta.android.framework.ui.callback.SnackbarSupport;
import com.genonbeta.android.framework.util.Interrupter;
import com.google.android.material.appbar.AppBarLayout;
import com.google.android.material.snackbar.Snackbar;

public class ConnectionManagerActivity
        extends Activity
        implements SnackbarSupport
{
    public static final String ACTION_CHANGE_FRAGMENT = "com.leaf.intent.action.CONNECTION_MANAGER_CHANGE_FRAGMENT";
    public static final String EXTRA_FRAGMENT_ENUM = "extraFragmentEnum";
    public static final String EXTRA_DEVICE_ID = "extraDeviceId";
    public static final String EXTRA_CONNECTION_ADAPTER = "extraConnectionAdapter";
    public static final String EXTRA_REQUEST_TYPE = "extraRequestType";
    public static final String EXTRA_ACTIVITY_SUBTITLE = "extraActivitySubtitle";

    private final IntentFilter mFilter = new IntentFilter();
    private HotspotManagerFragment mHotspotManagerFragment;
    private QRConnectFragment mBarcodeConnectFragment;
    private P2PManagerFragment mP2PManagerFragment;
    private P2PDiscoverCustomFragment mP2PDiscoverFragment;
    private NetworkManagerFragment mNetworkManagerFragment;
    private NetworkDeviceListFragment mDeviceListFragment;
    private OptionsFragment mOptionsFragment;
    private AppBarLayout mAppBarLayout;
    private ProgressBar mProgressBar;
    private static String mTitleProvided;
    private RequestType mRequestType = RequestType.RETURN_RESULT;

    @SuppressLint("StaticFieldLeak")
    private static ConnectionUtils mConnectionUtils;

    private final NetworkDeviceSelectedListener mDeviceSelectionListener = new NetworkDeviceSelectedListener()
    {
        @Override
        public boolean onNetworkDeviceSelected(NetworkDevice networkDevice, NetworkDevice.Connection connection)
        {
            if (mRequestType.equals(RequestType.RETURN_RESULT)) {
                setResult(RESULT_OK, new Intent()
                        .putExtra(EXTRA_DEVICE_ID, networkDevice.deviceId)
                        .putExtra(EXTRA_CONNECTION_ADAPTER, connection.adapterName));

                finish();
            } else {
                ConnectionUtils connectionUtils = ConnectionUtils.getInstance(ConnectionManagerActivity.this);
                UIConnectionUtils uiConnectionUtils = new UIConnectionUtils(connectionUtils, ConnectionManagerActivity.this);

                UITask uiTask = new UITask()
                {
                    @Override
                    public void updateTaskStarted(Interrupter interrupter)
                    {
                        mProgressBar.setVisibility(View.VISIBLE);
                    }

                    @Override
                    public void updateTaskStopped()
                    {
                        mProgressBar.setVisibility(View.GONE);
                    }
                };

                NetworkDeviceLoader.OnDeviceRegisteredListener registeredListener = (database, device, connection1) -> createSnackbar(R.string.mesg_completing).show();

                uiConnectionUtils.makeAcquaintance(ConnectionManagerActivity.this, uiTask,
                        connection.ipAddress, -1, registeredListener);
            }

            return true;
        }

        @Override
        public boolean isListenerEffective()
        {
            return true;
        }
    };

    private final BroadcastReceiver mReceiver = new BroadcastReceiver()
    {
        @Override
        public void onReceive(Context context, Intent intent)
        {
            if (ACTION_CHANGE_FRAGMENT.equals(intent.getAction())
                    && intent.hasExtra(EXTRA_FRAGMENT_ENUM)) {
                String fragmentEnum = intent.getStringExtra(EXTRA_FRAGMENT_ENUM);

                try {
                    AvailableFragment value = AvailableFragment.valueOf(fragmentEnum);

                    if (AvailableFragment.EnterIpAddress.equals(value))
                        showEnterIpAddressDialog();
                    else
                        setFragment(value);
                } catch (Exception e) {
                    // do nothing
                }
            } else if (mRequestType.equals(RequestType.RETURN_RESULT)) {
                if (CommunicationService.ACTION_DEVICE_ACQUAINTANCE.equals(intent.getAction())
                        && intent.hasExtra(CommunicationService.EXTRA_DEVICE_ID)
                        && intent.hasExtra(CommunicationService.EXTRA_CONNECTION_ADAPTER_NAME)) {
                    NetworkDevice device = new NetworkDevice(intent.getStringExtra(CommunicationService.EXTRA_DEVICE_ID));
                    NetworkDevice.Connection connection = new NetworkDevice.Connection(device.deviceId, intent.getStringExtra(CommunicationService.EXTRA_CONNECTION_ADAPTER_NAME));

                    try {
                        AppUtils.getDatabase(ConnectionManagerActivity.this).reconstruct(device);
                        AppUtils.getDatabase(ConnectionManagerActivity.this).reconstruct(connection);

                        mDeviceSelectionListener.onNetworkDeviceSelected(device, connection);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            } else if (mRequestType.equals(RequestType.MAKE_ACQUAINTANCE)) {
                if (CommunicationService.ACTION_INCOMING_TRANSFER_READY.equals(intent.getAction())
                        && intent.hasExtra(CommunicationService.EXTRA_GROUP_ID)) {
                    ViewTransferActivity.startInstance(ConnectionManagerActivity.this,
                            intent.getLongExtra(CommunicationService.EXTRA_GROUP_ID, -1));
                    finish();
                }
            }
        }
    };

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);

        setResult(RESULT_CANCELED);
        setContentView(R.layout.activity_connection_manager);

        FragmentFactory factory = getSupportFragmentManager().getFragmentFactory();
        Toolbar toolbar = findViewById(R.id.toolbar);
        mAppBarLayout = findViewById(R.id.app_bar);
        mProgressBar = findViewById(R.id.activity_connection_establishing_progress_bar);
        mOptionsFragment = (OptionsFragment) factory.instantiate(getClassLoader(), OptionsFragment.class.getName());
        mBarcodeConnectFragment = (QRConnectFragment) factory.instantiate(getClassLoader(), QRConnectFragment.class.getName());
        mHotspotManagerFragment = (HotspotManagerFragment) factory.instantiate(getClassLoader(), HotspotManagerFragment.class.getName());
        mP2PManagerFragment = (P2PManagerFragment) factory.instantiate(getClassLoader(), P2PManagerFragment.class.getName());
        mP2PDiscoverFragment = (P2PDiscoverCustomFragment) factory.instantiate(getClassLoader(), P2PDiscoverCustomFragment.class.getName());
        mNetworkManagerFragment = (NetworkManagerFragment) factory.instantiate(getClassLoader(), NetworkManagerFragment.class.getName());
        mDeviceListFragment = (NetworkDeviceListFragment) factory.instantiate(getClassLoader(), NetworkDeviceListFragment.class.getName());

        mFilter.addAction(ACTION_CHANGE_FRAGMENT);
        mFilter.addAction(CommunicationService.ACTION_DEVICE_ACQUAINTANCE);
        mFilter.addAction(CommunicationService.ACTION_INCOMING_TRANSFER_READY);

        setSupportActionBar(toolbar);

        if (getSupportActionBar() != null)
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        if (getIntent() != null) {
            if (getIntent().hasExtra(EXTRA_REQUEST_TYPE))
                try {
                    mRequestType = RequestType.valueOf(getIntent().getStringExtra(EXTRA_REQUEST_TYPE));
                } catch (Exception e) {
                    // do nothing
                }

            if (getIntent().hasExtra(EXTRA_ACTIVITY_SUBTITLE))
                mTitleProvided = getIntent().getStringExtra(EXTRA_ACTIVITY_SUBTITLE);
        }
    }

    @Override
    protected void onResume()
    {
        super.onResume();
        checkFragment();
        registerReceiver(mReceiver, mFilter);
    }

    @Override
    protected void onPause()
    {
        super.onPause();
        unregisterReceiver(mReceiver);
    }

    @Override
    public void onBackPressed()
    {
        if (getShowingFragment() instanceof OptionsFragment)
            super.onBackPressed();
        else
            setFragment(AvailableFragment.Options);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        int id = item.getItemId();

        if (id == android.R.id.home)
            onBackPressed();
        else
            return super.onOptionsItemSelected(item);

        return true;
    }

    public void applyViewChanges(Fragment fragment, String mTitleProvided)
    {
        boolean isOptions = fragment instanceof OptionsFragment;

        if (fragment instanceof DeviceSelectionSupport)
            ((DeviceSelectionSupport) fragment).setDeviceSelectedListener(mDeviceSelectionListener);

        if (getSupportActionBar() != null) {
            CharSequence titleCurrent = fragment instanceof TitleSupport
                    ? ((TitleSupport) fragment).getTitle(ConnectionManagerActivity.this)
                    : getString(R.string.text_connectDevices);

            if (isOptions)
                setTitle(mTitleProvided != null ? mTitleProvided : titleCurrent);
            else
                setTitle(titleCurrent);
        }

        mAppBarLayout.setExpanded(isOptions, true);
    }

    private void checkFragment()
    {
        Fragment currentFragment = getShowingFragment();

        if (currentFragment == null)
            setFragment(AvailableFragment.Options);
        else
            applyViewChanges(currentFragment, mTitleProvided);
    }

    @Override
    public Snackbar createSnackbar(int resId, Object... objects)
    {
        return Snackbar.make(findViewById(R.id.activity_connection_establishing_content_view), getString(resId, objects), Snackbar.LENGTH_LONG);
    }

    @SuppressLint("SupportAnnotationUsage")
    @IdRes
    public AvailableFragment getShowingFragmentId()
    {
        Fragment fragment = getShowingFragment();

        if (fragment instanceof QRConnectFragment)
            return AvailableFragment.ScanQrCode;
        else if (fragment instanceof HotspotManagerFragment)
            return AvailableFragment.CreateHotspot;
        else if (fragment instanceof P2PManagerFragment)
            return AvailableFragment.ReceiveP2P;
        else if (fragment instanceof P2PDiscoverCustomFragment)
            return AvailableFragment.SendP2P;
        else if (fragment instanceof NetworkManagerFragment)
            return AvailableFragment.UseExistingNetwork;
        else if (fragment instanceof NetworkDeviceListFragment)
            return AvailableFragment.UseKnownDevice;

        // Probably OptionsFragment
        return AvailableFragment.Options;
    }

    @Nullable
    public Fragment getShowingFragment()
    {
        return getSupportFragmentManager().findFragmentById(R.id.activity_connection_establishing_content_view);
    }

    public void setFragment(AvailableFragment fragment)
    {
        @Nullable
        Fragment activeFragment = getShowingFragment();
        Fragment fragmentCandidate;

        switch (fragment) {
            case ScanQrCode:
                //fragmentCandidate = mBarcodeConnectFragment;
                if (mOptionsFragment.isAdded())
                    mOptionsFragment.startCodeScanner();
                return;
            case CreateHotspot:
                fragmentCandidate = mHotspotManagerFragment;
                break;
            case ReceiveP2P:
                fragmentCandidate = mP2PManagerFragment;
                break;
            case SendP2P:
                fragmentCandidate = mP2PDiscoverFragment;
                break;
            case UseExistingNetwork:
                fragmentCandidate = mNetworkManagerFragment;
                break;
            case UseKnownDevice:
                fragmentCandidate = mDeviceListFragment;
                break;
            default:
                fragmentCandidate = mOptionsFragment;
        }

        if (activeFragment == null || fragmentCandidate != activeFragment) {
            FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();

            if (activeFragment != null)
                transaction.remove(activeFragment);

            if (activeFragment != null && fragmentCandidate instanceof OptionsFragment)
                transaction.setCustomAnimations(R.anim.enter_from_left, R.anim.exit_to_right);
            else
                transaction.setCustomAnimations(R.anim.enter_from_right, R.anim.exit_to_left);

            transaction.add(R.id.activity_connection_establishing_content_view, fragmentCandidate);
            transaction.commit();

            applyViewChanges(fragmentCandidate, mTitleProvided);
        }
    }

    protected void showEnterIpAddressDialog()
    {
        ConnectionUtils connectionUtils = ConnectionUtils.getInstance(this);
        UIConnectionUtils uiConnectionUtils = new UIConnectionUtils(connectionUtils, this);
        new ManualIpAddressConnectionDialog(this, uiConnectionUtils, mDeviceSelectionListener).show();
    }

    public enum RequestType
    {
        RETURN_RESULT,
        MAKE_ACQUAINTANCE
    }

    public enum AvailableFragment
    {
        Options,
        UseExistingNetwork,
        UseKnownDevice,
        ScanQrCode,
        CreateHotspot,
        ReceiveP2P,
        SendP2P,
        EnterIpAddress
    }

    public interface DeviceSelectionSupport
    {
        void setDeviceSelectedListener(NetworkDeviceSelectedListener listener);
    }

    public static class OptionsFragment
            extends com.genonbeta.android.framework.app.Fragment
            implements DeviceSelectionSupport
    {

        private NetworkDeviceSelectedListener mListener;

        @Nullable
        @Override
        public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState)
        {
            View view = inflater.inflate(R.layout.fragment_coptions, container, false);

            mConnectionUtils = new ConnectionUtils(getContext());

            LinearLayout option_ReceiveP2P = view.findViewById(R.id.connection_option_ReceiveP2P);
            LinearLayout option_SendP2P = view.findViewById(R.id.connection_option_SendP2P);
            LinearLayout option_manual_ip = view.findViewById(R.id.connection_option_manual_ip);
            LinearLayout option_scan = view.findViewById(R.id.connection_option_scan);
            LinearLayout option_network = view.findViewById(R.id.connection_option_network);

            Configuration configuration = requireActivity().getResources().getConfiguration();
            if (Build.VERSION.SDK_INT >= 24) {
                LocaleList list = configuration.getLocales();

                if (list.size() > 0)
                    for (int pos = 0; pos < list.size(); pos++)
                        if (list.get(pos).toLanguageTag().startsWith("en")) {
                            break;
                        }
            }

            NetworkDevice localDevice = AppUtils.getLocalDevice(getActivity());


            //   ImageView imageView = view.findViewById(R.id.layout_profile_picture_image_default);
            //   ImageView editImageView = view.findViewById(R.id.layout_profile_picture_image_preferred);
            TextView deviceNameText = view.findViewById(R.id.header_default_device_name_text);
            TextView versionText = view.findViewById(R.id.header_default_device_version_text);

            deviceNameText.setText(localDevice.nickname);
            //  versionText.setText(localDevice.versionName);

            if (mTitleProvided.equals(getString(R.string.text_receive))) {
                option_ReceiveP2P.setVisibility(View.VISIBLE);
                option_network.setVisibility(View.GONE);
                option_SendP2P.setVisibility(View.GONE);
                option_manual_ip.setVisibility(View.VISIBLE);
                option_scan.setVisibility(View.GONE);

            } else if (mTitleProvided.equals(getString(R.string.text_addDevicesToTransfer))) {
                option_ReceiveP2P.setVisibility(View.GONE);
                option_SendP2P.setVisibility(View.VISIBLE);
                option_network.setVisibility(View.VISIBLE);
                option_manual_ip.setVisibility(View.GONE);
                option_scan.setVisibility(View.GONE);

            }
//
//            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
//                option_hotspot.setVisibility(View.GONE);
//            }

            View.OnClickListener listener = v -> {
                int id = v.getId();
                if (id == R.id.connection_option_devices) {
                    updateFragment(AvailableFragment.UseKnownDevice);
                } else if (id == R.id.connection_option_hotspot) {
                    updateFragment(AvailableFragment.CreateHotspot);
                } else if (id == R.id.connection_option_ReceiveP2P) {
                    updateFragment(AvailableFragment.ReceiveP2P);
                } else if (id == R.id.connection_option_SendP2P) {
                    updateFragment(AvailableFragment.SendP2P);
                } else if (id == R.id.connection_option_network) {
                    updateFragment(AvailableFragment.UseExistingNetwork);
                } else if (id == R.id.connection_option_manual_ip) {
                    updateFragment(AvailableFragment.EnterIpAddress);
                } else if (id == R.id.connection_option_scan) {
                    startCodeScanner();
                }
            };

            view.findViewById(R.id.connection_option_devices).setOnClickListener(listener);
            view.findViewById(R.id.connection_option_hotspot).setOnClickListener(listener);
            view.findViewById(R.id.connection_option_ReceiveP2P).setOnClickListener(listener);
            view.findViewById(R.id.connection_option_SendP2P).setOnClickListener(listener);
            view.findViewById(R.id.connection_option_network).setOnClickListener(listener);
            view.findViewById(R.id.connection_option_scan).setOnClickListener(listener);
            view.findViewById(R.id.connection_option_manual_ip).setOnClickListener(listener);

            view.findViewById(R.id.connection_option_guide).setOnClickListener(v -> new ConnectionSetUpAssistant(getActivity())
                    .startShowing());

            return view;
        }

        ActivityResultLauncher<Intent> CodeScannerResultLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                new ActivityResultCallback<ActivityResult>() {
                    @Override
                    public void onActivityResult(ActivityResult result) {
                        if (result.getResultCode() == Activity.RESULT_OK) {
                            // There are no request codes
                            Intent data = result.getData();
                            if (data != null) {
                                try {
                                    NetworkDevice device = new NetworkDevice(data.getStringExtra(BarcodeScannerActivity.EXTRA_DEVICE_ID));
                                    AppUtils.getDatabase(getContext()).reconstruct(device);
                                    NetworkDevice.Connection connection = new NetworkDevice.Connection(device.deviceId, data.getStringExtra(BarcodeScannerActivity.EXTRA_CONNECTION_ADAPTER));
                                    AppUtils.getDatabase(getContext()).reconstruct(connection);

                                    if (mListener != null)
                                        mListener.onNetworkDeviceSelected(device, connection);
                                } catch (Exception e) {
                                    // do nothing
                                }
                            }
                        }
                    }
                });

        private void startCodeScanner()
        {
            Intent intent = new Intent(getActivity(), BarcodeScannerActivity.class);
            CodeScannerResultLauncher.launch(intent);
        }

        public void updateFragment(AvailableFragment fragment)
        {
            if (getContext() != null)
                getContext().sendBroadcast(new Intent(ACTION_CHANGE_FRAGMENT)
                        .putExtra(EXTRA_FRAGMENT_ENUM, fragment.toString()));
        }

        @Override
        public void setDeviceSelectedListener(NetworkDeviceSelectedListener listener)
        {
            mListener = listener;
        }

        public ConnectionUtils getConnectionUtils()
        {
            return mConnectionUtils;
        }

    }
}
