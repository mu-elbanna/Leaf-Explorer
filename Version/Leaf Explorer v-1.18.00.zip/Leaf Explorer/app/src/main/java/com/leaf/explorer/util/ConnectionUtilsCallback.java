package com.leaf.explorer.util;

import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkRequest;
import android.os.Build;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;

@RequiresApi(Build.VERSION_CODES.Q)
public class ConnectionUtilsCallback {
    private static final String TAG = "ConnectionUtilsCallback";

    @Nullable
    private static volatile ConnectionUtilsCallback sInstance;
    @Nullable
    private ConnectivityManager.NetworkCallback mNetworkCallback;
    @Nullable
    private ConnectivityManager mConnectivityManager;

    private boolean isNetworkcallbackAdded;

    private boolean isProcessBoundToNetwork;

    private ConnectionUtilsCallback() {
    }

    /**
     * Gets a Singleton instance of DisconnectCallbackHolder.
     * This is a Lazy and Thread safe Singleton with Double-check locking
     *
     * @return DisconnectCallbackHolder Singleton instance
     */
    public static ConnectionUtilsCallback getInstance() {
        if (sInstance == null) {
            synchronized (ConnectionUtilsCallback.class) {
                if (sInstance == null) {
                    sInstance = new ConnectionUtilsCallback();
                }
            }
        }
        return sInstance;
    }

    /**
     * Keeps a reference of {@link ConnectivityManager} and {@link ConnectivityManager.NetworkCallback}
     * This method must be called before anything else.
     *
     * @param networkCallback     the networkcallback class to keep a reference of
     * @param connectivityManager the ConnectivityManager
     */
    public void addNetworkCallback(@NonNull ConnectivityManager.NetworkCallback networkCallback, @NonNull ConnectivityManager connectivityManager) {
        mNetworkCallback = networkCallback;
        mConnectivityManager = connectivityManager;
        isNetworkcallbackAdded = true;
    }

    /**
     * Disconnects from Network and nullifies networkcallback meaning you will have to
     * call {@link ConnectionUtilsCallback#addNetworkCallback(ConnectivityManager.NetworkCallback, ConnectivityManager)} again
     * next time you want to connect again.
     */
    public void disconnect() {
        if (mNetworkCallback != null && mConnectivityManager != null) {
            Log.e(TAG,"Disconnecting on Android 10+");
            mConnectivityManager.unregisterNetworkCallback(mNetworkCallback);
            mNetworkCallback = null;
            isNetworkcallbackAdded = false;
        }
    }

    /**
     * See {@link ConnectivityManager#requestNetwork(NetworkRequest, ConnectivityManager.NetworkCallback) }
     *
     * @param networkRequest {@link NetworkRequest}
     */
    public void requestNetwork(NetworkRequest networkRequest) {
        if (mNetworkCallback != null && mConnectivityManager != null) {
            mConnectivityManager.requestNetwork(networkRequest, mNetworkCallback);
        } else {
            Log.e(TAG,"NetworkCallback has not been added yet. Please call addNetworkCallback method first");
        }
    }

    /**
     * Unbinds the previously bound Network from the process.
     */
    public void unbindProcessFromNetwork() {
        if (mConnectivityManager != null) {
            mConnectivityManager.bindProcessToNetwork(null);
            isProcessBoundToNetwork = false;
        } else {
            Log.e(TAG,"ConnectivityManager is null. Did you call addNetworkCallback method first?");
        }
    }


    /**
     * binds so all api calls performed over this new network
     * if we don't bind, connection with the wifi network is immediately dropped
     */
    public void bindProcessToNetwork(@NonNull Network network) {

        if (mConnectivityManager != null) {
            mConnectivityManager.bindProcessToNetwork(network);
            isProcessBoundToNetwork = true;
        } else {
            Log.e(TAG,"ConnectivityManager is null. Did you call addNetworkCallback method first?");
        }
    }

    /**
     * Checks whether {@link ConnectionUtilsCallback#addNetworkCallback(ConnectivityManager.NetworkCallback, ConnectivityManager)}
     * is called
     *
     * @return true if networkcallback is initialized false otherwise.
     */
    public boolean isNetworkcallbackAdded() {
        return isNetworkcallbackAdded;
    }

    /**
     * Checks whether {@link ConnectionUtilsCallback#bindProcessToNetwork(Network)}
     * is called
     *
     * @return true if bound false otherwise.
     */
    public boolean isProcessBoundToNetwork() {
        return isProcessBoundToNetwork;
    }
}
