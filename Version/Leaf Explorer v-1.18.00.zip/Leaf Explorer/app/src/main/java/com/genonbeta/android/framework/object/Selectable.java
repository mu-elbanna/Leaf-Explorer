package com.genonbeta.android.framework.object;

/**
 * created by: Veli
 * date: 5.01.2018 10:58
 */

public interface Selectable
{
	String getSelectableTitle();

	boolean isSelectableSelected();

	boolean setSelectableSelected(boolean selected);
}
