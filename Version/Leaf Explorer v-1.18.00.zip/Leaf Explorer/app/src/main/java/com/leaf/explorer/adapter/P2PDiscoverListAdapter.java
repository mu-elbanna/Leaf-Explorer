package com.leaf.explorer.adapter;

import android.content.Context;
import android.net.wifi.p2p.WifiP2pDevice;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.leaf.explorer.R;
import com.leaf.explorer.GlideApp;
import com.leaf.explorer.model.Shareable;
import com.leaf.explorer.widget.EditableListAdapter;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class P2PDiscoverListAdapter extends EditableListAdapter<P2PDiscoverListAdapter.ContributorObject, EditableListAdapter.EditableViewHolder>
{
    private Collection<WifiP2pDevice> wifiP2pDeviceList;

    public P2PDiscoverListAdapter(Context context)
    {
        super(context);
    }

    @NonNull
    @Override
    public EditableListAdapter.EditableViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType)
    {
        return new EditableListAdapter.EditableViewHolder(getInflater().inflate(R.layout.fragment_p2p_discover, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull EditableListAdapter.EditableViewHolder holder, int position)
    {
        final ContributorObject contributorObject = getList().get(position);
        TextView textView = holder.getView().findViewById(R.id.text);
        TextView text2 = holder.getView().findViewById(R.id.text2);
        ImageView imageView = holder.getView().findViewById(R.id.image);

        textView.setText(contributorObject.mWifiP2pDevice.deviceName);
        text2.setText(contributorObject.mWifiP2pDevice.deviceAddress);

        GlideApp.with(getContext())
                .load(R.drawable.ic_android_white_24dp)
                .override(90)
                .circleCrop()
                .into(imageView);
    }

    @Override
    public List<ContributorObject> onLoad()
    {
        List<ContributorObject> contributorObjects = new ArrayList<>();

        try {

            for (WifiP2pDevice mWifiP2pDevice : wifiP2pDeviceList) {

                contributorObjects.add(new ContributorObject(mWifiP2pDevice));

            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return contributorObjects;
    }

    public void P2pDeviceList(Collection<WifiP2pDevice> P2pDeviceList) {
        wifiP2pDeviceList = P2pDeviceList;
    }

    public static class ContributorObject extends Shareable
    {
        public WifiP2pDevice mWifiP2pDevice;

        public ContributorObject(WifiP2pDevice mWifiP2pDevice)
        {
            this.mWifiP2pDevice = mWifiP2pDevice;
        }
    }
}
