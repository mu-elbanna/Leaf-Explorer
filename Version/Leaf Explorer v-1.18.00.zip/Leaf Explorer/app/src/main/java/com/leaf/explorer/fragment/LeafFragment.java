package com.leaf.explorer.fragment;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.genonbeta.android.framework.app.Fragment;
import com.genonbeta.android.framework.io.DocumentFile;
import com.genonbeta.android.framework.ui.callback.SnackbarSupport;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.leaf.explorer.R;
import com.leaf.explorer.app.Activity;
import com.leaf.explorer.model.TitleSupport;
import com.leaf.explorer.util.FileUtils;

import java.io.FileNotFoundException;

public class LeafFragment extends Fragment
        implements TitleSupport, SnackbarSupport, com.genonbeta.android.framework.app.FragmentImpl, Activity.OnBackPressedListener {

    private Fragment mFragment;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState)
    {
        final View view = inflater.inflate(R.layout.fragment_leaf, container, false);

        BottomNavigationView bottomNavigationView = view.findViewById(R.id.layout_main_bottom_navigation_view);

        openFragment(new MainLeafFrag());

        bottomNavigationView.setOnItemSelectedListener(menuItem -> {
            int itemId = menuItem.getItemId();
            if (itemId == R.id.leaf_transfers) {
                openFragment(new TransferGroupListFragment());
                return true;
            } else if (itemId == R.id.leaf_home) {
                openFragment(new MainLeafFrag());
                return true;
            } else if (itemId == R.id.leaf_explorer) {
                openFragment(new StorageExplorerFragment());
                return true;
            }
            return false;
        });

        //Reading incoming intents
        Intent read_int = requireActivity().getIntent();

        if(Intent.ACTION_VIEW.equals(read_int.getAction()) && read_int.getType() != null) {
            Uri uri = read_int.getData();
            if (uri != null) {
                try {
                    DocumentFile current_file = FileUtils.fromUri(getContext(), uri);

                    if(current_file.getName().contains(".zip") || current_file.getName().contains(".ZIP")) {
                        openFragment(new StorageExplorerFragment());

                        // mRequestedPath = DocumentFile.fromFile(requireContext().getExternalCacheDir());
                    }
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                }

            }
        }

        return view;
    }

    public void openFragment(Fragment mFragment) {
        getChildFragmentManager()
                .beginTransaction()
                .replace(R.id.layout_main_view_pager, mFragment)
                .commit();

        this.mFragment = mFragment;
    }

    @Override
    public CharSequence getTitle(Context context)
    {
        return context.getString(R.string.text_home);
    }

    public Fragment getFragment() {
        return mFragment;
    }

    @Override
    public boolean onBackPressed()
    {
        Object activeItem = getFragment();

        if ((activeItem instanceof Activity.OnBackPressedListener
                && ((Activity.OnBackPressedListener) activeItem).onBackPressed()))
            return true;

        return false;
    }
}
