package com.leaf.explorer.utils;

import android.os.AsyncTask;
import com.leaf.explorer.file_share.base.Keyword;
import com.leaf.explorer.file_share.wifi_p2p.P2PWiFiFrag;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;

public class WifiServerTask extends AsyncTask<Void, Void, Void> {

    ServerSocket serverSocket = null;
    PrintWriter output = null;
    private final String networkName;
    private final String password;
    private final int keyManagement;

    public WifiServerTask(String networkName, String password, int keyManagement) {
        this.networkName = networkName;
        this.password = password;
        this.keyManagement = keyManagement;
    }

    @Override
    protected Void doInBackground(Void... voids) {
        clean();
        try {
            serverSocket = new ServerSocket();
            serverSocket.setReuseAddress(true);
            serverSocket.bind(new InetSocketAddress(P2PWiFiFrag.PORT));
            Socket client = serverSocket.accept();

            output = new PrintWriter(client.getOutputStream());

            try {
                JSONObject object = new JSONObject()
                        .put(Keyword.NETWORK_NAME, networkName)
                        .put(Keyword.NETWORK_PASSWORD, password)
                        .put(Keyword.NETWORK_KEYMGMT, keyManagement);

                output.write(object.toString());
                output.flush();
            } catch (JSONException e) {
                e.printStackTrace();
            }

            serverSocket.close();
            serverSocket = null;
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            clean();
        }
        return null;
    }

    private void clean() {
        if (serverSocket != null && !serverSocket.isClosed()) {
            try {
                serverSocket.close();
                serverSocket = null;
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        if (output != null) {
            output.close();
        }
    }

}