package com.leaf.explorer.leaf_music.fragment;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.MediaMetadataRetriever;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example_gallary.sectionedrecyclerviewadapter.Section;
import com.example_gallary.sectionedrecyclerviewadapter.SectionParameters;
import com.genonbeta.android.framework.io.DocumentFile;
import com.leaf.explorer.R;
import com.leaf.explorer.view.album.FoldersUtils;

import java.io.File;

final class ExpandableMusicSection extends Section {

    private final String title;
    private final String[] list;
    private final ClickListener clickListener;
    private final Activity activity;

    private boolean expanded = false;

    ExpandableMusicSection(Activity activity, @NonNull final String title, @NonNull final String[] list,
                           @NonNull final ClickListener clickListener) {
        super(SectionParameters.builder()
                .itemResourceId(R.layout.fragment_music_folder)
                .headerResourceId(R.layout.section_ex6_header)
                .build());

        this.activity = activity;
        this.title = title;
        this.list = list;
        this.clickListener = clickListener;
    }

    @Override
    public int getContentItemsTotal() {
        return expanded ? list.length : 0;
    }

    @Override
    public RecyclerView.ViewHolder getItemViewHolder(final View view) {
        return new ItemViewHolder(view);
    }

    @Override
    public void onBindItemViewHolder(final RecyclerView.ViewHolder holder, final int position) {
        final ItemViewHolder itemHolder = (ItemViewHolder) holder;

        //Movie movie = list.get(position);
        String url = list[position];

        MediaMetadataRetriever mmr = new MediaMetadataRetriever();
        mmr.setDataSource(url);
        String title = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE);
        String artist = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST);
        if (title == null) {
            DocumentFile current_song = DocumentFile.fromFile(new File(url));
            title = current_song.getName();
            artist = "<Unknown>";
        }
        if (artist == null) {
            artist = "<Unknown>";
        }

        itemHolder.tvItem.setText(title);
        itemHolder.tvSubItem.setText("Artist : " + artist);

        Bitmap bm = getAlbumImage(url);
        if(bm != null) {
            itemHolder.mImageView.setImageBitmap(bm);
        } else {
            itemHolder.mImageView.setImageResource(R.drawable.ic_music_note_white_24dp);
        }

        /*
        GlideApp.with(activity)
                .load(url)
                .override(300)
                .centerCrop()
                .into(itemHolder.mImageView);

         */

        itemHolder.rootView.setOnClickListener(v ->
                clickListener.onItemRootViewClicked(this, list, position)
        );
    }

    private Bitmap getAlbumImage(String path) {
        android.media.MediaMetadataRetriever mmr = new MediaMetadataRetriever();
        mmr.setDataSource(path);
        byte[] data = mmr.getEmbeddedPicture();
        if (data != null)
            return BitmapFactory.decodeByteArray(data, 0, data.length);

        return null;
    }

    @Override
    public RecyclerView.ViewHolder getHeaderViewHolder(final View view) {
        return new HeaderViewHolder(view);
    }

    @Override
    public void onBindHeaderViewHolder(final RecyclerView.ViewHolder holder) {
        final HeaderViewHolder headerHolder = (HeaderViewHolder) holder;
        String currentFolder = FoldersUtils.getFolderName(title);

        headerHolder.tvTitle.setText(currentFolder);
        headerHolder.imgArrow.setImageResource(
                expanded ? R.drawable.ic_keyboard_arrow_up_black_18dp : R.drawable.ic_keyboard_arrow_down_black_18dp
        );

        headerHolder.rootView.setOnClickListener(v ->
                clickListener.onHeaderRootViewClicked(this)
        );
    }

    boolean isExpanded() {
        return expanded;
    }

    void setExpanded(final boolean expanded) {
        this.expanded = expanded;
    }

    interface ClickListener {

        void onHeaderRootViewClicked(@NonNull final ExpandableMusicSection section);

        void onItemRootViewClicked(@NonNull final ExpandableMusicSection section, String[] url, final int itemAdapterPosition);
    }

    static final class HeaderViewHolder extends RecyclerView.ViewHolder {

        final View rootView;
        final TextView tvTitle;
        final ImageView imgArrow;

        HeaderViewHolder(@NonNull final View view) {
            super(view);

            rootView = view;
            tvTitle = view.findViewById(R.id.tvTitle);
            imgArrow = view.findViewById(R.id.imgArrow);
        }
    }

    static final class ItemViewHolder extends RecyclerView.ViewHolder {

        final View rootView;
        final TextView tvItem;
        final TextView tvSubItem;
        ImageView mImageView;

        ItemViewHolder(@NonNull final View view) {
            super(view);

            rootView = view;
            tvItem = view.findViewById(R.id.tvItem);
            tvSubItem = view.findViewById(R.id.tvSubItem);
            mImageView = view.findViewById(R.id.imgItem);
        }
    }
}
