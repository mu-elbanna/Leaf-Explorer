package com.leaf.explorer.fragments.recent;

import android.content.Context;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.format.DateUtils;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.leaf.explorer.file_share.view.GalleryGroupEditableListFragment;
import com.leaf.explorer.file_share.model.TitleSupport;
import com.leaf.explorer.file_share.util.AppUtils;
import com.leaf.explorer.R;
import com.leaf.explorer.file_share.widget.GroupEditableListAdapter;
import android.content.ContentResolver;
import android.database.Cursor;
import android.net.Uri;
import android.webkit.MimeTypeMap;
import android.widget.ImageView;
import android.widget.TextView;

import com.leaf.explorer.file_share.base.GlideApp;
import com.leaf.explorer.file_share.util.TimeUtils;
import com.leaf.explorer.file_share.widget.GalleryGroupEditableListAdapter;
import com.leaf.explorer.fragments.recent.RecentOtherFragment.RecentOtherAdapter;

import java.io.File;

public class RecentOtherFragment extends GalleryGroupEditableListFragment<RecentOtherAdapter.OtherHolder, GroupEditableListAdapter.GroupViewHolder, RecentOtherAdapter>
        implements TitleSupport {

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);

        setFilteringSupported(true);
        setDefaultOrderingCriteria(RecentOtherAdapter.MODE_SORT_ORDER_DESCENDING);
        setDefaultSortingCriteria(RecentOtherAdapter.MODE_SORT_BY_DATE);
        setDefaultGroupingCriteria(RecentOtherAdapter.MODE_GROUP_BY_DATE);
        setDefaultViewingGridSize(4, 6);
        setUseDefaultPaddingDecoration(false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState)
    {
        super.onViewCreated(view, savedInstanceState);

        setEmptyImage(R.drawable.ic_photo_white_24dp);
        setEmptyText(getString(R.string.text_listEmptyImage));
    }

    @Override
    public void onResume()
    {
        super.onResume();

        requireContext().getContentResolver()
                .registerContentObserver(MediaStore.Files.getContentUri("external"), true, getDefaultContentObserver());
    }

    @Override
    public void onPause()
    {
        super.onPause();

        requireContext().getContentResolver()
                .unregisterContentObserver(getDefaultContentObserver());
    }

    @Override
    public RecentOtherAdapter onAdapter()
    {
        final AppUtils.QuickActions<GroupEditableListAdapter.GroupViewHolder> quickActions = clazz -> {
            if (!clazz.isRepresentative()) {
                registerLayoutViewClicks(clazz);

                View visitView = clazz.getView().findViewById(R.id.visitView);
                visitView.setOnClickListener(
                        v -> performLayoutClickOpen(clazz));
                visitView.setOnLongClickListener(v -> performLayoutLongClick(clazz));

                clazz.getView().findViewById(getAdapter().isGridLayoutRequested()
                        ? R.id.selectorContainer : R.id.selector)
                        .setOnClickListener(v -> {
                            if (getSelectionConnection() != null)
                                getSelectionConnection().setSelected(clazz.getAdapterPosition());
                        });

                //  View selectView = clazz.getView().findViewById(R.id.SelectView);
                //  selectView.setOnClickListener(v -> Toast.makeText(getContext(), "success", Toast.LENGTH_SHORT).show());
            }
        };

        return new RecentOtherAdapter(getActivity())
        {
            @NonNull
            @Override
            public GroupViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType)
            {
                return AppUtils.quickAction(super.onCreateViewHolder(parent, viewType), quickActions);
            }
        };
    }

    @Override
    public boolean onDefaultClickAction(GroupEditableListAdapter.GroupViewHolder holder)
    {
        return getSelectionConnection() != null
                ? getSelectionConnection().setSelected(holder)
                : performLayoutClickOpen(holder);
    }

    @Override
    public CharSequence getTitle(Context context)
    {
        return context.getString(R.string.text_gallery);
    }








    public static class RecentOtherAdapter
            extends GalleryGroupEditableListAdapter<RecentOtherAdapter.OtherHolder, GroupEditableListAdapter.GroupViewHolder>
    {
        private final ContentResolver mResolver;

        public RecentOtherAdapter(Context context)
        {
            super(context, MODE_GROUP_BY_DATE);
            mResolver = context.getContentResolver();
        }

        @Override
        protected void onLoad(GroupLister<OtherHolder> lister)
        {

            /*
            String pdf = MimeTypeMap.getSingleton().getMimeTypeFromExtension("pdf");
            String doc = MimeTypeMap.getSingleton().getMimeTypeFromExtension("doc");
            String docx = MimeTypeMap.getSingleton().getMimeTypeFromExtension("docx");
            String xls = MimeTypeMap.getSingleton().getMimeTypeFromExtension("xls");
            String xlsx = MimeTypeMap.getSingleton().getMimeTypeFromExtension("xlsx");
            String ppt = MimeTypeMap.getSingleton().getMimeTypeFromExtension("ppt");
            String pptx = MimeTypeMap.getSingleton().getMimeTypeFromExtension("pptx");
            String txt = MimeTypeMap.getSingleton().getMimeTypeFromExtension("txt");
            String rtx = MimeTypeMap.getSingleton().getMimeTypeFromExtension("rtx");
            String rtf = MimeTypeMap.getSingleton().getMimeTypeFromExtension("rtf");
            String html = MimeTypeMap.getSingleton().getMimeTypeFromExtension("html");

            String where = MediaStore.Files.FileColumns.MIME_TYPE + "=?"
                    + " OR " + MediaStore.Files.FileColumns.MIME_TYPE + "=?"
                    + " OR " + MediaStore.Files.FileColumns.MIME_TYPE + "=?"
                    + " OR " + MediaStore.Files.FileColumns.MIME_TYPE + "=?"
                    + " OR " + MediaStore.Files.FileColumns.MIME_TYPE + "=?"
                    + " OR " + MediaStore.Files.FileColumns.MIME_TYPE + "=?"
                    + " OR " + MediaStore.Files.FileColumns.MIME_TYPE + "=?"
                    + " OR " + MediaStore.Files.FileColumns.MIME_TYPE + "=?"
                    + " OR " + MediaStore.Files.FileColumns.MIME_TYPE + "=?"
                    + " OR " + MediaStore.Files.FileColumns.MIME_TYPE + "=?"
                    + " OR " + MediaStore.Files.FileColumns.MIME_TYPE + "=?";
            String[] args = new String[]{pdf, doc, docx, xls, xlsx, ppt, pptx, txt, rtx, rtf, html};

             */

            Uri collection = MediaStore.Files.getContentUri("external");

            long MAX_HISTORY_IN_MILLIS = 15 * DateUtils.DAY_IN_MILLIS;
            long cutoff = System.currentTimeMillis() - MAX_HISTORY_IN_MILLIS;

            Cursor cursor = mResolver.query(collection,
                    null,
                    MediaStore.Files.FileColumns.DATE_TAKEN + ">" + cutoff,
                    null,
                    null);

            if (cursor != null) {
                if (cursor.moveToFirst()) {
                    int idIndex = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns._ID);
                    int titleIndex = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.TITLE);
                    int displayIndex = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.DISPLAY_NAME);
                    int folderIndex = cursor.getColumnIndex(MediaStore.Files.FileColumns.DATA);
                    int dateAddedIndex = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.DATE_MODIFIED);
                    int sizeIndex = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.SIZE);
                    int typeIndex = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.MIME_TYPE);

                    do {
                        OtherHolder holder = new OtherHolder(
                                cursor.getLong(idIndex),
                                cursor.getString(titleIndex),
                                cursor.getString(displayIndex),
                                extractFolderName(cursor.getString(folderIndex)),
                                cursor.getString(typeIndex),
                                cursor.getLong(dateAddedIndex) * 1000,
                                cursor.getLong(sizeIndex),
                                Uri.parse(collection + "/" + cursor.getInt(idIndex)));

                        holder.dateTakenString = String.valueOf(TimeUtils.formatDateTime(getContext(), holder.date));

                        lister.offerObliged(this, holder);
                    }
                    while (cursor.moveToNext());
                }

                cursor.close();
            }
        }

        public String extractFolderName(String folder)
        {
            if (folder.contains(File.separator)) {
                String[] split = folder.split(File.separator);

                if (split.length >= 2)
                    folder = split[split.length - 2];
            }

            return folder;
        }

        @NonNull
        @Override
        public GroupViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType)
        {
            if (viewType == VIEW_TYPE_REPRESENTATIVE)
                return new GroupViewHolder(getInflater().inflate(R.layout.view_title, parent, false),
                        R.id.layout_list_title_text);

            return new GroupViewHolder(getInflater().inflate(isGridLayoutRequested()
                    ? R.layout.row_image_grid
                    : R.layout.row_image, parent, false));
        }

        @Override
        public void onBindViewHolder(@NonNull GroupViewHolder holder, int position)
        {
            try {
                final View parentView = holder.getView();
                final OtherHolder object = getItem(position);

                if (!holder.tryBinding(object)) {
                    ViewGroup container = parentView.findViewById(R.id.container);
                    ImageView image = parentView.findViewById(R.id.image);
                    TextView text1 = parentView.findViewById(R.id.text);
                    TextView text2 = parentView.findViewById(R.id.text2);

                    text1.setText(object.friendlyName);
                    text2.setText(object.dateTakenString);

                    parentView.setSelected(object.isSelectableSelected());

                    GlideApp.with(getContext())
                            .load(object.uri)
                            .override(300)
                            .centerCrop()
                            .into(image);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        @Override
        protected OtherHolder onGenerateRepresentative(String representativeText)
        {
            return new OtherHolder(representativeText);
        }

        @Override
        public boolean isGridSupported()
        {
            return true;
        }

        public static class OtherHolder extends GalleryGroupEditableListAdapter.GalleryGroupShareable
        {
            public String dateTakenString;

            public OtherHolder(String representativeText)
            {
                super(VIEW_TYPE_REPRESENTATIVE, representativeText);
            }

            public OtherHolder(long id, String title, String fileName, String albumName, String mimeType, long date, long size, Uri uri)
            {
                super(id, title, fileName, albumName, mimeType, date, size, uri);
            }
        }

    }
}
