package com.leaf.explorer.file_share.view;

import com.leaf.explorer.file_share.fragment.EditableListFragment;
import com.leaf.explorer.file_share.widget.EditableListAdapter;

public interface EditableListFragmentModelImpl<V extends EditableListAdapter.EditableViewHolder>
{
    void setLayoutClickListener(EditableListFragment.LayoutClickListener<V> clickListener);
}
