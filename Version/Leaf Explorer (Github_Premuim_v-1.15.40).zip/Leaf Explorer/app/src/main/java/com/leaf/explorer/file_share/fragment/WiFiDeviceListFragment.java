package com.leaf.explorer.file_share.fragment;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothManager;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanFilter;
import android.bluetooth.le.ScanResult;
import android.bluetooth.le.ScanSettings;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.leaf.explorer.R;
import com.leaf.explorer.file_share.adapter.WiFiDeviceListAdapter;
import com.leaf.explorer.file_share.model.TitleSupport;
import com.leaf.explorer.file_share.util.AppUtils;
import com.leaf.explorer.file_share.util.NotReadyException;
import com.leaf.explorer.file_share.widget.EditableListAdapter;
import com.leaf.explorer.utils.ble.BluetoothLeServices;

import java.util.ArrayList;
import java.util.List;

import static android.content.Context.BIND_AUTO_CREATE;

public class WiFiDeviceListFragment extends EditableListFragment<WiFiDeviceListAdapter.ShortcutHolder, EditableListAdapter.EditableViewHolder, WiFiDeviceListAdapter>
        implements TitleSupport
{

    private BluetoothAdapter mBluetoothAdapter;
    private BluetoothLeScanner mBluetoothLeScanner;
    private static final long SCAN_PERIOD = 15000;
    private Handler mHandler;

   // static String uuid = "00002220-0000-1000-8000-00805f9b34fb";
    private ScanSettings settings;
    private List<ScanFilter> filters;
   // private BluetoothGatt mGatt;

    private BluetoothLeServices mBluetoothLeServices;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setSortingSupported(false);
        setHasOptionsMenu(true);

        setDefaultViewingGridSize(4, 6);

        getBluetoothAdapterAndLeScanner();

    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState)
    {
        super.onViewCreated(view, savedInstanceState);

        setEmptyImage(R.drawable.ic_photo_white_24dp);
        setEmptyText(getString(R.string.text_listEmptyImage));
    }


    @Override
    public void onResume()
    {
        super.onResume();

        if (!mBluetoothAdapter.isEnabled()) {
            mBluetoothAdapter.enable();
        } else {
            settings = new ScanSettings.Builder()
                    .setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY)
                    .build();
            filters = new ArrayList<>();

            scanLeDevice(true);
        }
        getActivity().registerReceiver(mGattUpdateReceiver, BluetoothLeServices.getIntentFilter());

    }


    @Override
    public void onPause()
    {
        super.onPause();
        if (mBluetoothAdapter != null && mBluetoothAdapter.isEnabled()) {
            scanLeDevice(false);
        }
        getActivity().unregisterReceiver(mGattUpdateReceiver);

    }

    @Override
    public void onDestroy() {
        /*
        if (mGatt == null) {
            return;
        }
        mGatt.close();
        mGatt = null;

         */
        super.onDestroy();
    }

    @Override
    public WiFiDeviceListAdapter onAdapter()
    {
        final AppUtils.QuickActions<EditableListAdapter.EditableViewHolder> quickActions = clazz -> {
            registerLayoutViewClicks(clazz);

            View visitView = clazz.getView().findViewById(R.id.menu);
            visitView.setOnClickListener(
                    v -> Toast.makeText(getContext(), "working", Toast.LENGTH_SHORT).show());

        };

        return new WiFiDeviceListAdapter(getActivity())
        {
            @NonNull
            @Override
            public EditableViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType)
            {
                return AppUtils.quickAction(super.onCreateViewHolder(parent, viewType), quickActions);
            }
        };
    }

    @Override
    public boolean onDefaultClickAction(EditableListAdapter.EditableViewHolder holder)
    {
        try {
            WiFiDeviceListAdapter.ShortcutHolder item = getAdapter().getItem(holder);

        } catch (NotReadyException e) {
            e.printStackTrace();
        }
        return true;
    }


    @Override
    public CharSequence getTitle(Context context)
    {
        return context.getString(R.string.text_shortcut);
    }

    @Override
    public void onCreateOptionsMenu(@NonNull Menu menu, @NonNull MenuInflater inflater)
    {
        super.onCreateOptionsMenu(menu, inflater);

        if (!isHorizontalOrientation())
            inflater.inflate(R.menu.actions_network_device, menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        if (R.id.network_devices_scan == item.getItemId())
            scanLeDevice(true);
        else
            return super.onOptionsItemSelected(item);

        return true;
    }




    private void getBluetoothAdapterAndLeScanner() {
        // Get BluetoothAdapter and BluetoothLeScanner.
        final BluetoothManager bluetoothManager =
                (BluetoothManager) requireContext().getSystemService(Context.BLUETOOTH_SERVICE);
        mBluetoothAdapter = bluetoothManager.getAdapter();
        mBluetoothLeScanner = mBluetoothAdapter.getBluetoothLeScanner();
        mHandler = new Handler();
        mBluetoothLeServices = new BluetoothLeServices();

    }

    private void scanLeDevice(boolean enable) {
        if (enable) {
            // Stops scanning after a pre-defined scan period.
            mHandler.postDelayed(() -> mBluetoothLeScanner.stopScan(mScanCallback), SCAN_PERIOD);
            //filters.add(new UUID[]{UUID.fromString(uuid)});
           // mBluetoothLeScanner.startScan(filters, settings, mScanCallback);
            mBluetoothLeScanner.startScan(mScanCallback);
        } else {
            mBluetoothLeScanner.stopScan(mScanCallback);
        }
    }

    private final ScanCallback mScanCallback = new ScanCallback() {
        @Override
        public void onScanResult(int callbackType, ScanResult result) {
            Log.i("callbackType", String.valueOf(callbackType));
            Log.i("result", result.toString());
            BluetoothDevice btDevice = result.getDevice();
            connectToDevice(btDevice);
            requireActivity().runOnUiThread(() -> getAdapter().addDevice(btDevice));
        }

        @Override
        public void onBatchScanResults(List<ScanResult> results) {
            for (ScanResult sr : results) {
                Log.i("ScanResult - Results", sr.toString());
            }
        }

        @Override
        public void onScanFailed(int errorCode) {
            Log.e("Scan Failed", "Error Code: " + errorCode);
        }
    };

    public void connectToDevice(BluetoothDevice device) {
       // if (mGatt == null) {
           // mGatt = device.connectGatt(getContext(), false, gattCallback);
            Intent intent = new Intent(getContext(), BluetoothLeServices.class);
            getActivity().bindService(intent,
                    new ServiceConnection() {
                        @Override
                        public void onServiceConnected(ComponentName name, IBinder service) {

                            mBluetoothLeServices = ((BluetoothLeServices.LocalBinder) service).getService();
                            mBluetoothLeServices.start(device);
                        }

                        @Override
                        public void onServiceDisconnected(ComponentName name) {

                        }
                    },
                    BIND_AUTO_CREATE);

            scanLeDevice(false);// will stop after first device detection
      //  }
    }

    private final BroadcastReceiver mGattUpdateReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            final String action = intent.getAction();

            if(BluetoothLeServices.ACTION_DATA_AVAILABLE.equals(action)){
                //refineData(intent.getStringExtra(mBluetoothLeServices.EXTRA_DATA));

                byte [] data = intent.getByteArrayExtra(BluetoothLeServices.EXTRA_DATA);

                try{
                    int i = data.length;
                    Toast.makeText(context, i, Toast.LENGTH_SHORT).show();
                   // Log.i(LOG_TAG, "Data Received: " + data);
                } catch (Exception e){
                   // Log.e(LOG_TAG, e.toString());
                }
            }
        }
    };







































    /*
    private final BluetoothAdapter.LeScanCallback mLeScanCallback =
            (device, rssi, scanRecord) -> requireActivity().runOnUiThread(() -> {
                Log.i("onLeScan", device.toString());
                connectToDevice(device);
            });

    public void connectToDevice2(BluetoothDevice device) {
        if (mGatt == null) {
            mGatt = device.connectGatt(getContext(), false, gattCallback);
            scanLeDevice(false);// will stop after first device detection
        }
    }

    private final BluetoothGattCallback gattCallback = new BluetoothGattCallback() {
        @Override
        public void onConnectionStateChange(BluetoothGatt gatt, int status, int newState) {
            Log.i("onConnectionStateChange", "Status: " + status);
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                Log.i("gattCallback", "STATE_CONNECTED");
                gatt.discoverServices();
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                Log.e("gattCallback", "STATE_DISCONNECTED");
            } else {
                Log.e("gattCallback", "STATE_OTHER");
            }
        }

        @Override
        public void onServicesDiscovered(BluetoothGatt gatt, int status) {
            List<BluetoothGattService> services = gatt.getServices();
            Log.i("onServicesDiscovered", services.toString());
            gatt.readCharacteristic(services.get(1).getCharacteristics().get
                    (0));
        }

        @Override
        public void onCharacteristicRead(BluetoothGatt gatt,
                                         BluetoothGattCharacteristic
                                                 characteristic, int status) {
            Log.i("onCharacteristicRead", characteristic.toString());
            gatt.disconnect();
        }
    };

     */
}
