package com.leaf.explorer.file_share.wifi_p2p;

import android.Manifest;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.net.NetworkInfo;
import android.net.wifi.p2p.WifiP2pDevice;
import android.net.wifi.p2p.WifiP2pInfo;
import android.net.wifi.p2p.WifiP2pManager;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;

import com.google.android.material.button.MaterialButton;
import com.leaf.explorer.R;
import com.leaf.explorer.file_share.model.TitleSupport;
import com.leaf.explorer.file_share.util.ConnectionUtils;
import com.leaf.explorer.file_share.util.IconSupport;
import com.leaf.explorer.file_share.view.RadarLayout;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import static android.os.Looper.getMainLooper;

public class ReceiveFileFrag
        extends com.genonbeta.android.framework.app.Fragment
        implements TitleSupport, IconSupport {

    private WifiP2pManager.Channel channel;
    private BroadcastReceiver broadcastReceiver;
    private TextView tv_log;
    private ConnectionUtils mConnectionUtils;
    TextView tv_device_name;
    private boolean ConnectionInfoAvailable = false;

    private final DirectActionListener directActionListener = new DirectActionListener() {
        @Override
        public void wifiP2pEnabled(boolean enabled) {
            log("wifiP2pEnabled: " + enabled);
        }

        @Override
        public void onConnectionInfoAvailable(WifiP2pInfo wifiP2pInfo) {
            log("onConnectionInfoAvailable");
            log("isGroupOwner：" + wifiP2pInfo.isGroupOwner);
            log("groupFormed：" + wifiP2pInfo.groupFormed);
            if (wifiP2pInfo.groupFormed && wifiP2pInfo.isGroupOwner) {

                if (ActivityCompat.checkSelfPermission(requireContext(), Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {

                    return;
                }
                getConnectionUtils().getWifiP2pManager().requestGroupInfo(channel, group -> {
                    tv_device_name.setText("Started" + "\n" + group.getNetworkName() + "\n" + group.getPassphrase());
                    log("Group Password: " + group.getPassphrase());
                    ConnectionInfoAvailable = true;
                });

            }
        }

        @Override
        public void onDisconnection() {
            log("onDisconnection");
            tv_device_name.setText("Service Stop");
            ConnectionInfoAvailable = false;
        }

        @Override
        public void onSelfDeviceAvailable(WifiP2pDevice wifiP2pDevice) {
            log("onSelfDeviceAvailable");
            log(wifiP2pDevice.toString());
        }

        @Override
        public void onPeersAvailable(Collection<WifiP2pDevice> wifiP2pDeviceList) {
            log("onPeersAvailable,size:" + wifiP2pDeviceList.size());
            for (WifiP2pDevice wifiP2pDevice : wifiP2pDeviceList) {
                log(wifiP2pDevice.toString());
            }
        }

        @Override
        public void onChannelDisconnected() {
            log("onChannelDisconnected");
            ConnectionInfoAvailable = false;
        }
    };

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mConnectionUtils = new ConnectionUtils(getContext());
        channel = getConnectionUtils().getWifiP2pManager().initialize(getContext(), getMainLooper(), directActionListener);
        broadcastReceiver = new DirectBroadcastReceiver(getConnectionUtils().getWifiP2pManager(), channel, directActionListener);

    }

    public ConnectionUtils getConnectionUtils()
    {
        return mConnectionUtils;
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = getLayoutInflater().inflate(R.layout.activity_receive_file, container, false);

        RadarLayout radarLayout;
        radarLayout = view.findViewById(R.id.SenderRadar);
        radarLayout.setUseRing(true);
        radarLayout.setColor(getResources().getColor(R.color.blue2));
        radarLayout.setCount(5);
        radarLayout.start();

        createGroup();

        tv_device_name = view.findViewById(R.id.tv_device_name);

        MaterialButton btn_createGroup = view.findViewById(R.id.btn_createGroup);
        btn_createGroup.setOnClickListener(v -> createGroup());

        MaterialButton btn_removeGroup = view.findViewById(R.id.btn_removeGroup);
        btn_removeGroup.setOnClickListener(v -> removeGroup());

        tv_log = view.findViewById(R.id.tv_log);

        return view;
    }

    @Override
    public int getIconRes()
    {
        return R.drawable.ic_wifi_tethering_white_24dp;
    }

    @Override
    public CharSequence getTitle(Context context)
    {
        return context.getString(R.string.text_startHotspot);
    }

    @Override
    public void onResume()
    {
        super.onResume();
        requireContext().registerReceiver(broadcastReceiver, DirectBroadcastReceiver.getIntentFilter());
    }

    @Override
    public void onPause()
    {
        super.onPause();

        requireContext().unregisterReceiver(broadcastReceiver);
    }

    public void createGroup() {
        if (ActivityCompat.checkSelfPermission(requireContext(), Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            //
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        getConnectionUtils().getWifiP2pManager().createGroup(channel, new WifiP2pManager.ActionListener() {
            @Override
            public void onSuccess() {
                log("createGroup onSuccess");
                Toast.makeText(requireContext(), "Started", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onFailure(int reason) {
                log("createGroup onFailure: " + reason);
                if(ConnectionInfoAvailable) {
                    Toast.makeText(requireContext(), "Started", Toast.LENGTH_SHORT).show();
                } else {
                    // Toast.makeText(requireContext(), R.string.mesg_somethingWentWrong, Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void removeGroup() {
        getConnectionUtils().getWifiP2pManager().removeGroup(channel, new WifiP2pManager.ActionListener() {
            @Override
            public void onSuccess() {
                log("removeGroup onSuccess");
                Toast.makeText(requireContext(), "Service Stop", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onFailure(int reason) {
                log("removeGroup onFailure");
                if(!ConnectionInfoAvailable) {
                    Toast.makeText(requireContext(), "Service Stop", Toast.LENGTH_SHORT).show();
                } else {
                    // Toast.makeText(requireContext(), R.string.mesg_somethingWentWrong, Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void log(String log) {
        tv_log.append(log + "\n");
        tv_log.append("----------" + "\n");
    }


    public static class DirectBroadcastReceiver extends BroadcastReceiver {

        public static IntentFilter getIntentFilter() {
            IntentFilter intentFilter = new IntentFilter();
            intentFilter.addAction(WifiP2pManager.WIFI_P2P_STATE_CHANGED_ACTION);
            intentFilter.addAction(WifiP2pManager.WIFI_P2P_PEERS_CHANGED_ACTION);
            intentFilter.addAction(WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION);
            intentFilter.addAction(WifiP2pManager.WIFI_P2P_THIS_DEVICE_CHANGED_ACTION);
            return intentFilter;
        }

        private static final String TAG = "DirectBroadcastReceiver";

        private final WifiP2pManager mWifiP2pManager;

        private final WifiP2pManager.Channel mChannel;

        private final DirectActionListener mDirectActionListener;

        public DirectBroadcastReceiver(WifiP2pManager wifiP2pManager, WifiP2pManager.Channel channel, DirectActionListener directActionListener) {
            mWifiP2pManager = wifiP2pManager;
            mChannel = channel;
            mDirectActionListener = directActionListener;
        }

        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (action != null) {
                switch (action) {
                    // 用于指示 Wifi P2P 是否可用
                    case WifiP2pManager.WIFI_P2P_STATE_CHANGED_ACTION: {
                        int state = intent.getIntExtra(WifiP2pManager.EXTRA_WIFI_STATE, -100);
                        if (state == WifiP2pManager.WIFI_P2P_STATE_ENABLED) {
                            mDirectActionListener.wifiP2pEnabled(true);
                        } else {
                            mDirectActionListener.wifiP2pEnabled(false);
                            List<WifiP2pDevice> wifiP2pDeviceList = new ArrayList<>();
                            mDirectActionListener.onPeersAvailable(wifiP2pDeviceList);
                        }
                        break;
                    }
                    // 对等节点列表发生了变化
                    case WifiP2pManager.WIFI_P2P_PEERS_CHANGED_ACTION: {
                        if (ActivityCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                            //
                            //    ActivityCompat#requestPermissions
                            // here to request the missing permissions, and then overriding
                            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                            //                                          int[] grantResults)
                            // to handle the case where the user grants the permission. See the documentation
                            // for ActivityCompat#requestPermissions for more details.
                            return;
                        }
                        mWifiP2pManager.requestPeers(mChannel, peers -> mDirectActionListener.onPeersAvailable(peers.getDeviceList()));
                        break;
                    }
                    // Wifi P2P 的连接状态发生了改变
                    case WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION: {
                        NetworkInfo networkInfo = intent.getParcelableExtra(WifiP2pManager.EXTRA_NETWORK_INFO);
                        if (networkInfo != null && networkInfo.isConnected()) {
                            mWifiP2pManager.requestConnectionInfo(mChannel, mDirectActionListener::onConnectionInfoAvailable);
                            Log.e(TAG, "已连接p2p设备");
                        } else {
                            mDirectActionListener.onDisconnection();
                            Log.e(TAG, "与p2p设备已断开连接");
                        }
                        break;
                    }
                    //本设备的设备信息发生了变化
                    case WifiP2pManager.WIFI_P2P_THIS_DEVICE_CHANGED_ACTION: {
                        WifiP2pDevice wifiP2pDevice = intent.getParcelableExtra(WifiP2pManager.EXTRA_WIFI_P2P_DEVICE);
                        mDirectActionListener.onSelfDeviceAvailable(wifiP2pDevice);
                        break;
                    }
                }
            }
        }

    }

}
