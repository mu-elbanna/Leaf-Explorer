package com.leaf.explorer.utils;

import android.app.IntentService;
import android.content.Intent;
import android.os.Binder;
import android.os.IBinder;
import androidx.annotation.Nullable;
import com.leaf.explorer.file_share.wifi_p2p.P2PWiFiFrag;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.InetSocketAddress;
import java.net.Socket;

public class WifiClientService extends IntentService {

    public interface OnProgressChangListener {

        void onReceive(String message);

    }

    private Socket socket = null;
    private BufferedReader input = null;
    private String ipAddress;

    private OnProgressChangListener progressChangListener;

    public class MyBinder extends Binder {
        public WifiClientService getService() {
            return WifiClientService.this;
        }
    }

    public WifiClientService() {
        super("WifiClientService");
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return new MyBinder();
    }

    @Override
    protected void onHandleIntent(Intent intent) {
        clean();
        String message = null;
        try {
            socket = new Socket();
            socket.bind(null);
            socket.connect((new InetSocketAddress(ipAddress, P2PWiFiFrag.PORT)), 10000);

            input = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            message = input.readLine();

            socket.close();
            input.close();

            socket = null;
            input = null;
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            clean();
            if (progressChangListener != null) {
                progressChangListener.onReceive(message);
            }
            //再次启动服务，等待客户端下次连接
            startService(new Intent(this, WifiClientService.class));
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        clean();
    }

    public void setProgressChangListener(OnProgressChangListener progressChangListener) {
        this.progressChangListener = progressChangListener;
    }

    public void setLeafIpAddress(String ipAddress) {
        this.ipAddress = ipAddress;
    }

    private void clean() {
        if (socket != null && !socket.isClosed()) {
            try {
                socket.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        if (input != null) {
            try {
                input.close();
                input = null;
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

}