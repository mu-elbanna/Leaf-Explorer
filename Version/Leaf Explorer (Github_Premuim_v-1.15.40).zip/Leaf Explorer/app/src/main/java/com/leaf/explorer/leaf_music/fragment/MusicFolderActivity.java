package com.leaf.explorer.leaf_music.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.example_gallary.sectionedrecyclerviewadapter.SectionAdapter;
import com.example_gallary.sectionedrecyclerviewadapter.SectionedRecyclerViewAdapter;
import com.leaf.explorer.R;
import com.leaf.explorer.app.AppActivity;
import com.leaf.explorer.leaf_music.MusicActivity;
import com.leaf.explorer.view.album.Folders;
import com.leaf.explorer.view.album.FoldersUtils;
import com.leaf.explorer.view.album.MediaFromFolders;
import java.util.ArrayList;

public class MusicFolderActivity
        extends AppActivity
        implements ExpandableMusicSection.ClickListener {

    private SectionedRecyclerViewAdapter sectionedAdapter;
    ArrayList<Folders> albumsList;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_music_folder);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_close_white_24dp);
        }

        sectionedAdapter = new SectionedRecyclerViewAdapter();

        final RecyclerView recyclerView = findViewById(R.id.recyclerview);

        albumsList = FoldersUtils.getAllAlbums(this);
        String[] resultFolders = FoldersUtils.initFolders(this, albumsList);

        for (String path : resultFolders) {
            String[] mediaUrls = MediaFromFolders.listMedia(path);

            if (mediaUrls.length != 0) {
                LinearLayoutManager HorizontalLayout;
                RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(this);
                recyclerView.setLayoutManager(layoutManager);
                HorizontalLayout = new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false);
                recyclerView.setLayoutManager(HorizontalLayout);

                sectionedAdapter.addSection(new ExpandableMusicSection(this, path,
                        mediaUrls, this));
            }
        }

        recyclerView.setAdapter(sectionedAdapter);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        int id = item.getItemId();

        if (id == android.R.id.home)
            finish();
        else
            return super.onOptionsItemSelected(item);

        return true;
    }

    @Override
    public void onHeaderRootViewClicked(@NonNull final ExpandableMusicSection section) {
        final SectionAdapter sectionAdapter = sectionedAdapter.getAdapterForSection(section);

        // store info of current section state before changing its state
        final boolean wasExpanded = section.isExpanded();
        final int previousItemsTotal = section.getContentItemsTotal();

        section.setExpanded(!wasExpanded);
        sectionAdapter.notifyHeaderChanged();

        if (wasExpanded) {
            sectionAdapter.notifyItemRangeRemoved(0, previousItemsTotal);
        } else {
            sectionAdapter.notifyAllItemsInserted();
        }
    }

    @Override
    public void onItemRootViewClicked(@NonNull final ExpandableMusicSection section, String[] url, final int itemAdapterPosition) {

        Intent intent = new Intent(this,
                MusicActivity.class);
        intent.putExtra("urls", url);
        intent.putExtra("pos", itemAdapterPosition);
        intent.putExtra("play", true);
        startActivity(intent);
    }

}
