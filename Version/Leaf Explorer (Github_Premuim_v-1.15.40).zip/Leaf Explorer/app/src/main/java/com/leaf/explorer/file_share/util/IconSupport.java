package com.leaf.explorer.file_share.util;

import androidx.annotation.DrawableRes;

public interface IconSupport
{
    @DrawableRes
    int getIconRes();
}
