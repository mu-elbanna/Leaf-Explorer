package com.leaf.explorer.leaf_music;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.leaf.explorer.R;
import java.util.ArrayList;

public class SongAdapter extends BaseAdapter {

    Context context;
    private final ArrayList<Song> songs;
    private AdapterView.OnItemClickListener onItemClickListenerSongPlay;

    public SongAdapter(Context c, ArrayList<Song> theSongs){
        this.context = c;
        songs = theSongs;
    }

    @Override
    public int getCount() {
        return songs.size();
    }

    @Override
    public Object getItem(int arg0) {
        return null;
    }

    @Override
    public long getItemId(int arg0) {

        return 0;
    }

    private static class ViewHolder {
        LinearLayout Linear_songView;
        TextView songView;
        TextView artistView;
        ImageView songImage;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        Song currSong = songs.get(position);

        ViewHolder viewHolder;

        if (convertView == null) {
            viewHolder = new ViewHolder();
            LayoutInflater inflater = LayoutInflater.from(context);
            convertView = inflater.inflate(R.layout.song, parent, false);

            viewHolder.Linear_songView = convertView.findViewById(R.id.Linear_songView);
            viewHolder.songView = convertView.findViewById(R.id.tv_song_title);
            viewHolder.artistView = convertView.findViewById(R.id.tv_song_artist);
            viewHolder.songImage = convertView.findViewById(R.id.iv_song_image);

            convertView.setTag(viewHolder);
        } else {
            viewHolder = (ViewHolder) convertView.getTag();
        }

        viewHolder.songView.setText(currSong.getTitle());
        viewHolder.artistView.setText(currSong.getArtist());
        Bitmap bm = getAlbumImage(currSong.getData());
       if(bm != null) {
           viewHolder.songImage.setImageBitmap(getRounded(bm));
       } else {
           viewHolder.songImage.setImageResource(R.drawable.ic_music_note_white_24dp);
       }

        viewHolder.Linear_songView.setOnClickListener(v -> {
            if (onItemClickListenerSongPlay != null) {
                onItemClickListenerSongPlay.onItemClick(null, v, position, -1);
            }
        });

        return convertView;

    }

    private Bitmap getAlbumImage(Uri path) {
        android.media.MediaMetadataRetriever mmr = new MediaMetadataRetriever();
        mmr.setDataSource(context, path);
        byte[] data = mmr.getEmbeddedPicture();
        if (data != null)
            return BitmapFactory.decodeByteArray(data, 0, data.length);

      return null;
    }


    private Bitmap getRounded(Bitmap mbitmap)
    {
        Bitmap imageRounded=Bitmap.createBitmap(mbitmap.getWidth(), mbitmap.getHeight(), mbitmap.getConfig());
        Canvas canvas=new Canvas(imageRounded);
        Paint mpaint=new Paint();
        mpaint.setAntiAlias(true);
        mpaint.setShader(new BitmapShader(mbitmap, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP));
        canvas.drawRoundRect((new RectF(0, 0, mbitmap.getWidth(), mbitmap.getHeight())), 100, 100, mpaint);
        return  imageRounded;
    }

    public void setOnItemClickListener(AdapterView.OnItemClickListener onItemClickListener) {
        this.onItemClickListenerSongPlay = onItemClickListener;
    }

}