package com.leaf.explorer.file_share.model;

import android.content.Context;

public interface TitleSupport
{
    CharSequence getTitle(Context context);
}
