package org.monora.uprotocol.client.android.model

data class StorageModel(val name: String, val free: String, val total: String, val used: String, val percentage: Int, val path: String)