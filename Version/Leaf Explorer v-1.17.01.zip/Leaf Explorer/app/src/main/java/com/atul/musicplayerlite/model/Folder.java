package com.atul.musicplayerlite.model;

import android.os.Parcel;
import android.os.Parcelable;

import com.atul.musicplayerlite.helper.ListHelper;

import java.util.ArrayList;
import java.util.List;

public class Folder implements Parcelable {

    public static final Creator<Folder> CREATOR = new Creator<Folder>() {
        @Override
        public Folder createFromParcel(Parcel in) {
            return new Folder(in);
        }

        @Override
        public Folder[] newArray(int size) {
            return new Folder[size];
        }
    };

    public int songsCount;
    public String name;
    public List<Music> music;

    public Folder(int songsCount, String name, List<Music> music) {
        this.songsCount = songsCount;
        this.name = ListHelper.ifNull(name);
        this.music = music;
    }

    protected Folder(Parcel in) {
        name = in.readString();
        music = new ArrayList<>();
        in.readTypedList(music, Music.CREATOR);

        if (in.readByte() == 0) {
            songsCount = 0;
        } else {
            songsCount = in.readInt();
        }
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(name);
        dest.writeTypedList(music);

        if (songsCount == 0) {
            dest.writeByte((byte) 0);
        } else {
            dest.writeByte((byte) 1);
            dest.writeInt(songsCount);
        }
    }
}
