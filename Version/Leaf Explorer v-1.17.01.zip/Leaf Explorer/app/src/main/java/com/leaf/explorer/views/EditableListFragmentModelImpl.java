package com.leaf.explorer.views;

import com.leaf.explorer.fragment.EditableListFragment;
import com.leaf.explorer.widget.EditableListAdapter;

public interface EditableListFragmentModelImpl<V extends EditableListAdapter.EditableViewHolder>
{
    void setLayoutClickListener(EditableListFragment.LayoutClickListener<V> clickListener);
}
