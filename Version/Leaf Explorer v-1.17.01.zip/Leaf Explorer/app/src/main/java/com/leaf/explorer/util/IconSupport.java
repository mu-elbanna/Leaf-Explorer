package com.leaf.explorer.util;

import androidx.annotation.DrawableRes;

public interface IconSupport
{
    @DrawableRes
    int getIconRes();
}
