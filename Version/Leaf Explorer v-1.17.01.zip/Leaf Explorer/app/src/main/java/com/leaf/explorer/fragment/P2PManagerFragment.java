package com.leaf.explorer.fragment;

import android.Manifest;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.net.NetworkInfo;
import android.net.wifi.p2p.WifiP2pDevice;
import android.net.wifi.p2p.WifiP2pInfo;
import android.net.wifi.p2p.WifiP2pManager;
import android.os.Build;
import android.os.Bundle;

import com.genonbeta.android.framework.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.widget.AppCompatButton;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.widget.ImageViewCompat;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.common.BitMatrix;
import com.journeyapps.barcodescanner.BarcodeEncoder;
import com.leaf.explorer.R;
import com.leaf.explorer.activity.BarcodeScannerActivity;
import com.leaf.explorer.activity.ConnectionManagerActivity;
import com.leaf.explorer.app.AppConfig;
import com.leaf.explorer.GlideApp;
import com.leaf.explorer.app.Keyword;
import com.leaf.explorer.model.NetworkDevice;
import com.leaf.explorer.model.TitleSupport;
import com.leaf.explorer.util.AppUtils;
import com.leaf.explorer.util.ConnectionUtils;
import com.leaf.explorer.util.IconSupport;
import com.leaf.explorer.util.NetworkDeviceSelectedListener;
import com.leaf.explorer.util.UIConnectionUtils;
import com.leaf.explorer.views.RadarLayout;
import com.leaf.explorer.p2p_ble.DirectActionListener;

import org.json.JSONObject;

import static android.os.Looper.getMainLooper;

public class P2PManagerFragment extends Fragment
        implements TitleSupport, IconSupport, ConnectionManagerActivity.DeviceSelectionSupport {

    public static final int REQUEST_PERMISSION_LOCATION = 2;
    private boolean mWaitForHotspot = false;

    private AppCompatButton advertise, scanLayoutButton;

    private NetworkDeviceSelectedListener mListener;

    private TextView tv_device_name;

    private WifiP2pManager.Channel channel;
    private BroadcastReceiver broadcastReceiver;

    private UIConnectionUtils mConnectionUtils;
    private  boolean ConnectionInfoAvailable = false;
    private ImageView mCodeView;
    private ColorStateList mColorPassiveState;

    private final DirectActionListener directActionListener = new DirectActionListener() {
        @Override
        public void wifiP2pEnabled(boolean enabled) {

        }

        @Override
        public void onConnectionInfoAvailable(WifiP2pInfo wifiP2pInfo) {
            if (wifiP2pInfo.groupFormed && wifiP2pInfo.isGroupOwner) {

                final String[] info = new String[1];

                if (ActivityCompat.checkSelfPermission(requireContext(), Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {

                    return;
                }
                getConnectionUtils().getWifiP2pManager().requestGroupInfo(channel, group -> {

                    AppConfig.NetworkName = group.getNetworkName();
                    AppConfig.password = group.getPassphrase();
                    AppConfig.Bssid = group.getOwner().deviceAddress;
                    ConnectionInfoAvailable = true;
                    advertiseButton(false);

                    info[0] = "Name : " + AppConfig.NetworkName + "\n" + "Password : " + AppConfig.password;
                    tv_device_name.setText(info[0]);

                    QR_Data(AppConfig.NetworkName,
                            AppConfig.password);
                });

            }
        }

        @Override
        public void onDisconnection() {
            tv_device_name.setText(R.string.p2p_null);
            advertiseButton(true);
            ConnectionInfoAvailable = false;
        }

        @Override
        public void onSelfDeviceAvailable(WifiP2pDevice wifiP2pDevice) {

        }

        @Override
        public void onPeersAvailable(Collection<WifiP2pDevice> wifiP2pDeviceList) {

        }

        @Override
        public void onChannelDisconnected() {
            ConnectionInfoAvailable = false;
        }
    };

    public ConnectionUtils getConnectionUtils()
    {
        return getUIConnectionUtils().getConnectionUtils();
    }

    public UIConnectionUtils getUIConnectionUtils()
    {
        if (mConnectionUtils == null)
            mConnectionUtils = new UIConnectionUtils(ConnectionUtils.getInstance(getContext()), this);

        return mConnectionUtils;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);

        channel = getConnectionUtils().getWifiP2pManager().initialize(getContext(), getMainLooper(), directActionListener);
        broadcastReceiver = new DirectBroadcastReceiver(getConnectionUtils().getWifiP2pManager(), channel, directActionListener);

        mColorPassiveState = ColorStateList.valueOf(ContextCompat.getColor(requireContext(), AppUtils.getReference(requireContext(), R.attr.colorPassive)));
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View myView = inflater.inflate(R.layout.fragment_create_p2p, container, false);

        RadarLayout radarLayout;
        radarLayout = myView.findViewById(R.id.SenderRadar);
        radarLayout.setUseRing(true);
        radarLayout.setColor(getResources().getColor(R.color.blue2));
        radarLayout.setCount(8);
        radarLayout.start();

        tv_device_name = myView.findViewById(R.id.tv_device_name);
        mCodeView = myView.findViewById(R.id.layout_manager_qr_image);
        scanLayoutButton = myView.findViewById(R.id.scanLayoutButton);

        advertise = myView.findViewById(R.id.advertise);
        advertise.setOnClickListener(v -> {
            if (ConnectionInfoAvailable) {
                removeGroup();
            } else {
                createGroup();
            }
        });

        scanLayoutButton.setOnClickListener(v -> {
            if (ConnectionInfoAvailable) {
                Intent intent = new Intent(getActivity(), BarcodeScannerActivity.class);
                CodeScannerResultLauncher.launch(intent);
            } else {
                Toast.makeText(requireContext(), "First Setup P2P", Toast.LENGTH_SHORT).show();
            }
        });

        return myView;
    }

    private void advertiseButton(Boolean setup) {
        if (setup) {
            advertise.setText(R.string.butn_startP2P);
        } else
            advertise.setText(R.string.butn_stopP2P);
    }

    @Override
    public void onCreateOptionsMenu(@NonNull Menu menu, @NonNull MenuInflater inflater)
    {
        super.onCreateOptionsMenu(menu, inflater);
        inflater.inflate(R.menu.p2p_fragment, menu);

        menu.findItem(R.id.network_devices_scan).setVisible(false);
        menu.findItem(R.id.devices_disconnect).setVisible(false);
        menu.findItem(R.id.manager_qr_image).setVisible(false);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        if (R.id.manager_qr_image == item.getItemId())
            if (mCodeView.getVisibility() == View.VISIBLE) {
                mCodeView.setVisibility(View.GONE);
            } else
                mCodeView.setVisibility(View.VISIBLE);
        else
            return super.onOptionsItemSelected(item);

        return true;
    }

    @Override
    public void onResume()
    {
        super.onResume();
        requireContext().registerReceiver(broadcastReceiver, DirectBroadcastReceiver.getIntentFilter());
        String info;

        if (!ConnectionInfoAvailable) {
            createGroup();
        } else {
            advertiseButton(false);

            info = "Name : " + AppConfig.NetworkName + "\n" + "Password : " + AppConfig.password;
            tv_device_name.setText(info);

            QR_Data(AppConfig.NetworkName,
                    AppConfig.password);
        }
    }

    private void QR_Data(String NetworkName, String password) {
        try {
            JSONObject object = new JSONObject()
                    .put(Keyword.NETWORK_NAME, NetworkName)
                    .put(Keyword.NETWORK_PASSWORD, password)
                    .put(Keyword.P2P_Boolean, true);

            GenerateQR(object);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onPause()
    {
        super.onPause();

        requireContext().unregisterReceiver(broadcastReceiver);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }

    @Override
    public int getIconRes()
    {
        return R.drawable.ic_wifi_white_24dp;
    }

    @Override
    public CharSequence getTitle(Context context)
    {
        return context.getString(R.string.text_P2P_Network);
    }

    public void createGroup() {

        if (!getInfo_Location()) {
            getUIConnectionUtils().P2P_LocationPermission(getActivity(), REQUEST_PERMISSION_LOCATION, mHotspotWatcher);
        } else if (!getConnectionUtils().getWifiManager().isWifiEnabled()) {
            getUIConnectionUtils().turnOnWiFi(getActivity(), mHotspotWatcher);
        } else {
            if (ActivityCompat.checkSelfPermission(requireContext(), Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                return;
            }

            getConnectionUtils().getWifiP2pManager().createGroup(channel, new WifiP2pManager.ActionListener() {
                @Override
                public void onSuccess() {
                    Toast.makeText(requireContext(), "Started", Toast.LENGTH_SHORT).show();
                }

                @Override
                public void onFailure(int reason) {
                    if(ConnectionInfoAvailable) {
                        Toast.makeText(requireContext(), "Started", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(requireContext(), R.string.mesg_somethingWentWrong, Toast.LENGTH_SHORT).show();
                        removeGroup();
                    }
                }
            });
        }



    }

    private void removeGroup() {
        getConnectionUtils().getWifiP2pManager().removeGroup(channel, new WifiP2pManager.ActionListener() {
            @Override
            public void onSuccess() {
                Toast.makeText(requireContext(), "Service Stop", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onFailure(int reason) {
                if(!ConnectionInfoAvailable) {
                    Toast.makeText(requireContext(), "Service Stop", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(requireContext(), R.string.mesg_somethingWentWrong, Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void GenerateQR(JSONObject codeIndex) {
        boolean showQRCode = codeIndex != null
                && codeIndex.length() > 0
                && getContext() != null;

        try {

            if (showQRCode) {
                {
                    int networkPin = AppUtils.getUniqueNumber();

                    codeIndex.put(Keyword.NETWORK_PIN, networkPin);

                    AppUtils.getDefaultPreferences(getContext()).edit()
                            .putInt(Keyword.NETWORK_PIN, networkPin)
                            .apply();
                }

                MultiFormatWriter formatWriter = new MultiFormatWriter();
                BitMatrix bitMatrix = formatWriter.encode(codeIndex.toString(), BarcodeFormat.QR_CODE, 400, 400);
                BarcodeEncoder encoder = new BarcodeEncoder();
                Bitmap bitmap = encoder.createBitmap(bitMatrix);

                GlideApp.with(getContext())
                        .load(bitmap)
                        .into(mCodeView);
            } else
                mCodeView.setImageResource(R.drawable.ic_qrcode_white_128dp);

            ImageViewCompat.setImageTintList(mCodeView, showQRCode ? null : mColorPassiveState);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static class DirectBroadcastReceiver extends BroadcastReceiver {

        public static IntentFilter getIntentFilter() {
            IntentFilter intentFilter = new IntentFilter();
            intentFilter.addAction(WifiP2pManager.WIFI_P2P_STATE_CHANGED_ACTION);
            intentFilter.addAction(WifiP2pManager.WIFI_P2P_PEERS_CHANGED_ACTION);
            intentFilter.addAction(WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION);
            intentFilter.addAction(WifiP2pManager.WIFI_P2P_THIS_DEVICE_CHANGED_ACTION);
            return intentFilter;
        }

        private static final String TAG = "DirectBroadcastReceiver";

        private final WifiP2pManager mWifiP2pManager;

        private final WifiP2pManager.Channel mChannel;

        private final DirectActionListener mDirectActionListener;

        public DirectBroadcastReceiver(WifiP2pManager wifiP2pManager, WifiP2pManager.Channel channel, DirectActionListener directActionListener) {
            mWifiP2pManager = wifiP2pManager;
            mChannel = channel;
            mDirectActionListener = directActionListener;
        }

        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (action != null) {
                switch (action) {
                    // 用于指示 Wifi P2P 是否可用
                    case WifiP2pManager.WIFI_P2P_STATE_CHANGED_ACTION: {
                        int state = intent.getIntExtra(WifiP2pManager.EXTRA_WIFI_STATE, -100);
                        if (state == WifiP2pManager.WIFI_P2P_STATE_ENABLED) {
                            mDirectActionListener.wifiP2pEnabled(true);
                        } else {
                            mDirectActionListener.wifiP2pEnabled(false);
                            List<WifiP2pDevice> wifiP2pDeviceList = new ArrayList<>();
                            mDirectActionListener.onPeersAvailable(wifiP2pDeviceList);
                        }
                        break;
                    }
                    // 对等节点列表发生了变化
                    case WifiP2pManager.WIFI_P2P_PEERS_CHANGED_ACTION: {
                        if (ActivityCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                            //
                            //    ActivityCompat#requestPermissions
                            // here to request the missing permissions, and then overriding
                            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                            //                                          int[] grantResults)
                            // to handle the case where the user grants the permission. See the documentation
                            // for ActivityCompat#requestPermissions for more details.
                            return;
                        }
                        mWifiP2pManager.requestPeers(mChannel, peers -> mDirectActionListener.onPeersAvailable(peers.getDeviceList()));
                        break;
                    }
                    // Wifi P2P 的连接状态发生了改变
                    case WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION: {
                        NetworkInfo networkInfo = intent.getParcelableExtra(WifiP2pManager.EXTRA_NETWORK_INFO);
                        if (networkInfo != null && networkInfo.isConnected()) {
                            mWifiP2pManager.requestConnectionInfo(mChannel, mDirectActionListener::onConnectionInfoAvailable);
                            Log.e(TAG, "已连接p2p设备");
                        } else {
                            mDirectActionListener.onDisconnection();
                            Log.e(TAG, "与p2p设备已断开连接");
                        }
                        break;
                    }
                    //本设备的设备信息发生了变化
                    case WifiP2pManager.WIFI_P2P_THIS_DEVICE_CHANGED_ACTION: {
                        WifiP2pDevice wifiP2pDevice = intent.getParcelableExtra(WifiP2pManager.EXTRA_WIFI_P2P_DEVICE);
                        mDirectActionListener.onSelfDeviceAvailable(wifiP2pDevice);
                        break;
                    }
                }
            }
        }

    }

    ActivityResultLauncher<Intent> CodeScannerResultLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if (result.getResultCode() == Activity.RESULT_OK) {
                    // There are no request codes
                    Intent data = result.getData();
                    if (data != null) {
                        try {
                            NetworkDevice device = new NetworkDevice(data.getStringExtra(BarcodeScannerActivity.EXTRA_DEVICE_ID));
                            AppUtils.getDatabase(getContext()).reconstruct(device);
                            NetworkDevice.Connection connection = new NetworkDevice.Connection(device.deviceId, data.getStringExtra(BarcodeScannerActivity.EXTRA_CONNECTION_ADAPTER));
                            AppUtils.getDatabase(getContext()).reconstruct(connection);

                            if (mListener != null)
                                mListener.onNetworkDeviceSelected(device, connection);
                        } catch (Exception e) {
                            // do nothing
                        }
                    }
                }
            });


    @Override
    public void setDeviceSelectedListener(NetworkDeviceSelectedListener listener)
    {
        mListener = listener;
    }

    private final UIConnectionUtils.RequestWatcher mHotspotWatcher = (result, shouldWait) -> mWaitForHotspot = shouldWait;

    public boolean getInfo_Location()
    {
        return (Build.VERSION.SDK_INT < 26 && getConnectionUtils().hasLocationPermission(getContext()))
                ||
                (getConnectionUtils().hasLocationPermission(getContext()) && getConnectionUtils().isLocationServiceEnabled());
    }


}
