package com.leaf.explorer.fragment;

import android.Manifest;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.net.NetworkInfo;
import android.net.wifi.WpsInfo;
import android.net.wifi.p2p.WifiP2pConfig;
import android.net.wifi.p2p.WifiP2pDevice;
import android.net.wifi.p2p.WifiP2pInfo;
import android.net.wifi.p2p.WifiP2pManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.core.app.ActivityCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.leaf.explorer.R;
import com.leaf.explorer.activity.LeafActivity;
import com.leaf.explorer.adapter.P2PDiscoverListAdapter;
import com.leaf.explorer.db.AccessDatabase;
import com.leaf.explorer.model.NetworkDevice;
import com.leaf.explorer.model.TitleSupport;
import com.leaf.explorer.service.CommunicationService;
import com.leaf.explorer.util.AppUtils;
import com.leaf.explorer.util.ConnectionUtils;
import com.leaf.explorer.util.IconSupport;
import com.leaf.explorer.util.NetworkDeviceLoader;
import com.leaf.explorer.util.NetworkDeviceSelectedListener;
import com.leaf.explorer.util.UIConnectionUtils;
import com.leaf.explorer.p2p_ble.DirectActionListener;
import com.leaf.explorer.widget.EditableListAdapter;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import static android.os.Looper.getMainLooper;

public class P2PDiscoverListFragment extends EditableListFragment<P2PDiscoverListAdapter.ContributorObject,
        EditableListAdapter.EditableViewHolder, P2PDiscoverListAdapter>
        implements TitleSupport, IconSupport {

    public static final int REQUEST_PERMISSION_LOCATION = 2;
    private boolean mWaitForHotspot = false;

    private UIConnectionUtils mConnectionUtils;
    private WifiP2pManager.Channel channel;
    private final IntentFilter mIntentFilter = new IntentFilter();
    private BroadcastReceiver broadcastReceiver;
    private boolean wifiP2pEnabled = false;
    private boolean ConnectionInfoAvailable = false;
    private NetworkDeviceSelectedListener mDeviceSelectedListener;
    private RelativeLayout ProgressLayout;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);

        mIntentFilter.addAction(WifiP2pManager.WIFI_P2P_STATE_CHANGED_ACTION);
        mIntentFilter.addAction(WifiP2pManager.WIFI_P2P_PEERS_CHANGED_ACTION);
        mIntentFilter.addAction(WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION);
        mIntentFilter.addAction(WifiP2pManager.WIFI_P2P_THIS_DEVICE_CHANGED_ACTION);

        channel = getConnectionUtils().getWifiP2pManager().initialize(getContext(), getMainLooper(), directActionListener);
        broadcastReceiver = new DirectBroadcastReceiver(getConnectionUtils().getWifiP2pManager(), channel, directActionListener);

        setDeviceSelectedListener(new NetworkDeviceSelectedListener()
        {
            @Override
            public boolean onNetworkDeviceSelected(NetworkDevice networkDevice, NetworkDevice.Connection connection)
            {
                if (getContext() != null) {
                    getContext().sendBroadcast(new Intent(CommunicationService.ACTION_DEVICE_ACQUAINTANCE)
                            .putExtra(CommunicationService.EXTRA_DEVICE_ID, networkDevice.deviceId)
                            .putExtra(CommunicationService.EXTRA_CONNECTION_ADAPTER_NAME, connection.adapterName));

                    return true;
                }

                return false;
            }

            @Override
            public boolean isListenerEffective()
            {
                return true;
            }
        });

    }

    @Override
    protected RecyclerView onListView(View mainContainer, ViewGroup listViewContainer)
    {
        View adaptedView = getLayoutInflater().inflate(R.layout.frag_p2p_container_task, null, false);
        listViewContainer.addView(adaptedView);

        ProgressLayout = adaptedView.findViewById(R.id.container_task);

        return super.onListView(mainContainer, adaptedView.findViewById(R.id.fragment_listViewContainer));
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState)
    {
        super.onViewCreated(view, savedInstanceState);

        useEmptyActionButton(true);
        getEmptyActionButton().setText(R.string.butn_refresh);
        getEmptyActionButton().setOnClickListener(v -> {
            ScanDevice();
            refreshList();
        });

        setEmptyImage(R.drawable.ic_github_circle_white_24dp);
        setEmptyText("\n" + getString(R.string.mesg_scanningDevices));
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState)
    {
        super.onActivityCreated(savedInstanceState);
        setHasOptionsMenu(true);
        setSortingSupported(false);

    }

    @Override
    public void onResume() {
        super.onResume();
        requireActivity().registerReceiver(broadcastReceiver, mIntentFilter);
        ScanDevice();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        requireActivity().unregisterReceiver(broadcastReceiver);
    }

    @Override
    public int getIconRes()
    {
        return R.drawable.ic_wifi_white_24dp;
    }

    @Override
    public CharSequence getTitle(Context context)
    {
        return context.getString(R.string.text_connectDevices);
    }

    @Override
    public void onCreateOptionsMenu(@NonNull Menu menu, @NonNull MenuInflater inflater)
    {
        super.onCreateOptionsMenu(menu, inflater);
        inflater.inflate(R.menu.p2p_fragment, menu);

        menu.findItem(R.id.manager_qr_image).setVisible(false);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        if (R.id.network_devices_scan == item.getItemId()) {
            ScanDevice();
        } else if (R.id.devices_disconnect == item.getItemId()) {
            disconnect();
        } else
            return super.onOptionsItemSelected(item);

        return true;
    }

    @Override
    public P2PDiscoverListAdapter onAdapter()
    {
        final AppUtils.QuickActions<EditableListAdapter.EditableViewHolder> quickActions = clazz -> {

            clazz.getView().findViewById(R.id.visitView).setOnClickListener(
                    v -> {
                        final P2PDiscoverListAdapter.ContributorObject contributorObject = getAdapter().getList().get(clazz.getAbsoluteAdapterPosition());
                        if (ConnectionInfoAvailable) {
                            new AlertDialog.Builder(requireContext())
                                    .setTitle("Information")
                                    .setMessage("Please Click on \n\n" +
                                            " =>Use Known Devices *Open* \n\n" +
                                            "and Select Your Device")
                                    .setPositiveButton("Ok", null)
                                    .create()
                                    .show();
                        } else {
                            // if (AppConfig.SAVE_P2P_PASS != null) {
                            //     Toast.makeText(getContext(), AppConfig.SAVE_P2P_PASS, Toast.LENGTH_SHORT).show();
                            // } else
                            connect(contributorObject.mWifiP2pDevice);
                            ProgressLayout.setVisibility(View.VISIBLE);
                        }
                    });

        };

        return new P2PDiscoverListAdapter(getContext())
        {
            @NonNull
            @Override
            public EditableViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType)
            {
                return AppUtils.quickAction(super.onCreateViewHolder(parent, viewType), quickActions);
            }
        };
    }

    @Override
    public boolean onDefaultClickAction(EditableListAdapter.EditableViewHolder holder)
    {
        return performLayoutClickOpen(holder);
    }

    public ConnectionUtils getConnectionUtils()
    {
        return getUIConnectionUtils().getConnectionUtils();
    }

    public UIConnectionUtils getUIConnectionUtils()
    {
        if (mConnectionUtils == null)
            mConnectionUtils = new UIConnectionUtils(ConnectionUtils.getInstance(getContext()), this);

        return mConnectionUtils;
    }

    public void setDeviceSelectedListener(NetworkDeviceSelectedListener listener)
    {
        mDeviceSelectedListener = listener;
    }

    private void ConnectP2PAddress(String IpAddress) {
        mConnectionUtils.makeAcquaintance(requireActivity(),
                null,
                IpAddress,
                -1,
                new NetworkDeviceLoader.OnDeviceRegisteredErrorListener() {
                    @Override
                    public void onError(Exception error) {

                    }

                    @Override
                    public void onDeviceRegistered(AccessDatabase database, NetworkDevice device, NetworkDevice.Connection connection) {
                        mDeviceSelectedListener.onNetworkDeviceSelected(device, connection);
                    }
                }
        );
    }

    private void connect(WifiP2pDevice mWifiP2pDevice) {
        WifiP2pConfig config = new WifiP2pConfig();
        if (config.deviceAddress != null && mWifiP2pDevice != null) {
            config.deviceAddress = mWifiP2pDevice.deviceAddress;
            config.wps.setup = WpsInfo.PBC;
            // Toast.makeText(getContext(), "Connecting to" + mWifiP2pDevice.deviceName, Toast.LENGTH_SHORT).show();

            if (ActivityCompat.checkSelfPermission(requireContext(), Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {

                return;
            }
            getConnectionUtils().getWifiP2pManager().connect(channel, config, new WifiP2pManager.ActionListener() {
                @Override
                public void onSuccess() {
                    Log.e(TAG, "connect onSuccess");
                }

                @Override
                public void onFailure(int reason) {
                    Toast.makeText(getContext(), reason, Toast.LENGTH_SHORT).show();
                }
            });
        }
    }

    private void disconnect() {
        getConnectionUtils().getWifiP2pManager().removeGroup(channel, new WifiP2pManager.ActionListener() {
            @Override
            public void onFailure(int reasonCode) {
                Log.e(TAG, "disconnect Fail:" + reasonCode);
                Toast.makeText(getContext(), "disconnect Fail:" + reasonCode, Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onSuccess() {
                Log.e(TAG, "disconnect onSuccess");
                Toast.makeText(getContext(), R.string.butn_disconnect, Toast.LENGTH_SHORT).show();
            }
        });
    }

    private final DirectActionListener directActionListener = new DirectActionListener() {
        @Override
        public void wifiP2pEnabled(boolean enabled) {
            wifiP2pEnabled = enabled;
        }

        @Override
        public void onConnectionInfoAvailable(WifiP2pInfo wifiP2pInfo) {
          //  if (wifiP2pInfo.groupFormed && !wifiP2pInfo.isGroupOwner) {
               // P2PDiscoverListFragment.this.wifiP2pInfo = wifiP2pInfo;
          //  }

            ConnectP2PAddress(wifiP2pInfo.groupOwnerAddress.getHostAddress());
        }

        @Override
        public void onDisconnection() {

        }

        @Override
        public void onSelfDeviceAvailable(WifiP2pDevice wifiP2pDevice) {
            if (LeafActivity.getDeviceStatus(wifiP2pDevice.status).equals("CONNECTED")) {
                ConnectionInfoAvailable = true;
            }
        }

        @Override
        public void onPeersAvailable(Collection<WifiP2pDevice> wifiP2pDeviceList) {
            getAdapter().P2pDeviceList(wifiP2pDeviceList);
            refreshList();
        }

        @Override
        public void onChannelDisconnected() {

        }
    };

    private void ScanDevice() {
        if (!getInfo_Location()) {
            getUIConnectionUtils().P2P_LocationPermission(getActivity(), REQUEST_PERMISSION_LOCATION, mHotspotWatcher);
        } else if (!getConnectionUtils().getWifiManager().isWifiEnabled()) {
            getUIConnectionUtils().turnOnWiFi(getActivity(), mHotspotWatcher);
        } else {
            if (ActivityCompat.checkSelfPermission(requireContext(), Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {

                return;
            }
            getConnectionUtils().getWifiP2pManager().discoverPeers(channel, new WifiP2pManager.ActionListener() {
                @Override
                public void onSuccess() {
                    Toast.makeText(getContext(), "Scanning", Toast.LENGTH_SHORT).show();
                }

                @Override
                public void onFailure(int reasonCode) {
                    if (!wifiP2pEnabled) {
                        Toast.makeText(getContext(), R.string.mesg_somethingWentWrong, Toast.LENGTH_SHORT).show();
                    }
                }
            });
        }
    }

    public static class DirectBroadcastReceiver extends BroadcastReceiver {

        private static final String TAG = "DirectBroadcastReceiver";

        private final WifiP2pManager mWifiP2pManager;
        private final WifiP2pManager.Channel mChannel;
        private final DirectActionListener mDirectActionListener;

        public DirectBroadcastReceiver(WifiP2pManager wifiP2pManager, WifiP2pManager.Channel channel, DirectActionListener directActionListener) {
            mWifiP2pManager = wifiP2pManager;
            mChannel = channel;
            mDirectActionListener = directActionListener;
        }

        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (action != null) {
                switch (action) {
                    // 用于指示 Wifi P2P 是否可用
                    case WifiP2pManager.WIFI_P2P_STATE_CHANGED_ACTION: {
                        int state = intent.getIntExtra(WifiP2pManager.EXTRA_WIFI_STATE, -100);
                        if (state == WifiP2pManager.WIFI_P2P_STATE_ENABLED) {
                            mDirectActionListener.wifiP2pEnabled(true);
                        } else {
                            mDirectActionListener.wifiP2pEnabled(false);
                            List<WifiP2pDevice> wifiP2pDeviceList = new ArrayList<>();
                            mDirectActionListener.onPeersAvailable(wifiP2pDeviceList);
                        }
                        break;
                    }
                    // 对等节点列表发生了变化
                    case WifiP2pManager.WIFI_P2P_PEERS_CHANGED_ACTION: {
                        if (ActivityCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                            //
                            //    ActivityCompat#requestPermissions
                            // here to request the missing permissions, and then overriding
                            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                            //                                          int[] grantResults)
                            // to handle the case where the user grants the permission. See the documentation
                            // for ActivityCompat#requestPermissions for more details.
                            return;
                        }
                        mWifiP2pManager.requestPeers(mChannel, peers -> mDirectActionListener.onPeersAvailable(peers.getDeviceList()));
                        break;
                    }
                    // Wifi P2P 的连接状态发生了改变
                    case WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION: {
                        NetworkInfo networkInfo = intent.getParcelableExtra(WifiP2pManager.EXTRA_NETWORK_INFO);
                        if (networkInfo != null && networkInfo.isConnected()) {
                            mWifiP2pManager.requestConnectionInfo(mChannel, mDirectActionListener::onConnectionInfoAvailable);
                            Log.e(TAG, "已连接p2p设备");
                        } else {
                            mDirectActionListener.onDisconnection();
                            Log.e(TAG, "与p2p设备已断开连接");
                        }
                        break;
                    }
                    //本设备的设备信息发生了变化
                    case WifiP2pManager.WIFI_P2P_THIS_DEVICE_CHANGED_ACTION: {
                        WifiP2pDevice wifiP2pDevice = intent.getParcelableExtra(WifiP2pManager.EXTRA_WIFI_P2P_DEVICE);
                        mDirectActionListener.onSelfDeviceAvailable(wifiP2pDevice);
                        break;
                    }
                }
            }
        }

    }

    private final UIConnectionUtils.RequestWatcher mHotspotWatcher = (result, shouldWait) -> mWaitForHotspot = shouldWait;

    public boolean getInfo_Location()
    {
        return (Build.VERSION.SDK_INT < 26 && getConnectionUtils().hasLocationPermission(getContext()))
                ||
                (getConnectionUtils().hasLocationPermission(getContext()) && getConnectionUtils().isLocationServiceEnabled());
    }

}
