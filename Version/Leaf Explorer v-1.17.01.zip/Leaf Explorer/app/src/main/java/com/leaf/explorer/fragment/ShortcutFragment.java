package com.leaf.explorer.fragment;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.leaf.explorer.R;
import com.leaf.explorer.activity.ContentSharingActivity;
import com.leaf.explorer.adapter.ShortcutAdapter;

import com.leaf.explorer.model.TitleSupport;
import com.leaf.explorer.util.AppUtils;
import com.leaf.explorer.util.NotReadyException;
import com.leaf.explorer.widget.EditableListAdapter;

public class ShortcutFragment extends EditableListFragment<ShortcutAdapter.ShortcutHolder, EditableListAdapter.EditableViewHolder, ShortcutAdapter>
        implements TitleSupport
{

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setSortingSupported(false);

        setDefaultViewingGridSize(1, 2);

    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState)
    {
        super.onViewCreated(view, savedInstanceState);

        setEmptyImage(R.drawable.ic_github_circle_white_24dp);
        setEmptyText(getString(R.string.coming_soon));
    }

    @Override
    public void onResume()
    {
        super.onResume();

    }

    @Override
    public void onPause()
    {
        super.onPause();
    }

    @Override
    public ShortcutAdapter onAdapter()
    {
        final AppUtils.QuickActions<EditableListAdapter.EditableViewHolder> quickActions = clazz -> {
            registerLayoutViewClicks(clazz);

            View visitView = clazz.getView().findViewById(R.id.menu);
            visitView.setOnClickListener(
                    v -> Toast.makeText(getContext(), "working", Toast.LENGTH_SHORT).show());

        };

        return new ShortcutAdapter(getActivity())
        {
            @NonNull
            @Override
            public EditableViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType)
            {
                return AppUtils.quickAction(super.onCreateViewHolder(parent, viewType), quickActions);
            }
        };
    }

    @Override
    public boolean onDefaultClickAction(EditableListAdapter.EditableViewHolder holder)
    {
        try {
            ShortcutAdapter.ShortcutHolder item = getAdapter().getItem(holder);

            if (item.getName().startsWith("Files")) {
//                Intent chooseFile = new Intent(Intent.ACTION_GET_CONTENT);
//                chooseFile.setType("*/*");
//                chooseFile.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
//                chooseFile = Intent.createChooser(chooseFile, "Choose a file");
//                openFileResultLauncher.launch(chooseFile);

                Toast.makeText(getContext(), "coming soon", Toast.LENGTH_SHORT).show();
            } else if (item.getName().startsWith("Images")) {
                SharingActivity(1);
            } else if (item.getName().startsWith("Musics")) {
                Toast.makeText(getContext(), "coming soon", Toast.LENGTH_SHORT).show();
            } else if (item.getName().startsWith("Videos")) {
                SharingActivity(2);
            }
        } catch (NotReadyException e) {
            e.printStackTrace();
        }
        return true;
    }

    private void SharingActivity(int number) {
        Intent mIntent = new Intent(getContext(), ContentSharingActivity.class);
        mIntent.putExtra("no.", number);
        startActivity(mIntent);
    }

    ActivityResultLauncher<Intent> openFileResultLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if (result.getResultCode() == Activity.RESULT_OK) {
                    // There are no request codes
                    Intent data = result.getData();
                    if (data != null) {
                        Uri uriTree = data.getData();

                    }
                }
            });

    @Override
    public CharSequence getTitle(Context context)
    {
        return context.getString(R.string.text_shortcut);
    }
}
