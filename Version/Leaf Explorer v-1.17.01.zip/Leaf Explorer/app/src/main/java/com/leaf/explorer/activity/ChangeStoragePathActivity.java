package com.leaf.explorer.activity;

import android.content.Intent;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;

import com.leaf.explorer.app.Activity;
import com.leaf.explorer.util.FileUtils;
import com.leaf.explorer.R;
import com.genonbeta.android.framework.io.DocumentFile;

/**
 * Created by: veli
 * Date: 5/30/17 6:57 PM
 */

public class ChangeStoragePathActivity extends Activity
{

    @Override
    protected void onStart()
    {
        super.onStart();

        DocumentFile currentSavePath = FileUtils.getApplicationDirectory(getApplicationContext());

        Intent intent = new Intent(this, FilePickerActivity.class)
                .setAction(FilePickerActivity.ACTION_CHOOSE_DIRECTORY)
                .putExtra(FilePickerActivity.EXTRA_START_PATH, currentSavePath.getUri().toString())
                .putExtra(FilePickerActivity.EXTRA_ACTIVITY_TITLE, getString(R.string.text_storagePath));
        someActivityResultLauncher.launch(intent);
    }

    ActivityResultLauncher<Intent> someActivityResultLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if (result.getResultCode() == Activity.RESULT_OK) {
                    // There are no request codes
                    Intent data = result.getData();
                    if (data != null && data.hasExtra(FilePickerActivity.EXTRA_CHOSEN_PATH)) {
                        getDefaultPreferences()
                                .edit()
                                .putString("storage_path", data.getParcelableExtra(FilePickerActivity.EXTRA_CHOSEN_PATH).toString())
                                .apply();

                        Toast.makeText(getApplicationContext(), "\uD83D\uDC4D", Toast.LENGTH_SHORT).show();
                    }
                }

                finish();
            });
}
