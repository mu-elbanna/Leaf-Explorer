package com.atul.musicplayerlite.listener;

import com.atul.musicplayerlite.model.Folder;

public interface AlbumSelectListener {
    void selectedAlbum(Folder album);
}
