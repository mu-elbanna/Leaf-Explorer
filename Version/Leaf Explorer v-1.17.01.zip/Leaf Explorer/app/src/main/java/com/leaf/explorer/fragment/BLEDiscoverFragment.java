package com.leaf.explorer.fragment;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothServerSocket;
import android.bluetooth.BluetoothSocket;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanFilter;
import android.bluetooth.le.ScanResult;
import android.bluetooth.le.ScanSettings;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;

import com.genonbeta.android.framework.app.Fragment;

import android.os.Handler;
import android.os.ParcelUuid;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import com.leaf.explorer.R;


/**
 * A simple {@link Fragment} subclass.
 */
public class BLEDiscoverFragment extends Fragment {
    private final static String TAG = "BLEDiscoverFragment";
    private Button discover;
    private Boolean discovering = false;

    private final ArrayList<DataModel> dataModels = new ArrayList<>();
    private CustomAdapter adapter;

    private BluetoothAdapter mBluetoothAdapter;
    private BluetoothLeScanner mBluetoothLeScanner;
    private final Handler mHandler = new Handler();

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        IntentFilter filter = new IntentFilter(BluetoothDevice.ACTION_PAIRING_REQUEST);
        requireActivity().registerReceiver(mPairingRequestReceiver, filter);
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View myView = inflater.inflate(R.layout.fragment_discover_p2p, container, false);

        discover = myView.findViewById(R.id.discover);
        discover.setOnClickListener(v -> {
            if (discovering) { //stop it
                stop_discover();
            } else { //start
                start_discover();
            }
        });

        mBluetoothLeScanner = BluetoothAdapter.getDefaultAdapter().getBluetoothLeScanner();
        mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();

        ListView donationList = myView.findViewById(R.id.list_view);
        adapter = new CustomAdapter(dataModels, getActivity());
        donationList.setAdapter(adapter);

        return myView;
    }

    @Override
    public void onResume() {
        super.onResume();
    }

    @Override
    public void onPause()
    {
        super.onPause();
    }

    private final ScanCallback mScanCallback = new ScanCallback() {
        @Override
        public void onScanResult(int callbackType, ScanResult result) {
            super.onScanResult(callbackType, result);

            if (result == null || result.getDevice() == null) {
                Toast.makeText(getContext(), "The data result is empty or no data", Toast.LENGTH_SHORT).show();
            } else {

               // AppConfig.SAVE_P2P_PASS = new String(result.getScanRecord().getServiceData(result.getScanRecord().getServiceUuids().get(0)), StandardCharsets.UTF_8);

                dataModels.add(new DataModel(result.getDevice(),
                        new String(result.getScanRecord().getServiceData(result.getScanRecord().getServiceUuids().get(0)), StandardCharsets.UTF_8)));
                adapter.notifyDataSetChanged();
            }

        }

        @Override
        public void onBatchScanResults(List<ScanResult> results) {

            for (ScanResult result : results) {
                //name
                StringBuilder builder = new StringBuilder("Name: ").append(result.getDevice().getName());
                //address
                builder.append("\n").append("address: ").append(result.getDevice().getAddress());
                //data
                builder.append("\n").append("data: ").append(new String(result.getScanRecord().getServiceData(result.getScanRecord().getServiceUuids().get(0)), StandardCharsets.UTF_8));

               // dataModels.add(new DataModel(result.getDevice(),
               //         new String(result.getScanRecord().getServiceData(result.getScanRecord().getServiceUuids().get(0)), StandardCharsets.UTF_8)));
               // adapter.notifyDataSetChanged();
            }
            super.onBatchScanResults(results);
        }

        @Override
        public void onScanFailed(int errorCode) {

            discovering = false;
            discover.setText("Start Discovering");
            super.onScanFailed(errorCode);

        }
    };

    void stop_discover() {
        mBluetoothLeScanner.stopScan(mScanCallback);

        discovering = false;
        discover.setText("Start Discovering");
    }

    void start_discover() {

        List<ScanFilter> filters = new ArrayList<>();

        ScanFilter filter = new ScanFilter.Builder()
                .setServiceUuid(new ParcelUuid(UUID.fromString(getString(R.string.blue_uuid))))
                .build();
        filters.add(filter);

        ScanSettings settings = new ScanSettings.Builder()
                .setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY)
                .build();

        mBluetoothLeScanner.startScan(filters, settings, mScanCallback);

        mHandler.postDelayed(() -> {
            mBluetoothLeScanner.stopScan(mScanCallback);

            discovering = false;
            discover.setText("Start Discovering");
        }, 5000);

        discovering = true;
        discover.setText("Stop Discovering");
    }

    public static class DataModel {

        BluetoothDevice device;
        String bleData;

        DataModel(BluetoothDevice device, String bleData) {
            this.device = device;
            this.bleData = bleData;
        }

        public BluetoothDevice getDevice() {
            return device;
        }

        public String getBleData() {
            return bleData;
        }
    }

    public class CustomAdapter extends ArrayAdapter<DataModel> {

        Activity mActivity;
        // View lookup cache
        private class ViewHolder {
            LinearLayout mRelativeLayout;
            TextView title;
            TextView mAddress;
            TextView bleData;
        }

        CustomAdapter(ArrayList<DataModel> data, Activity mActivity) {
            super(mActivity, R.layout.listitem_device, data);
            this.mActivity = mActivity;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            // Get the data item for this position
            DataModel dataModel = getItem(position);
            // Check if an existing view is being reused, otherwise inflate the view
            ViewHolder viewHolder; // view lookup cache stored in tag

            if (convertView == null) {

                viewHolder = new ViewHolder();
                LayoutInflater inflater = LayoutInflater.from(getContext());
                convertView = inflater.inflate(R.layout.listitem_device, parent, false);
                viewHolder.mRelativeLayout = convertView.findViewById(R.id.click);
                viewHolder.title = convertView.findViewById(R.id.device_name);
                viewHolder.mAddress = convertView.findViewById(R.id.device_address);
                viewHolder.bleData = convertView.findViewById(R.id.bleData);

                convertView.setTag(viewHolder);
            } else {
                viewHolder = (ViewHolder) convertView.getTag();
            }

            viewHolder.title.setText(dataModel.getDevice().getName());
            viewHolder.bleData.setText(dataModel.getBleData());
            viewHolder.mAddress.setText(dataModel.getDevice().getAddress());
            viewHolder.mRelativeLayout.setOnClickListener(v -> {

                boolean outcome = dataModel.getDevice().createBond();
                if (outcome) {
                    startServer();
                    Toast.makeText(mActivity, "success", Toast.LENGTH_SHORT).show();
                   //   Intent intent = new Intent(getContext(), DeviceControlActivity.class);
                   //   intent.putExtra(DeviceControlActivity.EXTRAS_DEVICE_NAME, dataModel.getDevice().getName());
                   //   intent.putExtra(DeviceControlActivity.EXTRAS_DEVICE_ADDRESS, dataModel.getDevice().getAddress());
                   //   getContext().startActivity(intent);
                }
                if (discovering) {
                    mBluetoothLeScanner.stopScan(mScanCallback);

                    discovering = false;
                }
            });

            // Return the completed view to render on screen
            return convertView;
        }
    }


    private final BroadcastReceiver mPairingRequestReceiver = new BroadcastReceiver() {
        final String BLE_PIN = "1234";
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (BluetoothDevice.ACTION_PAIRING_REQUEST.equals(action)) {
                try {
                    BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);

                    if (device != null) {
                        device.setPin(BLE_PIN.getBytes());
                        //setPairing confirmation if needed
                        device.setPairingConfirmation(true);
                    }

                } catch (Exception e) {
                    Log.e(TAG, "Error occurs when trying to auto pair");
                    e.printStackTrace();
                }
            }
        }
    };








    public void mkmsg(String str) {
        Toast.makeText(getContext(), str, Toast.LENGTH_SHORT).show();
    }

    public void startServer() {
        new Thread(new AcceptThread()).start();

    }

    public static final UUID MY_UUID = UUID.fromString("fa87c0d0-afac-11de-8a39-0800200c9a66");
    public static final String NAME = "BluetoothDemo";

    /**
     * This thread runs while listening for incoming connections. It behaves
     * like a server-side client. It runs until a connection is accepted
     * (or until cancelled).
     */
    private class AcceptThread extends Thread {
        // The local server socket
        private final BluetoothServerSocket mmServerSocket;

        public AcceptThread() {
            BluetoothServerSocket tmp = null;
            // Create a new listening server socket
            try {
                tmp = mBluetoothAdapter.listenUsingRfcommWithServiceRecord(NAME, MY_UUID);
            } catch (IOException e) {
                mkmsg("Failed to start server\n");
            }
            mmServerSocket = tmp;
        }

        public void run() {
            mkmsg("waiting on accept");
            BluetoothSocket socket = null;
            try {
                // This is a blocking call and will only return on a
                // successful connection or an exception
                socket = mmServerSocket.accept();
            } catch (IOException e) {
                mkmsg("Failed to accept\n");
            }

            // If a connection was accepted
            if (socket != null) {
                mkmsg("Connection made\n");
                mkmsg("Remote device address: " + socket.getRemoteDevice().getAddress() + "\n");
                //Note this is copied from the TCPdemo code.
                try {
                    mkmsg("Attempting to receive a message ...\n");
                    BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                    String str = in.readLine();
                    mkmsg("received a message:\n" + str + "\n");

                    PrintWriter out = new PrintWriter(new BufferedWriter(new OutputStreamWriter(socket.getOutputStream())), true);
                    mkmsg("Attempting to send message ...\n");
                    out.println("Hi from Bluetooth Demo Server");
                    out.flush();
                    mkmsg("Message sent...\n");

                    mkmsg("We are done, closing connection\n");
                } catch (Exception e) {
                    mkmsg("Error happened sending/receiving\n");

                } finally {
                    try {
                        socket.close();
                    } catch (IOException e) {
                        mkmsg("Unable to close socket" + e.getMessage() + "\n");
                    }
                }
            } else {
                mkmsg("Made connection, but socket is null\n");
            }
            mkmsg("Server ending \n");
        }

        public void cancel() {
            try {
                mmServerSocket.close();
            } catch (IOException e) {
                mkmsg( "close() of connect socket failed: "+e.getMessage() +"\n");
            }
        }
    }

}
