package com.genonbeta.android.framework.util.listing;

/**
 * created by: Veli
 * date: 29.03.2018 08:14
 */
abstract public class ComparableMerger<T>
		extends Merger<T>
		implements Comparable<ComparableMerger<T>>
{

}
