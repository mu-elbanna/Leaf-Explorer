package com.leaf.explorer.file_share.wifi_p2p;

import android.Manifest;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.net.NetworkInfo;
import android.net.wifi.WpsInfo;
import android.net.wifi.p2p.WifiP2pConfig;
import android.net.wifi.p2p.WifiP2pDevice;
import android.net.wifi.p2p.WifiP2pInfo;
import android.net.wifi.p2p.WifiP2pManager;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.leaf.explorer.R;
import com.leaf.explorer.activity.LeafActivity;
import com.leaf.explorer.file_share.db.AccessDatabase;
import com.leaf.explorer.file_share.model.NetworkDevice;
import com.leaf.explorer.file_share.model.TitleSupport;
import com.leaf.explorer.file_share.service.CommunicationService;
import com.leaf.explorer.file_share.util.ConnectionUtils;
import com.leaf.explorer.file_share.util.IconSupport;
import com.leaf.explorer.file_share.util.NetworkDeviceLoader;
import com.leaf.explorer.file_share.util.NetworkDeviceSelectedListener;
import com.leaf.explorer.file_share.util.UIConnectionUtils;
import com.leaf.explorer.file_share.view.RadarScanView;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import static android.os.Looper.getMainLooper;

public class P2PWiFiFrag
        extends com.genonbeta.android.framework.app.Fragment
        implements TitleSupport, IconSupport {

    private static final String TAG = "P2PWiFiFrag";
    private WifiP2pManager wifiP2pManager;
    private WifiP2pManager.Channel channel;
    private WifiP2pInfo wifiP2pInfo;
    private boolean wifiP2pEnabled = false;

    private final DirectActionListener directActionListener = new DirectActionListener() {

        @Override
        public void wifiP2pEnabled(boolean enabled) {
            wifiP2pEnabled = enabled;
        }

        @Override
        public void onConnectionInfoAvailable(WifiP2pInfo wifiP2pInfo) {

            wifiP2pDeviceList.clear();
            deviceAdapter.notifyDataSetChanged();

            Log.e(TAG, "onConnectionInfoAvailable");
            Log.e(TAG, "onConnectionInfoAvailable groupFormed: " + wifiP2pInfo.groupFormed);
            Log.e(TAG, "onConnectionInfoAvailable isGroupOwner: " + wifiP2pInfo.isGroupOwner);
            Log.e(TAG, "onConnectionInfoAvailable getHostAddress: " + wifiP2pInfo.groupOwnerAddress.getHostAddress());
            StringBuilder stringBuilder = new StringBuilder();
            if (mWifiP2pDevice != null) {
                stringBuilder.append("Device Name：");
                stringBuilder.append(mWifiP2pDevice.deviceName);
                stringBuilder.append("\n");
                stringBuilder.append("Device Address：");
                stringBuilder.append(mWifiP2pDevice.deviceAddress);
            }
            stringBuilder.append("\n");
            stringBuilder.append("GroupOwner：");
            stringBuilder.append(wifiP2pInfo.isGroupOwner ? "Yes" : "No");
            stringBuilder.append("\n");
            stringBuilder.append("OwnerAddress：");
            stringBuilder.append(wifiP2pInfo.groupOwnerAddress.getHostAddress());
            tv_status.setText(stringBuilder);
            if (wifiP2pInfo.groupFormed && !wifiP2pInfo.isGroupOwner) {
                P2PWiFiFrag.this.wifiP2pInfo = wifiP2pInfo;
            }

            mConnectionUtils.makeAcquaintance(requireActivity(),
                    null,
                    wifiP2pInfo.groupOwnerAddress.getHostAddress(),
                    -1,
                    new NetworkDeviceLoader.OnDeviceRegisteredErrorListener() {
                        @Override
                        public void onError(Exception error) {

                        }

                        @Override
                        public void onDeviceRegistered(AccessDatabase database, NetworkDevice device, NetworkDevice.Connection connection) {
                            mDeviceSelectedListener.onNetworkDeviceSelected(device, connection);
                        }
                    }
            );

        }

        @Override
        public void onDisconnection() {
            Log.e(TAG, "onDisconnection");

            Toast.makeText(getContext(), "Disconnect", Toast.LENGTH_SHORT).show();
            wifiP2pDeviceList.clear();
            deviceAdapter.notifyDataSetChanged();
            tv_status.setText(null);
            P2PWiFiFrag.this.wifiP2pInfo = null;
        }

        @Override
        public void onSelfDeviceAvailable(WifiP2pDevice wifiP2pDevice) {
            Log.e(TAG, "onSelfDeviceAvailable");
            Log.e(TAG, "DeviceName: " + wifiP2pDevice.deviceName);
            Log.e(TAG, "DeviceAddress: " + wifiP2pDevice.deviceAddress);
            Log.e(TAG, "Status: " + wifiP2pDevice.status);
            tv_myDeviceName.setText(wifiP2pDevice.deviceName);
            tv_myDeviceAddress.setText(wifiP2pDevice.deviceAddress);
            tv_myDeviceStatus.setText(LeafActivity.getDeviceStatus(wifiP2pDevice.status));
        }

        @Override
        public void onPeersAvailable(Collection<WifiP2pDevice> wifiP2pDeviceList) {
            Log.e(TAG, "onPeersAvailable :" + wifiP2pDeviceList.size());
            P2PWiFiFrag.this.wifiP2pDeviceList.clear();
            P2PWiFiFrag.this.wifiP2pDeviceList.addAll(wifiP2pDeviceList);
            deviceAdapter.notifyDataSetChanged();

        }

        @Override
        public void onChannelDisconnected() {
            Log.e(TAG, "onChannelDisconnected");
        }

    };

    private TextView tv_myDeviceName;
    private TextView tv_myDeviceAddress;
    private TextView tv_myDeviceStatus;
    private TextView tv_status;
    private List<WifiP2pDevice> wifiP2pDeviceList;
    private DeviceAdapter deviceAdapter;
    private Button btn_disconnect;
    private Button btn_chooseFile;
    private BroadcastReceiver broadcastReceiver;
    private WifiP2pDevice mWifiP2pDevice;
    private UIConnectionUtils mConnectionUtils;
    private NetworkDeviceSelectedListener mDeviceSelectedListener;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        initEvent();
        mConnectionUtils = new UIConnectionUtils(ConnectionUtils.getInstance(getContext()), this);

        setDeviceSelectedListener(new NetworkDeviceSelectedListener()
        {
            @Override
            public boolean onNetworkDeviceSelected(NetworkDevice networkDevice, NetworkDevice.Connection connection)
            {
                if (getContext() != null) {
                    getContext().sendBroadcast(new Intent(CommunicationService.ACTION_DEVICE_ACQUAINTANCE)
                            .putExtra(CommunicationService.EXTRA_DEVICE_ID, networkDevice.deviceId)
                            .putExtra(CommunicationService.EXTRA_CONNECTION_ADAPTER_NAME, connection.adapterName));

                    return true;
                }

                return false;
            }

            @Override
            public boolean isListenerEffective()
            {
                return true;
            }
        });
    }

    private void initEvent() {
        wifiP2pManager = (WifiP2pManager) requireContext().getApplicationContext().getSystemService(Context.WIFI_P2P_SERVICE);

        channel = wifiP2pManager.initialize(getContext(), getMainLooper(), directActionListener);
        broadcastReceiver = new DirectBroadcastReceiver(wifiP2pManager, channel, directActionListener);

    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = getLayoutInflater().inflate(R.layout.activity_send_file, container, false);

        RadarScanView radarView;
        radarView = view.findViewById(R.id.radar);
        radarView.start();

        tv_myDeviceName = view.findViewById(R.id.tv_myDeviceName);
        tv_myDeviceAddress = view.findViewById(R.id.tv_myDeviceAddress);
        tv_myDeviceStatus = view.findViewById(R.id.tv_myDeviceStatus);
        tv_status = view.findViewById(R.id.tv_status);
        btn_disconnect = view.findViewById(R.id.btn_disconnect);
        btn_chooseFile = view.findViewById(R.id.btn_chooseFile);
        btn_disconnect.setOnClickListener(v -> disconnect());
        btn_chooseFile.setOnClickListener(v -> ScanDevice());

        RecyclerView rv_deviceList = view.findViewById(R.id.rv_deviceList);
        wifiP2pDeviceList = new ArrayList<>();
        deviceAdapter = new DeviceAdapter(wifiP2pDeviceList, getContext());
        deviceAdapter.setClickListener(position -> {
            mWifiP2pDevice = wifiP2pDeviceList.get(position);
            Toast.makeText(getContext(), mWifiP2pDevice.deviceName, Toast.LENGTH_SHORT).show();
            connect();
        });
        rv_deviceList.setAdapter(deviceAdapter);
        rv_deviceList.setLayoutManager(new LinearLayoutManager(getContext()));

        return view;
    }

    @Override
    public void onResume() {
        super.onResume();
        requireContext().registerReceiver(broadcastReceiver, DirectBroadcastReceiver.getIntentFilter());
        ScanDevice();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        requireContext().unregisterReceiver(broadcastReceiver);
    }

    @Override
    public int getIconRes()
    {
        return R.drawable.ic_wifi_tethering_white_24dp;
    }

    @Override
    public CharSequence getTitle(Context context)
    {
        return context.getString(R.string.text_startHotspot);
    }

    public void setDeviceSelectedListener(NetworkDeviceSelectedListener listener)
    {
        mDeviceSelectedListener = listener;
    }

    private void ScanDevice() {

        wifiP2pDeviceList.clear();
        deviceAdapter.notifyDataSetChanged();

        if (ActivityCompat.checkSelfPermission(requireContext(), Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {

            return;
        }
        wifiP2pManager.discoverPeers(channel, new WifiP2pManager.ActionListener() {
            @Override
            public void onSuccess() {
                Toast.makeText(getContext(), "Scanning", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onFailure(int reasonCode) {
                if (!wifiP2pEnabled) {
                    Toast.makeText(getContext(), R.string.mesg_somethingWentWrong, Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void connect() {
        WifiP2pConfig config = new WifiP2pConfig();
        if (config.deviceAddress != null && mWifiP2pDevice != null) {
            config.deviceAddress = mWifiP2pDevice.deviceAddress;
            config.wps.setup = WpsInfo.PBC;
            Toast.makeText(getContext(), "Connecting to" + mWifiP2pDevice.deviceName, Toast.LENGTH_SHORT).show();

            if (ActivityCompat.checkSelfPermission(requireContext(), Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {

                return;
            }
            wifiP2pManager.connect(channel, config, new WifiP2pManager.ActionListener() {
                @Override
                public void onSuccess() {
                    Log.e(TAG, "connect onSuccess");
                }

                @Override
                public void onFailure(int reason) {
                    Toast.makeText(getContext(), reason, Toast.LENGTH_SHORT).show();
                }
            });
        }
    }

    private void disconnect() {
        wifiP2pManager.removeGroup(channel, new WifiP2pManager.ActionListener() {
            @Override
            public void onFailure(int reasonCode) {
                Log.e(TAG, "disconnect Fail:" + reasonCode);
                Toast.makeText(getContext(), "disconnect Fail:" + reasonCode, Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onSuccess() {
                Log.e(TAG, "disconnect onSuccess");
                tv_status.setText(null);
                Toast.makeText(getContext(), R.string.butn_disconnect, Toast.LENGTH_SHORT).show();
            }
        });
    }

    public static class DirectBroadcastReceiver extends BroadcastReceiver {

        public static IntentFilter getIntentFilter() {
            IntentFilter intentFilter = new IntentFilter();
            intentFilter.addAction(WifiP2pManager.WIFI_P2P_STATE_CHANGED_ACTION);
            intentFilter.addAction(WifiP2pManager.WIFI_P2P_PEERS_CHANGED_ACTION);
            intentFilter.addAction(WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION);
            intentFilter.addAction(WifiP2pManager.WIFI_P2P_THIS_DEVICE_CHANGED_ACTION);
            return intentFilter;
        }

        private static final String TAG = "DirectBroadcastReceiver";

        private final WifiP2pManager mWifiP2pManager;

        private final WifiP2pManager.Channel mChannel;

        private final DirectActionListener mDirectActionListener;

        public DirectBroadcastReceiver(WifiP2pManager wifiP2pManager, WifiP2pManager.Channel channel, DirectActionListener directActionListener) {
            mWifiP2pManager = wifiP2pManager;
            mChannel = channel;
            mDirectActionListener = directActionListener;
        }

        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (action != null) {
                switch (action) {
                    // 用于指示 Wifi P2P 是否可用
                    case WifiP2pManager.WIFI_P2P_STATE_CHANGED_ACTION: {
                        int state = intent.getIntExtra(WifiP2pManager.EXTRA_WIFI_STATE, -100);
                        if (state == WifiP2pManager.WIFI_P2P_STATE_ENABLED) {
                            mDirectActionListener.wifiP2pEnabled(true);
                        } else {
                            mDirectActionListener.wifiP2pEnabled(false);
                            List<WifiP2pDevice> wifiP2pDeviceList = new ArrayList<>();
                            mDirectActionListener.onPeersAvailable(wifiP2pDeviceList);
                        }
                        break;
                    }
                    // 对等节点列表发生了变化
                    case WifiP2pManager.WIFI_P2P_PEERS_CHANGED_ACTION: {
                        if (ActivityCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                            //
                            //    ActivityCompat#requestPermissions
                            // here to request the missing permissions, and then overriding
                            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                            //                                          int[] grantResults)
                            // to handle the case where the user grants the permission. See the documentation
                            // for ActivityCompat#requestPermissions for more details.
                            return;
                        }
                        mWifiP2pManager.requestPeers(mChannel, peers -> mDirectActionListener.onPeersAvailable(peers.getDeviceList()));
                        break;
                    }
                    // Wifi P2P 的连接状态发生了改变
                    case WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION: {
                        NetworkInfo networkInfo = intent.getParcelableExtra(WifiP2pManager.EXTRA_NETWORK_INFO);
                        if (networkInfo != null && networkInfo.isConnected()) {
                            mWifiP2pManager.requestConnectionInfo(mChannel, mDirectActionListener::onConnectionInfoAvailable);
                            Log.e(TAG, "已连接p2p设备");
                        } else {
                            mDirectActionListener.onDisconnection();
                            Log.e(TAG, "与p2p设备已断开连接");
                        }
                        break;
                    }
                    //本设备的设备信息发生了变化
                    case WifiP2pManager.WIFI_P2P_THIS_DEVICE_CHANGED_ACTION: {
                        WifiP2pDevice wifiP2pDevice = intent.getParcelableExtra(WifiP2pManager.EXTRA_WIFI_P2P_DEVICE);
                        mDirectActionListener.onSelfDeviceAvailable(wifiP2pDevice);
                        break;
                    }
                }
            }
        }

    }

}
