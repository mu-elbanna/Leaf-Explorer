package com.leaf.explorer.file_share.adapter;

import android.bluetooth.BluetoothDevice;
import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.leaf.explorer.R;
import com.leaf.explorer.file_share.base.GlideApp;
import com.leaf.explorer.file_share.model.Shareable;
import com.leaf.explorer.file_share.widget.EditableListAdapter;

import java.util.ArrayList;
import java.util.List;

public class WiFiDeviceListAdapter
        extends EditableListAdapter<WiFiDeviceListAdapter.ShortcutHolder, EditableListAdapter.EditableViewHolder>
{

    private final ArrayList<BluetoothDevice> mLeDevices;

    public WiFiDeviceListAdapter(Context context)
    {
        super(context);
        mLeDevices = new ArrayList<>();
    }

    @Override
    public List<ShortcutHolder> onLoad()
    {
        ArrayList<ShortcutHolder> shortcutList = new ArrayList<>();

        for (BluetoothDevice mDevice : mLeDevices) {
            ShortcutHolder mShortcutHolder = new ShortcutHolder(mDevice.getName(), mDevice.getAddress());
            mShortcutHolder.name = mDevice.getName();
            mShortcutHolder.desc = mDevice.getAddress();

            shortcutList.add(mShortcutHolder);
        }
      //  shortcutList.add(new ShortcutHolder("Images", "get Images"));

        return shortcutList;
    }

    public void addDevice(BluetoothDevice device) {
        mLeDevices.add(device);
    }

    @NonNull
    @Override
    public EditableViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType)
    {

        return new EditableListAdapter.EditableViewHolder(getInflater().inflate(
                isHorizontalOrientation() || isGridLayoutRequested()
                        ? R.layout.row_device_grid
                        : R.layout.row_device, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull EditableViewHolder holder, int position)
    {
        try {
            final View parentView = holder.getView();
            final ShortcutHolder object = getItem(position);

            TextView deviceText = parentView.findViewById(R.id.text2);
            TextView userText = parentView.findViewById(R.id.text1);
            ImageView userImage = parentView.findViewById(R.id.image);
            ImageView statusImage = parentView.findViewById(R.id.imageStatus);

            userText.setText(object.name);
            deviceText.setText(object.desc);

            GlideApp.with(getContext())
                    .load(R.drawable.ic_photo_white_24dp)
                    .override(300)
                    .centerCrop()
                    .into(userImage);

            statusImage.setVisibility(View.GONE);


        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static class ShortcutHolder extends Shareable
    {
        public String name, desc;

        public ShortcutHolder(String name, String desc) {
            super(0, name, desc, null, 0, 0, null);
        }

    }



}
